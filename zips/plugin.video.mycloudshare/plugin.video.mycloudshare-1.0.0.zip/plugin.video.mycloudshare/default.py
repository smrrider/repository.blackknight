# -*- coding: utf-8 -*-
"""My Cloud Share - browse and play a WD My Cloud OS5 public share link in Kodi.

Flow (mirrors the os5.mycloud.com web app):
  1. GET config.wdckeystone.com/config/v1/config        -> share service URL
  2. GET <share service>/v1/shares/<shareId>            -> shareToken + device relay URLs + root folder id
  3. GET <device>/sdk/v2/filesSearch/parents?ids=<id>   -> folder listing (Bearer shareToken, paginated)
  4. <device>/sdk/v3/files/<id>/content?access_token=   -> byte-range stream (seekable)
"""
import json
import re
import sys
import time
import urllib.error
import urllib.parse
import urllib.request

try:
    import xbmc
    import xbmcaddon
    import xbmcgui
    import xbmcplugin
except ImportError:  # allows command-line testing outside Kodi
    xbmc = xbmcaddon = xbmcgui = xbmcplugin = None

CONFIG_URL = "https://config.wdckeystone.com/config/v1/config"
UA = "Kodi-MyCloudShare/1.0"
TIMEOUT = 20
PAGE = 500
FIELDS = "id,name,mimeType,size,mTime,video,image"
VIDEO_EXT = (".mp4", ".m4v", ".mov", ".mkv", ".avi", ".mpg", ".mpeg", ".mts", ".m2ts",
             ".ts", ".wmv", ".3gp", ".vob", ".flv", ".webm", ".dv", ".mod", ".tod")


def log(msg):
    if xbmc:
        xbmc.log("[MyCloudShare] %s" % msg, xbmc.LOGINFO)
    else:
        print("[log]", msg)


def http_json(url, token=None):
    headers = {"User-Agent": UA, "Accept": "application/json"}
    if token:
        headers["Authorization"] = "Bearer " + token
    req = urllib.request.Request(url, headers=headers)
    with urllib.request.urlopen(req, timeout=TIMEOUT) as resp:
        return json.loads(resp.read().decode("utf-8"))


def share_id_from(url):
    m = re.search(r"share/([0-9a-fA-F-]{36})", url or "")
    if not m:
        raise ValueError("That doesn't look like an os5.mycloud.com/action/share/... link")
    return m.group(1)


class Share(object):
    """Resolves the share once per plugin invocation (token is valid ~10 h)."""

    def __init__(self, share_url, direct=False):
        cfg = http_json(CONFIG_URL)
        urls = cfg["data"]["componentMap"]["cloud.service.urls"]
        share_svc = urls["service.share.url"]
        data = http_json("%s/v1/shares/%s" % (share_svc, share_id_from(share_url)))
        if data.get("error") or not data.get("data"):
            raise RuntimeError("Share not found or link was deleted")
        d = data["data"]
        self.token = d["shareToken"]
        self.root_id = d["fileIds"][0]
        self.root_is_dir = d.get("metadata", {}).get("filetype", "").endswith("dir")
        dev = d.get("device") or {}
        if not dev.get("cloudConnected"):
            raise RuntimeError("The My Cloud drive is offline or not cloud-connected")
        net = dev.get("network", {})
        self.base = net["proxyURL"]
        if direct and net.get("portForwardURL"):
            try:
                http_json(net["portForwardURL"] + "/sdk/v2/files/%s?fields=id" % self.root_id, self.token)
                self.base = net["portForwardURL"]
                log("using direct connection")
            except Exception as e:  # noqa
                log("direct connection failed (%s), using WD relay" % e)

    def list(self, folder_id):
        items, token = [], ""
        while True:
            q = {"ids": folder_id, "limit": PAGE, "fields": FIELDS, "orderBy": "name", "order": "asc"}
            if token:
                q["pageToken"] = token
            j = http_json(self.base + "/sdk/v2/filesSearch/parents?" + urllib.parse.urlencode(q), self.token)
            items.extend(j.get("files", []))
            token = j.get("pageToken") or ""
            if not token or not j.get("files"):
                return items

    def stream_url(self, file_id):
        return "%s/sdk/v3/files/%s/content?access_token=%s" % (self.base, file_id, self.token)

    def thumb_url(self, file_id):
        return ("%s/sdk/v2/files/%s/content?minWidth=320&minHeight=180&allowOriginal=false"
                "&allowTemporary=true&access_token=%s" % (self.base, file_id, self.token))


def is_video(f):
    mt = f.get("mimeType", "")
    return mt.startswith("video/") or f.get("name", "").lower().endswith(VIDEO_EXT)


def natural_key(name):
    return [int(t) if t.isdigit() else t.lower() for t in re.split(r"(\d+)", name)]


def sort_items(files):
    dirs = [f for f in files if f.get("mimeType", "").endswith("dir")]
    rest = [f for f in files if not f.get("mimeType", "").endswith("dir")]
    key = lambda f: natural_key(f.get("name", ""))
    return sorted(dirs, key=key) + sorted(rest, key=key)


# ----------------------------------------------------------------- Kodi UI
def build_url(handle_base, **kw):
    return handle_base + "?" + urllib.parse.urlencode(kw)


def run(argv):
    base_url, handle = argv[0], int(argv[1])
    params = dict(urllib.parse.parse_qsl(argv[2].lstrip("?")))
    addon = xbmcaddon.Addon()
    try:
        share = Share(addon.getSetting("share_url"), direct=addon.getSetting("connection") == "1")
    except Exception as e:
        log("share resolve failed: %r" % e)
        xbmcgui.Dialog().ok("My Cloud Share", "Could not open the share:\n%s" % e)
        xbmcplugin.endOfDirectory(handle, succeeded=False)
        return

    if params.get("action") == "play":
        li = xbmcgui.ListItem(path=share.stream_url(params["id"]))
        xbmcplugin.setResolvedUrl(handle, True, li)
        return

    folder = params.get("id", share.root_id)
    show_photos = addon.getSetting("show_photos") == "true"
    xbmcplugin.setContent(handle, "videos")
    try:
        files = sort_items(share.list(folder))
    except urllib.error.HTTPError as e:
        xbmcgui.Dialog().ok("My Cloud Share", "Drive returned HTTP %s" % e.code)
        xbmcplugin.endOfDirectory(handle, succeeded=False)
        return

    for f in files:
        name, fid, mt = f.get("name", "?"), f["id"], f.get("mimeType", "")
        if mt.endswith("dir"):
            li = xbmcgui.ListItem(label=name)
            li.setArt({"icon": "DefaultFolder.png"})
            xbmcplugin.addDirectoryItem(handle, build_url(base_url, id=fid), li, isFolder=True)
        elif is_video(f):
            li = xbmcgui.ListItem(label=name)
            v = f.get("video") or {}
            tag = li.getVideoInfoTag()
            tag.setTitle(name)
            tag.setMediaType("video")
            if v.get("duration"):
                tag.setDuration(int(float(v["duration"])))
            if f.get("mTime"):
                tag.setPremiered(f["mTime"][:10])
            li.setArt({"thumb": share.thumb_url(fid), "icon": "DefaultVideo.png"})
            li.setProperty("IsPlayable", "true")
            xbmcplugin.addDirectoryItem(handle, build_url(base_url, action="play", id=fid), li, isFolder=False)
        elif show_photos and mt.startswith("image/"):
            li = xbmcgui.ListItem(label=name)
            li.setArt({"thumb": share.thumb_url(fid)})
            xbmcplugin.addDirectoryItem(handle, share.stream_url(fid), li, isFolder=False)

    xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_NONE)
    xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_LABEL)
    xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_DATE)
    xbmcplugin.endOfDirectory(handle, cacheToDisc=False)


if __name__ == "__main__":
    if xbmcplugin:
        run(sys.argv)
    else:  # CLI smoke test: python default.py <share_url>
        s = Share(sys.argv[1])
        root = sort_items(s.list(s.root_id))
        print("root items:", len(root))
        for f in root[:5]:
            print(" ", f["mimeType"], f["name"])
