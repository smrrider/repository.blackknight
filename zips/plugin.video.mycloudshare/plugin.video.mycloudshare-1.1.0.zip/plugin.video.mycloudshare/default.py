# -*- coding: utf-8 -*-
"""My Cloud Share - browse and play a WD My Cloud OS5 public share link in Kodi.

Flow (mirrors the os5.mycloud.com web app):
  1. GET config.wdckeystone.com/config/v1/config        -> share service URL
  2. GET <share service>/v1/shares/<shareId>            -> shareToken + device relay URLs + root folder id
  3. GET <device>/sdk/v2/filesSearch/parents?ids=<id>   -> folder listing (Bearer shareToken, paginated)
  4. <device>/sdk/v3/files/<id>/content?access_token=   -> byte-range stream, served to Kodi through
     the localhost relay in resources/lib/mcsproxy.py (adds Content-Length so .mp4 can seek)

1.1.0 adds: friendly titles, newest-first sorting, All clips (cached recursive library), Recent,
Search, folder thumbnails, Play all in folder, Kodi-native watched/resume via stable plugin URLs.
"""
import json
import os
import sys
import time
import urllib.error
import urllib.parse

try:
    import xbmc
    import xbmcaddon
    import xbmcgui
    import xbmcplugin
    try:
        import xbmcvfs
    except ImportError:
        xbmcvfs = None
except ImportError:  # allows command-line testing outside Kodi
    xbmc = xbmcaddon = xbmcgui = xbmcplugin = xbmcvfs = None

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "resources", "lib"))
import mcsproxy  # noqa: E402
import mcslib  # noqa: E402
from mcslib import Share, is_video, natural_key, share_id_from  # noqa: E402,F401  (kept for CLI/tests)

ADDON_ID = "plugin.video.mycloudshare"
SHARE_CACHE_SECS = 2 * 3600  # share token is valid ~10 h; re-resolve every 2 h for listings
MAX_HISTORY = 10

# string ids (resources/language/resource.language.en_gb/strings.po)
S_ALL, S_RECENT, S_SEARCH, S_BROWSE, S_REFRESH = 30100, 30101, 30102, 30103, 30104
S_PLAYALL, S_NEWSEARCH, S_SEARCH_HEAD, S_CLEAR_HIST = 30105, 30106, 30107, 30108
S_BUILDING, S_SCANNING, S_UPDATED, S_NONE, S_OPEN_FAIL = 30109, 30110, 30111, 30112, 30113
S_COUNT, S_REMOVE_HIST, S_HTTP, S_FOLDER_PLOT = 30114, 30115, 30116, 30117

FALLBACK_STRINGS = {
    S_ALL: "All clips", S_RECENT: "Recent", S_SEARCH: "Search", S_BROWSE: "Browse folders",
    S_REFRESH: "Refresh library", S_PLAYALL: "Play all in folder", S_NEWSEARCH: "New search...",
    S_SEARCH_HEAD: "Search clips (name or date)", S_CLEAR_HIST: "Clear search history",
    S_BUILDING: "Building clip library", S_SCANNING: "Scanning folders: %d of %d - %d clips",
    S_UPDATED: "Library updated: %d clips", S_NONE: "No clips found",
    S_OPEN_FAIL: "Could not open the share:", S_COUNT: "%d clips",
    S_REMOVE_HIST: "Remove from history", S_HTTP: "Drive returned HTTP %s",
    S_FOLDER_PLOT: "%d clips in this folder",
}


def log(msg):
    if xbmc:
        xbmc.log("[MyCloudShare] %s" % msg, xbmc.LOGINFO)
    else:
        print("[log]", msg)


def translate(path):
    if xbmcvfs and hasattr(xbmcvfs, "translatePath"):
        return xbmcvfs.translatePath(path)
    return xbmc.translatePath(path)  # Kodi 18/19 fallback


def play_path(share, file_id, size=0, mime=""):
    """Prefer the localhost relay (adds Content-Length so Kodi can seek to the mp4 index);
    fall back to the direct WD URL with Kodi request headers."""
    upstream = share.stream_url(file_id)
    port = 0
    if xbmcgui:
        port = xbmcgui.Window(10000).getProperty(mcsproxy.PROP)
    if port and mcsproxy.alive(port):
        return mcsproxy.relay_url(port, upstream, size, mime), True
    log("relay not running; playing direct (mp4 seeking may fail)")
    return upstream + "|" + urllib.parse.urlencode({"User-Agent": mcslib.UA}), False


def set_video_info(li, title, c, plot=""):
    """Kodi 20+ InfoTag, with setInfo fallback for Kodi 19."""
    dur = int(c.get("dur") or 0)
    date = mcslib.kodi_date(c["ts"]) if c.get("ts") else ""
    try:
        tag = li.getVideoInfoTag()
        tag.setTitle(title)
        tag.setMediaType("video")
        if plot:
            tag.setPlot(plot)
        if dur:
            tag.setDuration(dur)
        if date:
            tag.setPremiered(date)
            tag.setFirstAired(date)
            tag.setYear(int(date[:4]))
        try:
            if c.get("w") and c.get("h") and hasattr(xbmc, "VideoStreamDetail"):
                tag.addVideoStream(xbmc.VideoStreamDetail(width=int(c["w"]), height=int(c["h"]),
                                                          duration=dur))
        except Exception:
            pass
    except AttributeError:  # Kodi 19
        info = {"title": title, "mediatype": "video"}
        if plot:
            info["plot"] = plot
        if dur:
            info["duration"] = dur
        if date:
            info.update({"premiered": date, "aired": date, "year": int(date[:4]),
                         "date": "%s.%s.%s" % (date[8:10], date[5:7], date[:4])})
        li.setInfo("video", info)
        if c.get("w") and c.get("h"):
            try:
                li.addStreamInfo("video", {"width": int(c["w"]), "height": int(c["h"]), "duration": dur})
            except Exception:
                pass


class App(object):
    def __init__(self, argv):
        self.base_url = argv[0]
        self.handle = int(argv[1]) if len(argv) > 1 and argv[1].lstrip("-").isdigit() else -1
        self.params = dict(urllib.parse.parse_qsl(argv[2].lstrip("?"))) if len(argv) > 2 else {}
        self.addon = xbmcaddon.Addon()
        self.icon = os.path.join(self.addon.getAddonInfo("path"), "icon.png")
        self.fanart = os.path.join(self.addon.getAddonInfo("path"), "fanart.jpg")
        self.profile = translate("special://profile/addon_data/%s/" % ADDON_ID)
        if not os.path.isdir(self.profile):
            os.makedirs(self.profile)
        self.lib_file = os.path.join(self.profile, "library.json")
        self.share_file = os.path.join(self.profile, "share.json")
        self.hist_file = os.path.join(self.profile, "searches.json")
        self._share = None

    # ---------------------------------------------------------------- settings / helpers
    def s(self, sid):
        txt = self.addon.getLocalizedString(sid)
        return txt or FALLBACK_STRINGS.get(sid, "")

    def setting(self, key, default=""):
        v = self.addon.getSetting(key)
        return v if v != "" else default

    def setting_int(self, key, default):
        try:
            return int(float(self.setting(key, default)))
        except ValueError:
            return default

    @property
    def friendly(self):
        return self.setting("title_style", "0") == "0"

    @property
    def order(self):
        idx = self.setting_int("sort_order", 0)
        return mcslib.SORTS[idx] if 0 <= idx < len(mcslib.SORTS) else "newest"

    def url(self, **kw):
        return self.base_url + "?" + urllib.parse.urlencode(kw)

    def share(self, fresh=False):
        if self._share is None:
            self._share = Share(self.setting("share_url"), direct=self.setting("connection") == "1",
                                log=log, cache_file=self.share_file,
                                cache_secs=0 if fresh else SHARE_CACHE_SECS)
        return self._share

    def notify(self, msg, ms=3000):
        xbmcgui.Dialog().notification("My Cloud Share", msg, self.icon, ms)

    # ---------------------------------------------------------------- library
    def library(self, force=False, build_if_missing=True, allow_stale=False):
        share = self.share()
        ttl = max(1, self.setting_int("cache_ttl", 6)) * 3600
        lib, fresh = mcslib.load_library(self.lib_file, share.share_id, ttl)
        if lib and not force and (fresh or allow_stale):
            return lib
        if not build_if_missing and not force:
            return lib
        bar = xbmcgui.DialogProgressBG()
        bar.create("My Cloud Share", self.s(S_BUILDING))

        def progress(done, total, nclips):
            pct = int(100.0 * done / total) if total else 0
            bar.update(pct, "My Cloud Share", self.s(S_SCANNING) % (done, total, nclips))

        t0 = time.time()
        try:
            new = mcslib.build_library(share, progress)
            mcslib.save_library(self.lib_file, new)
            log("library built: %d clips, %d folders in %.1fs"
                % (len(new["clips"]), len(new["folders"]), time.time() - t0))
            return new
        except Exception as e:
            log("library build failed: %r" % e)
            if lib:
                return lib  # serve the stale copy rather than nothing
            raise
        finally:
            bar.close()

    # ---------------------------------------------------------------- list items
    def menu_item(self, label, url, folder=True, label2="", thumb=None, ctx=None):
        li = xbmcgui.ListItem(label=label, label2=label2)
        li.setArt({"icon": thumb or self.icon, "thumb": thumb or self.icon, "fanart": self.fanart})
        items = list(ctx or [])
        if url.find("action=refresh") < 0:
            items.append((self.s(S_REFRESH), "RunPlugin(%s)" % self.url(action="refresh")))
        li.addContextMenuItems(items)
        xbmcplugin.addDirectoryItem(self.handle, url, li, isFolder=folder)

    def play_url(self, c):
        # Stable URL per clip: Kodi keys watched state and resume points on this exact path.
        return self.url(action="play", id=c["id"], size=c.get("size") or 0, mime=c.get("mime") or "")

    def clip_item(self, c, share):
        title = mcslib.friendly_title(c) if self.friendly else c["name"]
        bits = [c["name"]]
        if c.get("path"):
            bits.append("Folder: %s" % c["path"])
        if c.get("w") and c.get("h"):
            bits.append("%dx%d" % (c["w"], c["h"]))
        if c.get("size"):
            bits.append("%.1f MB" % (c["size"] / 1048576.0))
        li = xbmcgui.ListItem(label=title, label2=c["name"] if self.friendly else mcslib.friendly_title(c))
        set_video_info(li, title, c, "\n".join(bits))
        li.setArt({"thumb": share.thumb_url(c["id"]), "icon": "DefaultVideo.png", "fanart": self.fanart})
        li.setProperty("IsPlayable", "true")
        li.addContextMenuItems([
            (self.s(S_PLAYALL), "RunPlugin(%s)" % self.url(action="playall", folder=c["parent"], start=c["id"])),
            (self.s(S_REFRESH), "RunPlugin(%s)" % self.url(action="refresh")),
        ])
        return li

    def add_clips(self, clips, share):
        for c in clips:
            xbmcplugin.addDirectoryItem(self.handle, self.play_url(c), self.clip_item(c, share), isFolder=False)

    def end(self, content="videos", sort=True):
        xbmcplugin.setContent(self.handle, content)
        if sort:
            xbmcplugin.addSortMethod(self.handle, xbmcplugin.SORT_METHOD_UNSORTED)
            xbmcplugin.addSortMethod(self.handle, xbmcplugin.SORT_METHOD_LABEL)
            xbmcplugin.addSortMethod(self.handle, xbmcplugin.SORT_METHOD_DURATION)
        xbmcplugin.endOfDirectory(self.handle, cacheToDisc=False)

    # ---------------------------------------------------------------- views
    def nav_items(self, include_all=True):
        lib, _ = mcslib.load_library(self.lib_file, self.share().share_id, None)
        count = (self.s(S_COUNT) % len(lib["clips"])) if lib else ""
        if include_all:
            self.menu_item(self.s(S_ALL), self.url(action="all"), label2=count)
        self.menu_item(self.s(S_RECENT), self.url(action="recent"))
        self.menu_item(self.s(S_SEARCH), self.url(action="search"))
        self.menu_item(self.s(S_BROWSE), self.url(action="folder"))
        self.menu_item(self.s(S_REFRESH), self.url(action="refresh"), folder=False)

    def view_root(self):
        if self.setting("start_flat", "false") == "true":
            return self.view_all(nav=True)
        self.nav_items()
        self.end(content="files", sort=False)

    def view_all(self, nav=False):
        share = self.share()
        lib = self.library()
        if nav:
            self.nav_items(include_all=False)
        self.add_clips(mcslib.sort_clips(lib["clips"], self.order), share)
        self.end()

    def view_recent(self):
        share = self.share()
        lib = self.library()
        n = max(1, self.setting_int("recent_count", 50))
        self.add_clips(mcslib.sort_clips(lib["clips"], "newest")[:n], share)
        self.end()

    def history(self):
        try:
            with open(self.hist_file) as fh:
                return [q for q in json.load(fh) if q][:MAX_HISTORY]
        except Exception:
            return []

    def save_history(self, items):
        mcslib._atomic_write(self.hist_file, items[:MAX_HISTORY])

    def view_search_menu(self):
        self.menu_item("[B]%s[/B]" % self.s(S_NEWSEARCH), self.url(action="newsearch"))
        for q in self.history():
            self.menu_item(q, self.url(action="results", q=q), ctx=[
                (self.s(S_REMOVE_HIST), "RunPlugin(%s)" % self.url(action="delsearch", q=q))])
        if self.history():
            self.menu_item(self.s(S_CLEAR_HIST), self.url(action="clearsearch"), folder=False)
        self.end(content="files", sort=False)

    def new_search(self):
        q = xbmcgui.Dialog().input(self.s(S_SEARCH_HEAD)).strip()
        xbmcplugin.endOfDirectory(self.handle, succeeded=False, cacheToDisc=False)
        if not q:
            return
        hist = [q] + [h for h in self.history() if h.lower() != q.lower()]
        self.save_history(hist)
        xbmc.executebuiltin("Container.Update(%s,replace)" % self.url(action="results", q=q))

    def view_results(self):
        share = self.share()
        lib = self.library()
        hits = mcslib.search(lib["clips"], self.params.get("q", ""))
        if not hits:
            self.notify(self.s(S_NONE))
        self.add_clips(mcslib.sort_clips(hits, self.order), share)
        self.end()

    def view_folder(self):
        share = self.share()
        folder = self.params.get("id") or share.root_id
        # thumbnails/date order come from the cached library; never rebuild just to browse
        lib = self.library(build_if_missing=False, allow_stale=True)
        finfo = (lib or {}).get("folders", {})
        try:
            files = share.list(folder)
        except urllib.error.HTTPError as e:
            xbmcgui.Dialog().ok("My Cloud Share", self.s(S_HTTP) % e.code)
            xbmcplugin.endOfDirectory(self.handle, succeeded=False)
            return
        path = (finfo.get(folder) or {}).get("path", "")
        dirs = [f for f in files if mcslib.is_dir(f)]
        for f in mcslib.sort_folders(dirs, self.order, finfo):
            info = finfo.get(f["id"]) or {}
            thumb = share.thumb_url(info["thumb"]) if info.get("thumb") else "DefaultFolder.png"
            li = xbmcgui.ListItem(label=f["name"], label2=(self.s(S_COUNT) % info["count"]) if info else "")
            li.setArt({"thumb": thumb, "icon": "DefaultFolder.png", "fanart": self.fanart})
            if info:
                try:
                    li.getVideoInfoTag().setPlot(self.s(S_FOLDER_PLOT) % info["count"])
                except AttributeError:
                    li.setInfo("video", {"plot": self.s(S_FOLDER_PLOT) % info["count"]})
            li.addContextMenuItems([
                (self.s(S_PLAYALL), "RunPlugin(%s)" % self.url(action="playall", folder=f["id"])),
                (self.s(S_REFRESH), "RunPlugin(%s)" % self.url(action="refresh")),
            ])
            xbmcplugin.addDirectoryItem(self.handle, self.url(action="folder", id=f["id"]), li, isFolder=True)
        clips = [mcslib.to_clip(f, folder, path) for f in files if not mcslib.is_dir(f) and is_video(f)]
        self.add_clips(mcslib.sort_clips(clips, self.order), share)
        if self.setting("show_photos", "false") == "true":
            for f in files:
                if f.get("mimeType", "").startswith("image/") and not mcslib.is_dir(f):
                    li = xbmcgui.ListItem(label=f.get("name", "?"))
                    li.setArt({"thumb": share.thumb_url(f["id"])})
                    xbmcplugin.addDirectoryItem(self.handle, share.stream_url(f["id"]), li, isFolder=False)
        self.end()

    # ---------------------------------------------------------------- actions
    def play(self):
        share = self.share(fresh=True)
        try:
            size = int(self.params.get("size") or 0)
        except ValueError:
            size = 0
        mime = self.params.get("mime") or ""
        path, _ = play_path(share, self.params["id"], size, mime)
        li = xbmcgui.ListItem(path=path)
        if mime.startswith("video/"):
            li.setMimeType(mime)
        li.setContentLookup(False)
        xbmcplugin.setResolvedUrl(self.handle, True, li)

    def playlist_clips(self):
        folder = self.params.get("folder") or self.share().root_id
        lib = self.library(build_if_missing=False, allow_stale=True)
        if lib and folder in lib["folders"]:
            clips = mcslib.folder_clips(lib, folder)
        else:
            clips = [mcslib.to_clip(f, folder, "") for f in self.share().list(folder)
                     if not mcslib.is_dir(f) and is_video(f)]
        return mcslib.sort_clips(clips, self.order)

    def play_all(self):
        share = self.share()
        clips = self.playlist_clips()
        if not clips:
            self.notify(self.s(S_NONE))
            return
        pl = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
        pl.clear()
        start = 0
        for i, c in enumerate(clips):
            if c["id"] == self.params.get("start"):
                start = i
            pl.add(self.play_url(c), self.clip_item(c, share))
        log("play all: %d clips, starting at %d" % (len(clips), start))
        xbmc.Player().play(pl, startpos=start)

    def refresh(self):
        lib = self.library(force=True)
        self.notify(self.s(S_UPDATED) % len(lib["clips"]))
        xbmc.executebuiltin("Container.Refresh")

    def run(self):
        action = self.params.get("action", "")
        try:
            if action == "play":
                return self.play()
            if action == "playall":
                return self.play_all()
            if action == "refresh":
                return self.refresh()
            if action == "delsearch":
                self.save_history([h for h in self.history() if h != self.params.get("q")])
                return xbmc.executebuiltin("Container.Refresh")
            if action == "clearsearch":
                self.save_history([])
                return xbmc.executebuiltin("Container.Refresh")
            if action == "all":
                return self.view_all()
            if action == "recent":
                return self.view_recent()
            if action == "search":
                return self.view_search_menu()
            if action == "newsearch":
                return self.new_search()
            if action == "results":
                return self.view_results()
            if action == "folder":
                return self.view_folder()
            return self.view_root()
        except Exception as e:
            log("error in %r: %r" % (action or "root", e))
            xbmcgui.Dialog().ok("My Cloud Share", "%s\n%s" % (self.s(S_OPEN_FAIL), e))
            if self.handle >= 0:
                if action == "play":
                    xbmcplugin.setResolvedUrl(self.handle, False, xbmcgui.ListItem())
                else:
                    xbmcplugin.endOfDirectory(self.handle, succeeded=False)


def run(argv):
    App(argv).run()


if __name__ == "__main__":
    if xbmcplugin:
        run(sys.argv)
    else:  # CLI smoke test: python default.py <share_url>
        s = Share(sys.argv[1])
        root = s.list(s.root_id)
        print("root items:", len(root))
        for f in root[:5]:
            print(" ", f["mimeType"], f["name"])
