# -*- coding: utf-8 -*-
"""Tiny localhost relay that makes WD My Cloud streams seekable in Kodi.

Why: the WD cloud relay answers large GET / Range requests with HTTP/2 and no
Content-Length header (only Content-Range). Kodi's curl reader takes the file
size from Content-Length only, so it sees size 0, marks the stream unseekable,
and an .mp4 whose moov index sits at the end of the file (camera clips) cannot
be opened. AVI/MPG play front-to-back, which is why they work.

This relay sits on 127.0.0.1, forwards Range requests upstream, and answers
with the correct Content-Length / Content-Range / Accept-Ranges headers.
"""
import re
import socket
import threading
import urllib.error
import urllib.parse
import urllib.request

try:
    from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
except ImportError:  # Python < 3.7
    from http.server import BaseHTTPRequestHandler, HTTPServer
    from socketserver import ThreadingMixIn

    class ThreadingHTTPServer(ThreadingMixIn, HTTPServer):
        daemon_threads = True

UA = "Kodi-MyCloudShare/1.0.1"
PORTS = range(52481, 52491)
PROP = "plugin.video.mycloudshare.proxyport"
CHUNK = 256 * 1024
TIMEOUT = 30
ALLOWED_PATH = re.compile(r"^(/[^?]*)?/sdk/v3/files/[A-Za-z0-9]+/content$")


def _allowed(url):
    p = urllib.parse.urlsplit(url)
    return p.scheme == "https" and bool(ALLOWED_PATH.match(p.path))


def _upstream(url, rng):
    req = urllib.request.Request(url, headers={"User-Agent": UA, "Range": rng,
                                               "Accept-Encoding": "identity"})
    return urllib.request.urlopen(req, timeout=TIMEOUT)


def probe_size(url):
    """Total size from Content-Range of a 1-byte request."""
    with _upstream(url, "bytes=0-0") as r:
        m = re.search(r"/(\d+)\s*$", r.headers.get("Content-Range", ""))
        return int(m.group(1)) if m else 0, r.headers.get("Content-Type", "")


class Handler(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"
    server_version = "MyCloudShareRelay"

    def log_message(self, fmt, *args):  # keep Kodi's log quiet
        pass

    def _params(self):
        q = urllib.parse.parse_qs(urllib.parse.urlsplit(self.path).query)
        url = (q.get("u") or [""])[0]
        try:
            size = int((q.get("s") or ["0"])[0])
        except ValueError:
            size = 0
        mime = (q.get("m") or [""])[0]
        return url, size, mime

    def _resolve(self):
        url, size, mime = self._params()
        if not _allowed(url):
            self.send_error(403)
            return None
        if size <= 0 or not mime:
            try:
                psize, pmime = probe_size(url)
            except urllib.error.HTTPError as e:
                self.send_error(e.code)
                return None
            except Exception:
                self.send_error(502)
                return None
            size = size if size > 0 else psize
            mime = mime or pmime
        if size <= 0:
            self.send_error(502, "size unknown")
            return None
        return url, size, mime or "application/octet-stream"

    def _range(self, size):
        h = self.headers.get("Range", "")
        m = re.match(r"^\s*bytes=(\d*)-(\d*)\s*$", h)
        if not m or (m.group(1) == "" and m.group(2) == ""):
            return None
        a, b = m.group(1), m.group(2)
        if a == "":  # suffix range: last N bytes
            n = int(b)
            return max(0, size - n), size - 1
        start = int(a)
        end = min(int(b), size - 1) if b else size - 1
        return start, end

    def do_HEAD(self):
        r = self._resolve()
        if not r:
            return
        _, size, mime = r
        self.send_response(200)
        self.send_header("Content-Type", mime)
        self.send_header("Content-Length", str(size))
        self.send_header("Accept-Ranges", "bytes")
        self.end_headers()

    def do_GET(self):
        r = self._resolve()
        if not r:
            return
        url, size, mime = r
        rng = self._range(size)
        partial = rng is not None
        start, end = rng if partial else (0, size - 1)
        if start >= size or start > end:
            self.send_response(416)
            self.send_header("Content-Range", "bytes */%d" % size)
            self.send_header("Content-Length", "0")
            self.end_headers()
            return
        try:
            up = _upstream(url, "bytes=%d-%d" % (start, end))
        except urllib.error.HTTPError as e:
            self.send_error(e.code)
            return
        except Exception:
            self.send_error(502)
            return
        length = end - start + 1
        with up:
            self.send_response(206 if partial else 200)
            self.send_header("Content-Type", mime)
            self.send_header("Content-Length", str(length))
            self.send_header("Accept-Ranges", "bytes")
            if partial:
                self.send_header("Content-Range", "bytes %d-%d/%d" % (start, end, size))
            self.end_headers()
            sent = 0
            try:
                while sent < length:
                    buf = up.read(min(CHUNK, length - sent))
                    if not buf:
                        break
                    self.wfile.write(buf)
                    sent += len(buf)
            except (socket.error, ConnectionError):
                pass  # Kodi closed the socket (seek/stop) or upstream dropped
            if sent < length:
                self.close_connection = True


def start(log=None):
    """Bind the first free port in PORTS; return (server, port) or (None, 0)."""
    for port in PORTS:
        try:
            srv = ThreadingHTTPServer(("127.0.0.1", port), Handler)
        except OSError:
            continue
        srv.daemon_threads = True
        t = threading.Thread(target=srv.serve_forever, name="mcs-relay")
        t.daemon = True
        t.start()
        if log:
            log("relay listening on 127.0.0.1:%d" % port)
        return srv, port
    if log:
        log("relay could not bind any port in %s-%s" % (PORTS[0], PORTS[-1]))
    return None, 0


def alive(port):
    if not port:
        return False
    try:
        s = socket.create_connection(("127.0.0.1", int(port)), timeout=1)
        s.close()
        return True
    except Exception:
        return False


def relay_url(port, upstream, size=0, mime=""):
    q = {"u": upstream}
    if size:
        q["s"] = str(size)
    if mime:
        q["m"] = mime
    return "http://127.0.0.1:%d/stream?%s" % (int(port), urllib.parse.urlencode(q))
