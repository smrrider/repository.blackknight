# -*- coding: utf-8 -*-
"""My Cloud Share core: WD share access, clip metadata, library cache, sort and search.

No Kodi imports here, so it can be tested from the command line.
"""
import calendar
import json
import os
import re
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
from concurrent.futures import ThreadPoolExecutor

CONFIG_URL = "https://config.wdckeystone.com/config/v1/config"
UA = "Kodi-MyCloudShare/1.1.1"
TIMEOUT = 20
PAGE = 500
FIELDS = "id,name,mimeType,size,mTime,video,image"
VIDEO_EXT = (".mp4", ".m4v", ".mov", ".mkv", ".avi", ".mpg", ".mpeg", ".mts", ".m2ts",
             ".ts", ".wmv", ".3gp", ".vob", ".flv", ".webm", ".dv", ".mod", ".tod")
MONTHS = ("Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec")
MONTHS_LONG = ("January", "February", "March", "April", "May", "June", "July", "August",
               "September", "October", "November", "December")
LIB_VERSION = 1
MIN_EPOCH = 631152000  # 1990-01-01; older "dates" are camera defaults, not real


# ------------------------------------------------------------------ http
def http_json(url, token=None, tries=3):
    headers = {"User-Agent": UA, "Accept": "application/json"}
    if token:
        headers["Authorization"] = "Bearer " + token
    last = None
    for attempt in range(tries):
        try:
            req = urllib.request.Request(url, headers=headers)
            with urllib.request.urlopen(req, timeout=TIMEOUT) as resp:
                return json.loads(resp.read().decode("utf-8"))
        except urllib.error.HTTPError as e:
            if e.code < 500:
                raise
            last = e
        except (urllib.error.URLError, OSError, ValueError) as e:  # timeouts, TLS resets
            last = e
        time.sleep(1.5 * (attempt + 1))
    raise last


def share_id_from(url):
    m = re.search(r"share/([0-9a-fA-F-]{36})", url or "")
    if not m:
        raise ValueError("That doesn't look like an os5.mycloud.com/action/share/... link")
    return m.group(1)


class Share(object):
    """Resolves a public share: token (valid ~10 h), relay base URL and root folder id."""

    def __init__(self, share_url, direct=False, log=None, cache_file=None, cache_secs=0):
        self.share_id = share_id_from(share_url)
        log = log or (lambda m: None)
        if cache_file and cache_secs and self._load(cache_file, cache_secs, direct):
            return
        cfg = http_json(CONFIG_URL)
        urls = cfg["data"]["componentMap"]["cloud.service.urls"]
        share_svc = urls["service.share.url"]
        data = http_json("%s/v1/shares/%s" % (share_svc, self.share_id))
        if data.get("error") or not data.get("data"):
            raise RuntimeError("Share not found or link was deleted")
        d = data["data"]
        self.token = d["shareToken"]
        self.root_id = d["fileIds"][0]
        self.root_is_dir = d.get("metadata", {}).get("filetype", "").endswith("dir")
        dev = d.get("device") or {}
        if not dev.get("cloudConnected"):
            raise RuntimeError("The My Cloud drive is offline or not cloud-connected")
        net = dev.get("network", {})
        self.base = net["proxyURL"]
        if direct and net.get("portForwardURL"):
            try:
                http_json(net["portForwardURL"] + "/sdk/v2/files/%s?fields=id" % self.root_id, self.token, tries=1)
                self.base = net["portForwardURL"]
                log("using direct connection")
            except Exception as e:  # noqa
                log("direct connection failed (%s), using WD relay" % e)
        if cache_file:
            self._save(cache_file, direct)

    def _load(self, path, max_age, direct):
        try:
            with open(path, "r") as fh:
                c = json.load(fh)
            if (c.get("share_id") == self.share_id and c.get("direct") == direct
                    and time.time() - c.get("at", 0) < max_age):
                self.token, self.root_id, self.base = c["token"], c["root_id"], c["base"]
                self.root_is_dir = c.get("root_is_dir", True)
                return True
        except Exception:
            pass
        return False

    def _save(self, path, direct):
        try:
            _atomic_write(path, {"share_id": self.share_id, "direct": direct, "at": time.time(),
                                 "token": self.token, "root_id": self.root_id, "base": self.base,
                                 "root_is_dir": self.root_is_dir})
        except Exception:
            pass

    def list(self, folder_id):
        items, token = [], ""
        while True:
            q = {"ids": folder_id, "limit": PAGE, "fields": FIELDS, "orderBy": "name", "order": "asc"}
            if token:
                q["pageToken"] = token
            j = http_json(self.base + "/sdk/v2/filesSearch/parents?" + urllib.parse.urlencode(q), self.token)
            items.extend(j.get("files", []))
            token = j.get("pageToken") or ""
            if not token or not j.get("files"):
                return items

    def stream_url(self, file_id):
        return "%s/sdk/v3/files/%s/content?access_token=%s" % (self.base, file_id, self.token)

    def thumb_url(self, file_id):
        return ("%s/sdk/v2/files/%s/content?minWidth=640&minHeight=360&allowOriginal=false"
                "&allowTemporary=true&access_token=%s" % (self.base, file_id, self.token))


def _atomic_write(path, obj):
    d = os.path.dirname(path)
    if d and not os.path.isdir(d):
        os.makedirs(d)
    tmp = path + ".tmp"
    with open(tmp, "w") as fh:
        json.dump(obj, fh, separators=(",", ":"))
    os.replace(tmp, path)


# ------------------------------------------------------------------ clip metadata
def is_dir(f):
    return f.get("mimeType", "").endswith("dir")


def is_video(f):
    mt = f.get("mimeType", "")
    if mt.startswith(("image/", "audio/")):  # e.g. JPEGs saved with an .MP4 name
        return False
    return mt.startswith("video/") or f.get("name", "").lower().endswith(VIDEO_EXT)


_ISO = re.compile(r"^(\d{4})-(\d\d)-(\d\d)[T ](\d\d):(\d\d):(\d\d)(?:\.\d+)?(Z|[+-]\d\d:?\d\d)?$")


def parse_iso(s):
    """ISO-8601 -> UTC epoch seconds (0 if unparseable). Works on Python 3.6+."""
    m = _ISO.match((s or "").strip())
    if not m:
        return 0
    y, mo, d, h, mi, se = (int(x) for x in m.groups()[:6])
    try:
        e = calendar.timegm((y, mo, d, h, mi, se, 0, 0, 0))
    except (ValueError, OverflowError):
        return 0
    tz = m.group(7)
    if tz and tz != "Z":
        sign = 1 if tz[0] == "+" else -1
        tz = tz[1:].replace(":", "")
        e -= sign * (int(tz[:2]) * 3600 + int(tz[2:]) * 60)
    return e


def clip_epoch(f):
    """Recorded time: video metadata date, then image date, then file modified time."""
    for s in ((f.get("video") or {}).get("date"), (f.get("image") or {}).get("date"), f.get("mTime")):
        e = parse_iso(s)
        if e >= MIN_EPOCH:
            return e
    return 0


def to_clip(f, parent_id, path):
    v = f.get("video") or {}
    try:
        dur = int(round(float(v.get("duration") or 0)))
    except (TypeError, ValueError):
        dur = 0
    return {"id": f["id"], "name": f.get("name", "?"), "size": int(f.get("size") or 0),
            "mime": f.get("mimeType", ""), "ts": clip_epoch(f), "dur": dur,
            "w": v.get("width") or 0, "h": v.get("height") or 0,
            "parent": parent_id, "path": path}


def fmt_date(ts):
    lt = time.localtime(ts)
    return "%s %d, %d" % (MONTHS[lt.tm_mon - 1], lt.tm_mday, lt.tm_year)


def fmt_time(ts):
    lt = time.localtime(ts)
    h = lt.tm_hour % 12 or 12
    return "%d:%02d %s" % (h, lt.tm_min, "AM" if lt.tm_hour < 12 else "PM")


def fmt_dur(sec):
    sec = int(sec or 0)
    h, rem = divmod(sec, 3600)
    m, s = divmod(rem, 60)
    return "%d:%02d:%02d" % (h, m, s) if h else "%d:%02d" % (m, s)


def friendly_title(c):
    parts = []
    if c.get("ts"):
        parts += [fmt_date(c["ts"]), fmt_time(c["ts"])]
    if c.get("dur"):
        parts.append(fmt_dur(c["dur"]))
    return " \u00b7 ".join(parts) if parts else c.get("name", "?")


def kodi_date(ts):
    """YYYY-MM-DD in local time for InfoTag premiered/aired."""
    lt = time.localtime(ts)
    return "%04d-%02d-%02d" % (lt.tm_year, lt.tm_mon, lt.tm_mday)


def kodi_datetime(ts):
    """YYYY-MM-DD HH:MM:SS in local time (dateadded / setDateTime)."""
    lt = time.localtime(ts)
    return "%04d-%02d-%02d %02d:%02d:%02d" % (lt.tm_year, lt.tm_mon, lt.tm_mday, lt.tm_hour, lt.tm_min, lt.tm_sec)


def natural_key(name):
    return [int(t) if t.isdigit() else t.lower() for t in re.split(r"(\d+)", name or "")]


SORTS = ("newest", "oldest", "name")


def sort_clips(clips, order="newest"):
    if order == "oldest":
        return sorted(clips, key=lambda c: (c["ts"] == 0, c["ts"], natural_key(c["name"])))
    if order == "name":
        return sorted(clips, key=lambda c: (natural_key(c["name"]), c["ts"]))
    return sorted(clips, key=lambda c: (c["ts"] == 0, -c["ts"], natural_key(c["name"])))


def sort_folders(folders, order, summary=None):
    """folders: list of {id,name}. Date orders use each folder's newest/oldest clip from the library."""
    summary = summary or {}
    if order in ("newest", "oldest") and summary:
        def key(f):
            s = summary.get(f["id"]) or {}
            ts = s.get("latest" if order == "newest" else "earliest") or 0
            return (ts == 0, -ts if order == "newest" else ts, natural_key(f["name"]))
        return sorted(folders, key=key)
    return sorted(folders, key=lambda f: natural_key(f["name"]))


# ------------------------------------------------------------------ search
def search_text(c):
    bits = [c["name"], c.get("path", "")]
    if c.get("ts"):
        lt = time.localtime(c["ts"])
        bits += [fmt_date(c["ts"]),
                 "%s %d %d" % (MONTHS_LONG[lt.tm_mon - 1], lt.tm_mday, lt.tm_year),
                 "%04d-%02d-%02d" % (lt.tm_year, lt.tm_mon, lt.tm_mday),
                 "%d/%d/%d" % (lt.tm_mon, lt.tm_mday, lt.tm_year),
                 "%02d/%02d/%04d" % (lt.tm_mon, lt.tm_mday, lt.tm_year)]
    return " ".join(bits).lower().replace(",", "")


def search(clips, query):
    """Every word must match. Short numbers (a day like the 5 in 'nov 5 2009') must match a whole word."""
    toks = [t for t in re.split(r"[\s,]+", (query or "").lower()) if t]
    if not toks:
        return []
    hits = []
    for c in clips:
        text = search_text(c)
        words = None
        ok = True
        for t in toks:
            if t.isdigit() and len(t) <= 2:
                if words is None:
                    words = set(re.split(r"[^0-9a-z]+", text))
                if t not in words and t.lstrip("0") not in words:
                    ok = False
                    break
            elif t not in text:
                ok = False
                break
        if ok:
            hits.append(c)
    return hits


# ------------------------------------------------------------------ library (recursive walk + cache)
def build_library(share, progress=None, workers=6):
    """Walk every folder under the share root. Returns the library dict."""
    clips, folders = [], {}
    root = share.root_id
    folders[root] = {"name": "", "parent": "", "path": "", "subs": []}
    lock = threading.Lock()
    done = [0]

    def visit(fid):
        info = folders[fid]
        items = share.list(fid)
        subs, mine = [], []
        for f in items:
            if is_dir(f):
                path = (info["path"] + "/" + f["name"]) if info["path"] else f["name"]
                subs.append((f["id"], {"name": f["name"], "parent": fid, "path": path, "subs": []}))
            elif is_video(f):
                mine.append(to_clip(f, fid, info["path"]))
        with lock:
            clips.extend(mine)
            for sid, sinfo in subs:
                folders[sid] = sinfo
                info["subs"].append(sid)
            done[0] += 1
        return [sid for sid, _ in subs]

    level = [root]
    with ThreadPoolExecutor(max_workers=workers) as pool:
        while level:
            nxt = []
            for subs in pool.map(visit, level):
                nxt.extend(subs)
            if progress:
                progress(done[0], done[0] + len(nxt), len(clips))
            level = nxt

    # per-folder summary for thumbnails and date ordering (subtree aware)
    by_parent = {}
    for c in clips:
        by_parent.setdefault(c["parent"], []).append(c)
    summary = {}

    def summarize(fid):
        own = by_parent.get(fid, [])
        dated = [c for c in own if c["ts"]]
        thumb = min(dated, key=lambda c: c["ts"])["id"] if dated else (
            sorted(own, key=lambda c: natural_key(c["name"]))[0]["id"] if own else "")
        latest = max([c["ts"] for c in own] or [0])
        earliest = min([c["ts"] for c in dated] or [0])
        count = len(own)
        for sid in sorted(folders[fid]["subs"], key=lambda s: natural_key(folders[s]["name"])):
            s = summarize(sid)
            thumb = thumb or s["thumb"]
            latest = max(latest, s["latest"])
            earliest = min(x for x in (earliest, s["earliest"]) if x) if (earliest or s["earliest"]) else 0
            count += s["count"]
        summary[fid] = {"thumb": thumb, "latest": latest, "earliest": earliest,
                        "count": count, "direct": len(own)}
        return summary[fid]

    summarize(root)
    for fid, info in folders.items():
        info.update(summary.get(fid, {}))
    return {"v": LIB_VERSION, "share_id": share.share_id, "root": root, "built": time.time(),
            "clips": clips, "folders": folders}


def load_library(path, share_id, max_age=None):
    """Returns (lib, fresh). lib is None if missing/unreadable/other share."""
    try:
        with open(path, "r") as fh:
            lib = json.load(fh)
    except Exception:
        return None, False
    if lib.get("v") != LIB_VERSION or lib.get("share_id") != share_id:
        return None, False
    fresh = max_age is None or (time.time() - lib.get("built", 0)) < max_age
    return lib, fresh


def save_library(path, lib):
    _atomic_write(path, lib)


def folder_clips(lib, folder_id, recursive_if_empty=True):
    own = [c for c in lib["clips"] if c["parent"] == folder_id]
    if own or not recursive_if_empty:
        return own
    ids, stack = set(), [folder_id]
    while stack:
        f = stack.pop()
        ids.add(f)
        stack.extend((lib["folders"].get(f) or {}).get("subs", []))
    return [c for c in lib["clips"] if c["parent"] in ids]
