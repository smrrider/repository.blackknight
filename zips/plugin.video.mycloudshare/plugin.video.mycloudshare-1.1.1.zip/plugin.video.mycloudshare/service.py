# -*- coding: utf-8 -*-
"""Background service: runs the localhost relay that makes .mp4 streams seekable."""
import os
import sys

import xbmc
import xbmcaddon
import xbmcgui

sys.path.insert(0, os.path.join(xbmcaddon.Addon().getAddonInfo("path"), "resources", "lib"))
import mcsproxy  # noqa: E402


def log(msg):
    xbmc.log("[MyCloudShare] %s" % msg, xbmc.LOGINFO)


def main():
    home = xbmcgui.Window(10000)
    srv, port = mcsproxy.start(log)
    if srv:
        home.setProperty(mcsproxy.PROP, str(port))
    monitor = xbmc.Monitor()
    while not monitor.abortRequested():
        if monitor.waitForAbort(5):
            break
    home.clearProperty(mcsproxy.PROP)
    if srv:
        srv.shutdown()
        srv.server_close()


if __name__ == "__main__":
    main()
