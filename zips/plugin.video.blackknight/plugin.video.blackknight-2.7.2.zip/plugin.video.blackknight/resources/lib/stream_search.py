"""
stream_search.py - "Search Streaming Services" for Black Knight (2.7.2).

Type a title once, see where it streams on the Captain's services, and play
it inside Black Knight through the same Real-Debrid source path the Movies
and TV menus use. Live TV is unchanged.

  * "Where to watch" comes from TMDB's watch-provider data (JustWatch-backed),
    using the TMDB key entered in Settings.
  * Clicking a movie result opens BKA's existing movie_sources route (TMDB id).
    Clicking a TV result opens the existing tv_seasons listing. The official
    app is only launched from the long-press context menu ("Open in <app>")
    or from the "Search each app" footer.
  * Live TV results come from the Channels DVR guide on BKMS and play the
    Captain's own DVR stream in Kodi, or open the channel in the YouTube TV app
    through the existing bkytvlaunch helper.

Per-device overrides: drop a services.json into the addon profile folder
(addon_data/plugin.video.blackknight/services.json) to change a service's
package list or search link without a rebuild. Format:
  {"netflix": {"packages": ["com.netflix.ninja"],
               "search_uri": "https://www.netflix.com/search?q={q}"}}
"""

import os
import re
import json
import time
import threading

import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs

try:
    from urllib.parse import quote, quote_plus
    from urllib.request import urlopen, Request
except ImportError:                                     # pragma: no cover
    from urllib import quote, quote_plus
    from urllib2 import urlopen, Request

_ADDON = xbmcaddon.Addon()
_ID    = _ADDON.getAddonInfo("id")
_LOG   = "[BlackKnight/StreamSearch]"

HISTORY_FILE  = "stream_search_history.json"
OVERRIDE_FILE = "services.json"
HISTORY_MAX   = 20
TITLE_LIMIT   = 12            # TMDB titles checked for providers per search
LIVE_LIMIT    = 25            # guide rows shown per search

HELPER_ID     = "plugin.video.bkytvlaunch"
YOUTUBE_ADDON = "plugin.video.youtube"

# -- Service registry -------------------------------------------------------------
# tmdb_ids: TMDB provider ids (US) for the subscription tiers of each service.
# match:    regex on TMDB provider_name as a fallback when an id is new.
# packages: Fire TV first, then Android TV / phone builds. First installed wins.
# search_uri: VIEW link the app is asked to open; {q} = URL-encoded query.
#             None -> open the app only (no known public search link).
SERVICES = [
    {"key": "netflix",   "name": "Netflix",     "tmdb_ids": [8, 1796],
     "match": r"^netflix",
     "packages": ["com.netflix.ninja", "com.netflix.mediaclient"],
     "search_uri": "https://www.netflix.com/search?q={q}"},
    {"key": "prime",     "name": "Prime Video", "tmdb_ids": [9, 119, 2100],
     "match": r"^amazon prime video",
     "packages": ["com.amazon.firebat", "com.amazon.amazonvideo.livingroom",
                  "com.amazon.avod.thirdpartyclient", "com.amazon.avod"],
     "search_uri": None},
    {"key": "disney",    "name": "Disney+",     "tmdb_ids": [337],
     "match": r"^disney (plus|\+)",
     "packages": ["com.disney.disneyplus"],
     "search_uri": "https://www.disneyplus.com/search?q={q}"},
    {"key": "hulu",      "name": "Hulu",        "tmdb_ids": [15],
     "match": r"^hulu",
     "packages": ["com.hulu.plus", "com.hulu.livingroomplus"],
     "search_uri": "https://www.hulu.com/search?q={q}"},
    {"key": "peacock",   "name": "Peacock",     "tmdb_ids": [386, 387],
     "match": r"^peacock",
     "packages": ["com.peacock.peacockfiretv", "com.peacocktv.peacockandroid"],
     "search_uri": None},
    {"key": "paramount", "name": "Paramount+",  "tmdb_ids": [531, 2303, 2616],
     "match": r"^paramount(\+| plus)",
     "packages": ["com.cbs.ott", "com.cbs.app"],
     "search_uri": None},
    {"key": "appletv",   "name": "Apple TV+",   "tmdb_ids": [350],
     "match": r"^apple tv( plus|\+)$",
     "packages": ["com.apple.atve.amazon.appletv", "com.apple.atve.androidtv.appletv"],
     "search_uri": "https://tv.apple.com/search?term={q}"},
    {"key": "max",       "name": "Max",         "tmdb_ids": [1899, 384],
     "match": r"^(hbo )?max$",
     "packages": ["com.wbd.stream", "com.hbo.hbonow"],
     "search_uri": "https://play.max.com/search?q={q}"},
    {"key": "tubi",      "name": "Tubi",        "tmdb_ids": [73],
     "match": r"^tubi",
     "packages": ["com.tubitv", "com.tubitv.ott"],
     "search_uri": "https://tubitv.com/search/{qp}"},
]

# Search-only rows (no TMDB provider grouping).
YOUTUBE_APP = {"key": "youtube", "name": "YouTube",
               "packages": ["com.amazon.firetv.youtube", "com.google.android.youtube.tv",
                            "com.google.android.youtube"],
               "search_uri": "https://www.youtube.com/results?search_query={q}"}

_SAFE_PKG = re.compile(r"^[A-Za-z][A-Za-z0-9_]*(\.[A-Za-z0-9_]+)+$")


def log(msg, level=xbmc.LOGINFO):
    xbmc.log("{} {}".format(_LOG, msg), level)


def build_url(action, **kwargs):
    params = "?action={}".format(action)
    for k, v in kwargs.items():
        params += "&{}={}".format(k, quote_plus(str(v)))
    return "plugin://{}{}".format(_ID, params)


def _profile_path(name):
    base = xbmcvfs.translatePath(_ADDON.getAddonInfo("profile"))
    if not xbmcvfs.exists(base + "/"):
        xbmcvfs.mkdirs(base)
    return os.path.join(base, name)


def _setting(key, default=""):
    try:
        val = _ADDON.getSetting(key)
    except Exception:
        val = ""
    return val if val not in (None, "") else default


def _setting_bool(key, default):
    try:
        raw = _ADDON.getSetting(key)
    except Exception:
        return default
    if raw == "":
        return default
    return raw.lower() == "true"


# -- Services (with per-device override) -----------------------------------------

def services():
    """SERVICES merged with addon_data/.../services.json, if present."""
    merged = [dict(s) for s in SERVICES] + [dict(YOUTUBE_APP)]
    path = _profile_path(OVERRIDE_FILE)
    if xbmcvfs.exists(path):
        try:
            with open(path, "r") as fh:
                over = json.load(fh)
            for svc in merged:
                o = over.get(svc["key"]) or {}
                if isinstance(o.get("packages"), list):
                    svc["packages"] = [p for p in o["packages"] if _SAFE_PKG.match(p or "")]
                if "search_uri" in o:
                    svc["search_uri"] = o["search_uri"] or None
            log("services.json override applied")
        except Exception as e:
            log("bad services.json: {}".format(e), xbmc.LOGWARNING)
    return merged


def service_by_key(key):
    for s in services():
        if s["key"] == key:
            return s
    return None


def match_service(provider_id, provider_name):
    """Map one TMDB provider entry to a service key, or None.

    Add-on subscriptions sold inside another app ("Max Amazon Channel",
    "Paramount+ Roku Premium Channel") are left out on purpose: they would
    open the wrong app.
    """
    name = (provider_name or "").strip().lower()
    if " channel" in name:
        return None
    for s in SERVICES:
        if provider_id in s["tmdb_ids"]:
            return s["key"]
    for s in SERVICES:
        if re.search(s["match"], name):
            return s["key"]
    return None


# -- Installed-app detection ------------------------------------------------------

_installed_cache = {}


def installed_packages():
    """Set of installed Android package names, or None when it can't be read
    (not Android, or Kodi couldn't list androidapp://). None means "assume
    everything is installed" so the hand-off is still offered."""
    if "pkgs" in _installed_cache:
        return _installed_cache["pkgs"]
    pkgs = None
    if xbmc.getCondVisibility("System.Platform.Android"):
        try:
            resp = json.loads(xbmc.executeJSONRPC(json.dumps({
                "jsonrpc": "2.0", "id": 1, "method": "Files.GetDirectory",
                "params": {"directory": "androidapp://sources/apps/", "media": "files"}})))
            files = (resp.get("result") or {}).get("files") or []
            found = set()
            for f in files:
                m = re.search(r"androidapp://sources/apps/([A-Za-z0-9_.]+?)(\.apk)?/?$",
                              f.get("file", ""))
                if m:
                    found.add(m.group(1))
            pkgs = found or None
        except Exception as e:
            log("app list failed: {}".format(e), xbmc.LOGWARNING)
    _installed_cache["pkgs"] = pkgs
    return pkgs


def resolve_package(svc):
    pkgs = installed_packages()
    cands = [p for p in svc.get("packages", []) if _SAFE_PKG.match(p or "")]
    if pkgs is None:
        return cands[0] if cands else ""
    for p in cands:
        if p in pkgs:
            return p
    return ""


# -- Intents ---------------------------------------------------------------------

def search_link(svc, query):
    tpl = svc.get("search_uri")
    if not tpl or not query:
        return ""
    link = tpl.replace("{q}", quote(query, safe="")).replace("{qp}", quote(query, safe=""))
    # quote() already removed spaces, quotes and commas; double-check anyway so
    # nothing can break Kodi's builtin parser.
    if any(c in link for c in '"\\ \r\n,()'):
        return ""
    return link


def builtin_for(pkg, link=""):
    if not _SAFE_PKG.match(pkg or ""):
        raise ValueError("bad package {!r}".format(pkg))
    if link:
        return 'StartAndroidActivity({},android.intent.action.VIEW,,"{}")'.format(pkg, link)
    return "StartAndroidActivity({})".format(pkg)


def launch_service(svc_key, query, mode=""):
    """Open the service's app, searching for `query` when possible."""
    svc = service_by_key(svc_key)
    if not svc:
        _notify("Unknown service")
        return False
    if not xbmc.getCondVisibility("System.Platform.Android"):
        _notify("App hand-off only works on the Fire TV / Android boxes", error=True)
        return False
    pkg = resolve_package(svc)
    if not pkg:
        _notify("{} app is not installed on this box".format(svc["name"]), error=True)
        return False
    app_only = (mode == "app") or _setting("stream_search_launch", "0") == "1"
    link = "" if app_only else search_link(svc, query)
    builtin = builtin_for(pkg, link)
    log("launch {} -> {}".format(svc_key, builtin))
    _stop_kodi_playback()
    if link:
        _notify("Searching {} for: {}".format(svc["name"], query))
    else:
        _notify("Opening {} - search for: {}".format(svc["name"], query), ms=6000)
    xbmc.executebuiltin(builtin)
    return True


def _stop_kodi_playback():
    try:
        p = xbmc.Player()
        if p.isPlaying():
            p.stop()
    except Exception:
        pass


def _notify(msg, error=False, ms=3500):
    icon = xbmcgui.NOTIFICATION_ERROR if error else xbmcgui.NOTIFICATION_INFO
    xbmcgui.Dialog().notification("Black Knight Search", msg, icon, ms)


# -- Search history ---------------------------------------------------------------

def load_history():
    path = _profile_path(HISTORY_FILE)
    try:
        if xbmcvfs.exists(path):
            with open(path, "r") as fh:
                data = json.load(fh)
            return [q for q in data if isinstance(q, str) and q.strip()][:HISTORY_MAX]
    except Exception as e:
        log("history read failed: {}".format(e), xbmc.LOGWARNING)
    return []


def save_history(items):
    try:
        with open(_profile_path(HISTORY_FILE), "w") as fh:
            json.dump(items[:HISTORY_MAX], fh)
    except Exception as e:
        log("history write failed: {}".format(e), xbmc.LOGWARNING)


def remember(query):
    q = query.strip()
    if not q:
        return
    items = [h for h in load_history() if h.lower() != q.lower()]
    save_history([q] + items)


def forget(query):
    save_history([h for h in load_history() if h.lower() != (query or "").lower()])


# -- Where-to-watch lookup ---------------------------------------------------------

def _title_of(r):
    return r.get("title") or r.get("name") or ""


def _year_of(r):
    return str(r.get("release_date") or r.get("first_air_date") or "")[:4]


def find_titles(tmdb, query, region):
    """TMDB search + watch providers for the top titles.

    Returns (titles, error). Each title dict: tmdb_id, media_type, title, year,
    plot, poster, fanart, on (service_key -> label tag), elsewhere (list of
    "Provider (rent)" strings).
    """
    try:
        results, _ = tmdb.search_multi(query, page=1)
    except Exception as e:
        return [], str(e)
    results = [r for r in results if r.get("media_type") in ("movie", "tv")][:TITLE_LIMIT]

    titles = []
    for r in results:
        titles.append({
            "tmdb_id": r.get("id"), "media_type": r.get("media_type"),
            "title": _title_of(r), "year": _year_of(r),
            "plot": r.get("overview", ""),
            "poster": tmdb.poster_url(r.get("poster_path")) if r.get("poster_path") else "",
            "fanart": tmdb.fanart_url(r.get("backdrop_path")) if r.get("backdrop_path") else "",
            "on": {}, "elsewhere": [],
        })

    def fetch(t):
        try:
            wp = tmdb.watch_providers(t["tmdb_id"], t["media_type"], region)
        except Exception as e:
            log("providers failed for {}: {}".format(t["title"], e), xbmc.LOGDEBUG)
            return
        for kind in ("flatrate", "free", "ads"):
            for p in wp.get(kind, []) or []:
                key = match_service(p.get("provider_id"), p.get("provider_name"))
                if not key:
                    continue
                name = (p.get("provider_name") or "").lower()
                tag = "free" if kind in ("free", "ads") else ("with ads" if "with ads" in name else "")
                # prefer the ad-free tier tag when a title is on several tiers
                rank = {"": 0, "with ads": 1, "free": 2}
                if key not in t["on"] or rank[tag] < rank[t["on"][key]]:
                    t["on"][key] = tag
        seen = set()
        for kind, word in (("flatrate", "subscription"), ("free", "free"), ("ads", "free"),
                           ("rent", "rent"), ("buy", "buy")):
            for p in wp.get(kind, []) or []:
                if match_service(p.get("provider_id"), p.get("provider_name")):
                    continue
                label = "{} ({})".format(p.get("provider_name", "?"), word)
                if label not in seen:
                    seen.add(label)
                    t["elsewhere"].append(label)

    threads = [threading.Thread(target=fetch, args=(t,)) for t in titles]
    for th in threads:
        th.daemon = True
        th.start()
    for th in threads:
        th.join(15)
    return titles, ""


# -- Live TV (Channels DVR guide) --------------------------------------------------

def _norm(s):
    return re.sub(r"[^a-z0-9]", "", (s or "").lower())


def cdvr_base():
    host = _setting("cdvr_host", "192.168.1.92").strip()
    port = _setting("cdvr_port", "8089").strip() or "8089"
    if not re.match(r"^[A-Za-z0-9.\-]+$", host) or not port.isdigit():
        return ""
    return "http://{}:{}".format(host, int(port))


def _http_json(url, timeout=8):
    req = Request(url, headers={"Accept": "application/json"})
    return json.loads(urlopen(req, timeout=timeout).read().decode("utf-8"))


def find_airings(query, hours=12):
    """Guide airings whose title or episode title contains the query.

    Uses Channels DVR's /devices/ANY/guide JSON. Returns (rows, error) where
    rows are dicts: number, channel, title, episode, start, stop, image, plot.
    """
    base = cdvr_base()
    if not base:
        return [], "Channels DVR host not set"
    now = int(time.time())
    try:
        data = _http_json("{}/devices/ANY/guide?time={}&duration={}".format(
            base, now, int(hours) * 3600))
    except Exception as e:
        log("guide fetch failed: {}".format(e), xbmc.LOGWARNING)
        return [], "guide unavailable (Channels DVR not reachable)"

    want = _norm(query)
    if not want:
        return [], ""
    rows, seen = [], set()
    for entry in data if isinstance(data, list) else []:
        ch = entry.get("Channel") or {}
        number = str(ch.get("Number") or "")
        chname = ch.get("Name") or ch.get("CallSign") or number
        callsign = ch.get("CallSign") or ""
        for a in entry.get("Airings") or []:
            title = a.get("Title") or ""
            ep = a.get("EpisodeTitle") or ""
            if want not in _norm(title) and want not in _norm(ep):
                continue
            start = int(a.get("Time") or 0)
            stop = start + int(a.get("Duration") or 0)
            if stop <= now:
                continue
            num = str(a.get("Channel") or number)
            dedupe = (_norm(title), _norm(ep), start, _norm(chname))
            if dedupe in seen:
                continue
            seen.add(dedupe)
            rows.append({"number": num, "channel": chname, "callsign": callsign,
                         "title": title, "episode": ep, "start": start, "stop": stop,
                         "image": a.get("Image") or "", "plot": a.get("Summary") or ""})
    rows.sort(key=lambda r: (r["start"] > now, r["start"], r["channel"]))
    return rows[:LIVE_LIMIT], ""


def helper_key_for(channel_name, callsign=""):
    """bkytvlaunch channel key for a guide channel, or "" if no match."""
    if not xbmc.getCondVisibility("System.HasAddon({})".format(HELPER_ID)):
        return ""
    keys = {}
    for base in ("special://profile/addon_data/{}/".format(HELPER_ID),
                 "special://home/addons/{}/".format(HELPER_ID)):
        path = xbmcvfs.translatePath(base + "channels.json")
        if xbmcvfs.exists(path):
            try:
                with open(path, "r") as fh:
                    keys = json.load(fh)
                break
            except Exception:
                pass
    lookup = dict((_norm(k), k) for k in keys)
    for cand in (channel_name, callsign):
        k = lookup.get(_norm(cand))
        if k:
            return k
    return ""


def watch_live(number, channel, title, callsign=""):
    """Let the Captain pick how to watch a guide result."""
    opts, acts = [], []
    base = cdvr_base()
    if base and number:
        opts.append("Watch in Kodi (Channels DVR - ch {})".format(number))
        acts.append("dvr")
    key = helper_key_for(channel, callsign)
    if key:
        opts.append("Open {} in the YouTube TV app".format(channel))
        acts.append("ytv")
    if not opts:
        _notify("No way to tune {} from here".format(channel), error=True)
        return
    idx = 0 if len(opts) == 1 else xbmcgui.Dialog().select("{} - {}".format(channel, title), opts)
    if idx < 0:
        return
    if acts[idx] == "dvr":
        url = "{}/devices/ANY/channels/{}/stream.mpg".format(base, quote(str(number), safe="."))
        li = xbmcgui.ListItem(label="{} - {}".format(channel, title))
        log("play DVR channel {} {}".format(number, url))
        xbmc.Player().play(url, li)
    else:
        log("YTV handoff ch={}".format(key))
        xbmc.executebuiltin("RunPlugin(plugin://{}/?ch={})".format(HELPER_ID, quote_plus(key)))


# -- Listings ---------------------------------------------------------------------

def _header(handle, text, url="", art=None):
    li = xbmcgui.ListItem(label="[B][COLOR gold]{}[/COLOR][/B]".format(text))
    if art:
        li.setArt(art)
    xbmcplugin.addDirectoryItem(handle, url or build_url("noop"), li, isFolder=False)


def _end(handle, content="files"):
    xbmcplugin.setContent(handle, content)
    xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_NONE)
    xbmcplugin.endOfDirectory(handle, cacheToDisc=False)


def build_root(handle):
    icon = _ADDON.getAddonInfo("icon")
    li = xbmcgui.ListItem(label="[B]New search...[/B]")
    li.setArt({"icon": "DefaultAddonsSearch.png", "thumb": "DefaultAddonsSearch.png"})
    xbmcplugin.addDirectoryItem(handle, build_url("stream_search_new"), li, isFolder=False)
    history = load_history()
    for q in history:
        li = xbmcgui.ListItem(label=q)
        li.setArt({"icon": icon, "thumb": "DefaultAddonsSearch.png"})
        li.addContextMenuItems([
            ("Remove from recent searches", "RunPlugin({})".format(build_url("stream_search_forget", query=q))),
            ("Clear recent searches", "RunPlugin({})".format(build_url("stream_search_clear"))),
        ])
        xbmcplugin.addDirectoryItem(handle, build_url("stream_search_results", query=q), li, isFolder=True)
    if history:
        li = xbmcgui.ListItem(label="[COLOR grey]Clear recent searches[/COLOR]")
        xbmcplugin.addDirectoryItem(handle, build_url("stream_search_clear"), li, isFolder=False)
    _end(handle)


def _fmt_time(ts):
    lt = time.localtime(ts)
    hour = lt.tm_hour % 12 or 12
    return "{}:{:02d} {}".format(hour, lt.tm_min, "AM" if lt.tm_hour < 12 else "PM")


def _when(row, now):
    if row["start"] <= now < row["stop"]:
        return "[COLOR red]LIVE[/COLOR] until {}".format(_fmt_time(row["stop"]))
    day = time.strftime("%a", time.localtime(row["start"]))
    today = time.strftime("%a", time.localtime(now))
    return "{}{}".format("" if day == today else day + " ", _fmt_time(row["start"]))


def _year_int(t):
    year = t.get("year") or 0
    try:
        return int(year) if str(year).isdigit() else 0
    except (TypeError, ValueError):
        return 0


def playback_url(t):
    """Plugin URL into BKA's existing movie play or TV season listing.

    Returns (url, is_folder). Movies are playable (movie_sources + TMDB id).
    TV shows open tv_seasons with the TMDB id so episodes use the same
    Real-Debrid path as the normal TV menus.
    """
    year = _year_int(t)
    tmdb_id = t.get("tmdb_id") or ""
    title = t.get("title") or ""
    if t.get("media_type") == "tv":
        return build_url("tv_seasons", tmdb_id=tmdb_id,
                         show_title=title, show_year=year), True
    return build_url("movie_sources", tmdb_id=tmdb_id,
                     title=title, year=year), False


def _where_list(t, by_key):
    names = [by_key[k]["name"] for k in (t.get("on") or {}) if k in by_key]
    names.extend(t.get("elsewhere") or [])
    return names


def _open_in_ctx(svc_key, title):
    return ("Open in {}".format(services_name(svc_key)),
            "RunPlugin({})".format(build_url("stream_launch", svc=svc_key, query=title)))


def services_name(key):
    for s in services():
        if s["key"] == key:
            return s["name"]
    return key


def _title_context(t, by_key, svc_key=None):
    """Long-press only: Open in <app>, Where else to watch."""
    ctx = []
    title = t.get("title") or ""
    if svc_key:
        ctx.append(_open_in_ctx(svc_key, title))
    else:
        for key in (t.get("on") or {}):
            if key in by_key:
                ctx.append(_open_in_ctx(key, title))
    where = _where_list(t, by_key)
    if where:
        ctx.append(("Where else to watch", "RunPlugin({})".format(
            build_url("stream_where", title=title, where=" | ".join(where)))))
    return ctx


def add_title_item(handle, t, by_key, svc_key=None, extra_grey=""):
    """Add one movie/TV row whose default click is BKA playback."""
    kind = "Series" if t.get("media_type") == "tv" else "Movie"
    tag = extra_grey
    label = "    {}{}  [COLOR grey]{}{}[/COLOR]".format(
        t.get("title") or "",
        " ({})".format(t["year"]) if t.get("year") else "",
        kind,
        " - {}".format(tag) if tag else "")
    li = xbmcgui.ListItem(label=label)
    li.setArt({"poster": t.get("poster") or "", "thumb": t.get("poster") or "",
               "fanart": t.get("fanart") or ""})
    _plot(li, t.get("title") or "", t.get("plot") or "")
    url, is_folder = playback_url(t)
    if not is_folder:
        li.setProperty("IsPlayable", "true")
    ctx = _title_context(t, by_key, svc_key=svc_key)
    if ctx:
        li.addContextMenuItems(ctx)
    xbmcplugin.addDirectoryItem(handle, url, li, isFolder=is_folder)


def build_results(handle, query, tmdb, region, svc_order):
    """Search results: All results first, then by service, then live TV.

    Default click on a movie or TV title plays (or lists seasons) inside
    BKA. Opening the official app is context-menu only.
    """
    titles, terr = [], ""
    rows, lerr = [], ""
    want_live = _setting_bool("stream_search_live", True)

    box = {}

    def _live():
        hours = 12
        try:
            hours = max(1, min(48, int(_setting("stream_search_hours", "12"))))
        except ValueError:
            pass
        box["live"] = find_airings(query, hours)

    th = None
    if want_live:
        th = threading.Thread(target=_live)
        th.daemon = True
        th.start()
    titles, terr = find_titles(tmdb, query, region)
    if th:
        th.join(20)
        rows, lerr = box.get("live", ([], "guide timed out"))

    by_key = dict((s["key"], s) for s in services())
    pkgs_known = installed_packages() is not None
    shown_any = False

    # 1. All results (unique titles that listed on at least one of his services)
    on_services = [t for t in titles if t.get("on")]
    if on_services:
        shown_any = True
        _header(handle, "All results  -  {}".format(len(on_services)))
        for t in on_services:
            services_tag = ", ".join(by_key[k]["name"] for k in svc_order if k in t["on"])
            add_title_item(handle, t, by_key, extra_grey=services_tag)

    # 2. Same titles grouped by service (default click is still BKA playback)
    for key in svc_order:
        svc = by_key.get(key)
        hits = [t for t in titles if key in t.get("on", {})]
        if not svc or not hits:
            continue
        shown_any = True
        installed = bool(resolve_package(svc))
        note = "" if installed or not pkgs_known else "  [COLOR grey](app not installed)[/COLOR]"
        _header(handle, "{}  -  {} result{}{}".format(svc["name"], len(hits),
                                                    "" if len(hits) == 1 else "s", note),
                build_url("stream_launch", svc=key, query=query))
        for t in hits:
            tag = t["on"][key]
            add_title_item(handle, t, by_key, svc_key=key, extra_grey=tag)

    # 3. Live / upcoming on TV (unchanged)
    if want_live:
        now = int(time.time())
        if rows:
            shown_any = True
            _header(handle, "Live TV - next {} h (Channels DVR)".format(
                _setting("stream_search_hours", "12")))
            for r in rows:
                label = "    {}  [COLOR grey]{}[/COLOR]  {}{}".format(
                    _when(r, now), r["channel"], r["title"],
                    " - {}".format(r["episode"]) if r["episode"] else "")
                li = xbmcgui.ListItem(label=label)
                if r["image"]:
                    li.setArt({"thumb": r["image"], "fanart": r["image"]})
                _plot(li, r["title"], r["plot"])
                xbmcplugin.addDirectoryItem(handle, build_url(
                    "stream_live", number=r["number"], channel=r["channel"],
                    callsign=r["callsign"], title=r["title"]), li, isFolder=False)
        elif lerr:
            _header(handle, "Live TV: {}".format(lerr[:80]))

    # 4. Titles not on his services — still playable in BKA via Real-Debrid
    others = [t for t in titles if not t.get("on") and t.get("elsewhere")]
    if others:
        _header(handle, "Not on your services")
        for t in others:
            where = ", ".join(t["elsewhere"][:3]) or "no US streaming listing"
            add_title_item(handle, t, by_key, extra_grey=where)
    elif terr:
        _header(handle, "TMDB: {}".format(terr[:80]))

    # 5. Hand the raw query to each app's own search (explicit app launch)
    _header(handle, "Search each app for \"{}\"".format(query))
    if xbmc.getCondVisibility("System.HasAddon({})".format(YOUTUBE_ADDON)):
        li = xbmcgui.ListItem(label="    YouTube (Kodi add-on)")
        xbmcplugin.addDirectoryItem(
            handle, "plugin://{}/kodion/search/query/?q={}".format(YOUTUBE_ADDON, quote_plus(query)),
            li, isFolder=True)
    for key in svc_order + ["youtube"]:
        svc = by_key.get(key)
        if not svc or (pkgs_known and not resolve_package(svc)):
            continue
        how = "search" if svc.get("search_uri") else "open app"
        li = xbmcgui.ListItem(label="    {}  [COLOR grey]({})[/COLOR]".format(svc["name"], how))
        xbmcplugin.addDirectoryItem(handle, build_url("stream_launch", svc=key, query=query),
                                    li, isFolder=False)

    if not shown_any:
        _notify("No streaming matches for \"{}\"".format(query))
    _end(handle, content="videos")



def _plot(li, title, plot):
    try:
        tag = li.getVideoInfoTag()
        tag.setTitle(title or "")
        tag.setPlot(plot or "")
    except AttributeError:
        li.setInfo("video", {"title": title or "", "plot": plot or ""})


def show_where(title, where):
    parts = [p for p in (where or "").split(" | ") if p]
    body = "\n".join(parts) if parts else "TMDB has no US streaming, rent or buy listing for this title."
    xbmcgui.Dialog().textviewer("Where to watch: {}".format(title), body)
