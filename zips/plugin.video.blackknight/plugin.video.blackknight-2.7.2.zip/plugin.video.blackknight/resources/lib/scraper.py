"""
scraper.py — Torrentio stream scraper + Real-Debrid resolver.

Torrentio is a free, open Stremio addon that indexes public torrent
sites and serves magnet links via a simple JSON API.
When an RD API key is supplied it pre-filters for RD-cached content
and returns direct download URLs — no polling needed.

Torrentio API format
--------------------
Movie : https://torrentio.strem.fun/{options}/stream/movie/{imdb_id}.json
Episode: https://torrentio.strem.fun/{options}/stream/series/{imdb_id}:{s}:{e}.json

With RD:  options = "realdebrid=<api_key>"
Without:  options = "" (returns infoHash only — needs RD magnet flow)
"""

import re
import json
import xbmc

try:
    from urllib.request import urlopen, Request
    from urllib.error import URLError, HTTPError
    from urllib.parse import quote
except ImportError:
    from urllib2 import urlopen, Request, URLError, HTTPError
    from urllib import quote

from realdebrid import RealDebrid, RealDebridError

TORRENTIO_BASE = "https://torrentio.strem.fun"

# Regex to extract rough quality label from torrent name
_QUALITY_RE = re.compile(
    r"(2160p|4K|UHD|1080p|720p|480p|HDTV|WEB-?DL|BluRay|BDRip|DVDRip)",
    re.IGNORECASE,
)

# Languages/tags to avoid (optional — filter out non-English if desired)
_FOREIGN_RE = re.compile(r"\b(FRENCH|GERMAN|SPANISH|ITALIAN|DUBBED|VOSTA)\b", re.IGNORECASE)


class ScraperError(Exception):
    pass


def _fetch_json(url):
    xbmc.log("[BlackKnight/Scraper] GET {}".format(url), xbmc.LOGDEBUG)
    try:
        req = Request(url, headers={"User-Agent": "BlackKnight/1.0", "Accept": "application/json"})
        resp = urlopen(req, timeout=15)
        return json.loads(resp.read().decode("utf-8"))
    except HTTPError as e:
        raise ScraperError("HTTP {}: {}".format(e.code, url))
    except URLError as e:
        raise ScraperError("Scraper unreachable: {}".format(e.reason))
    except Exception as e:
        raise ScraperError("Scraper request failed: {}".format(e))


def _quality_label(name):
    """Extract a short quality string from a torrent name."""
    m = _QUALITY_RE.search(name or "")
    if m:
        q = m.group(1).upper()
        # Normalise
        q = q.replace("2160P", "4K").replace("UHD", "4K")
        q = q.replace("WEBDL", "WEB-DL").replace("WEBL", "WEB-DL")
        return q
    return "?"


def _size_label(size_bytes):
    """Human-readable file size."""
    if not size_bytes:
        return ""
    gb = size_bytes / (1024 ** 3)
    if gb >= 1:
        return "{:.1f} GB".format(gb)
    mb = size_bytes / (1024 ** 2)
    return "{:.0f} MB".format(mb)


def _build_options(rd_api_key=None):
    """Build the Torrentio options path segment."""
    if rd_api_key:
        return "realdebrid={}".format(quote(rd_api_key, safe=""))
    return ""


class Stream:
    """Represents a resolved or resolvable stream source."""
    __slots__ = ("label", "url", "info_hash", "magnet", "quality", "size", "cached")

    def __init__(self, label, url="", info_hash="", magnet="",
                 quality="?", size="", cached=False):
        self.label     = label
        self.url       = url        # Direct play URL (already resolved)
        self.info_hash = info_hash  # For RD magnet flow fallback
        self.magnet    = magnet
        self.quality   = quality
        self.size      = size
        self.cached    = cached     # True = already cached on RD

    def __repr__(self):
        return "<Stream {} cached={} url={}>".format(self.quality, self.cached, bool(self.url))


class Scraper:
    """Fetch stream sources from Torrentio and resolve via Real-Debrid."""

    def __init__(self, rd_api_key=None, max_results=20, cached_only=True, english_only=False):
        self.rd_api_key    = rd_api_key
        self.max_results   = max_results
        self.cached_only   = cached_only
        self.english_only  = english_only
        self._rd           = RealDebrid(rd_api_key) if rd_api_key else None

    # ── Public API ────────────────────────────────────────────────────────────

    def get_movie_streams(self, imdb_id):
        """
        Fetch stream sources for a movie.
        imdb_id: string like 'tt1234567'
        Returns list of Stream objects, best quality first.
        """
        options = _build_options(self.rd_api_key)
        url = "{}/{}/stream/movie/{}.json".format(TORRENTIO_BASE, options, imdb_id)
        return self._fetch_streams(url)

    def get_episode_streams(self, imdb_id, season, episode):
        """
        Fetch stream sources for a TV episode.
        Returns list of Stream objects.
        """
        options = _build_options(self.rd_api_key)
        url = "{}/{}/stream/series/{}:{}:{}.json".format(
            TORRENTIO_BASE, options, imdb_id, int(season), int(episode)
        )
        return self._fetch_streams(url)

    def resolve_stream(self, stream):
        """
        Take a Stream object and return a direct playable URL.

        Priority order:
          1. Torrentio URL -> extract hash from URL -> RD API directly (skip Torrentio)
          2. Direct URL    -> return as-is
          3. info_hash     -> RD magnet flow
        """
        if stream.url and "torrentio.strem.fun" in stream.url:
            # Torrentio resolve URLs always contain the info_hash in the path:
            # /resolve/realdebrid/{api_key}/{info_hash}/...
            # Extract it from the URL if not already on the stream object.
            info_hash = stream.info_hash or _extract_hash_from_torrentio_url(stream.url)

            if info_hash and self._rd:
                xbmc.log("[BlackKnight/Scraper] RD direct resolve for hash: {}".format(info_hash), xbmc.LOGDEBUG)
                try:
                    magnet = stream.magnet or _build_magnet(info_hash, stream.label)
                    return self._rd.resolve_magnet(magnet, info_hash=info_hash)
                except RealDebridError as e:
                    raise ScraperError("RD resolve failed: {}".format(e))

            # No hash and no RD — Torrentio redirect won't work (returns 502)
            raise ScraperError("Cannot resolve Torrentio stream without Real-Debrid key")

        if stream.url:
            return stream.url

        if stream.info_hash and self._rd:
            magnet = stream.magnet or _build_magnet(stream.info_hash, stream.label)
            xbmc.log("[BlackKnight/Scraper] RD magnet resolve: {}".format(stream.info_hash), xbmc.LOGDEBUG)
            try:
                return self._rd.resolve_magnet(magnet, info_hash=stream.info_hash)
            except RealDebridError as e:
                raise ScraperError("RD resolve failed: {}".format(e))

        raise ScraperError("No playable URL and no RD key configured")

    # ── Internal ──────────────────────────────────────────────────────────────

    def _fetch_streams(self, url):
        data = _fetch_json(url)
        raw_streams = data.get("streams", [])
        streams = []

        for s in raw_streams:
            name  = s.get("name", "")
            title = s.get("title", "")
            url   = s.get("url", "")           # Set by Torrentio when RD pre-resolves
            hash_ = s.get("infoHash", "")
            idx   = s.get("fileIdx", 0)
            behavior = s.get("behaviorHints", {})

            if self.english_only and _FOREIGN_RE.search(title):
                continue

            # Early cache filter — skip non-cached streams if cached_only is set
            is_cached = bool(url)
            if self.cached_only and not is_cached:
                continue

            quality = _quality_label(title or name)

            # Parse size from title (Torrentio includes it as "👤 X 💾 Y GB ⚙️ ...")
            size = ""
            size_m = re.search(r"💾\s*([\d.,]+\s*(?:GB|MB))", title)
            if size_m:
                size = size_m.group(1).strip()

            cached = is_cached  # Torrentio only sets url for RD-cached content

            # Build magnet if we have a hash
            magnet = ""
            if hash_:
                magnet = _build_magnet(hash_, title)

            label = "{quality} — {size}".format(
                quality=quality,
                size=size or "?",
            )
            if cached:
                label = "[RD] " + label

            streams.append(Stream(
                label=label,
                url=url,
                info_hash=hash_,
                magnet=magnet,
                quality=quality,
                size=size,
                cached=cached,
            ))

            if len(streams) >= self.max_results:
                break

        # Sort: RD cached first, then by quality preference
        quality_order = {"4K": 0, "2160P": 0, "1080P": 1, "720P": 2, "480P": 3}
        streams.sort(key=lambda s: (
            0 if s.cached else 1,
            quality_order.get(s.quality.upper(), 9),
        ))
        return streams


def _extract_hash_from_torrentio_url(url):
    """
    Torrentio resolve URLs embed the info_hash in the path:
      /resolve/realdebrid/{api_key}/{info_hash}/...
    Returns the 40-char hex hash, or "" if not found.
    """
    m = re.search(r"/resolve/realdebrid/[^/]+/([0-9a-f]{40})/", url, re.IGNORECASE)
    return m.group(1).lower() if m else ""


def _build_magnet(info_hash, name=""):
    """Construct a magnet URI from an info hash."""
    trackers = [
        "udp://tracker.opentrackr.org:1337/announce",
        "udp://open.stealth.si:80/announce",
        "udp://tracker.torrent.eu.org:451/announce",
        "udp://tracker.cyberia.is:6969/announce",
    ]
    magnet = "magnet:?xt=urn:btih:{}".format(info_hash)
    if name:
        magnet += "&dn={}".format(quote(name, safe=""))
    for t in trackers:
        magnet += "&tr={}".format(quote(t, safe=""))
    return magnet
