"""
player_monitor.py — Inline Trakt scrobble monitor for Black Knight.

Called AFTER xbmcplugin.setResolvedUrl(). The plugin process stays alive
while KODI plays the stream in parallel. monitor_playback() blocks until
playback ends, firing scrobble events along the way.
"""
import time
import xbmc


class TraktPlayerMonitor(xbmc.Player):

    def __init__(self, trakt, np):
        """
        trakt : Trakt instance
        np    : now-playing dict (same format as now_playing.json handoff)
        """
        super(TraktPlayerMonitor, self).__init__()
        self._trakt     = trakt
        self._np        = np
        self._started   = False
        self._scrobbled = False
        self._last_hb   = 0

    # ── Progress ───────────────────────────────────────────────────────────────

    def _pct(self):
        try:
            total = self.getTotalTime()
            return min(int(self.getTime() / total * 100), 100) if total > 0 else 0
        except Exception:
            return 0

    # ── KODI callbacks ─────────────────────────────────────────────────────────

    def onAVStarted(self):
        if not self._started:
            self._started = True
            self._last_hb = time.time()
            self._trakt.scrobble_start(self._np, progress=1)
            self._maybe_seek()

    def onPlayBackStarted(self):
        if not self._started:
            self._started = True
            self._last_hb = time.time()
            self._trakt.scrobble_start(self._np, progress=1)

    def onPlayBackPaused(self):
        self._trakt.scrobble_pause(self._np, progress=self._pct())

    def onPlayBackResumed(self):
        self._trakt.scrobble_start(self._np, progress=self._pct())
        self._last_hb = time.time()

    def onPlayBackStopped(self):
        if not self._scrobbled:
            pct = self._pct()
            if pct >= 80:
                self._trakt.scrobble_stop(self._np, progress=100)
            else:
                self._trakt.scrobble_pause(self._np, progress=pct)
            self._scrobbled = True

    def onPlayBackEnded(self):
        if not self._scrobbled:
            self._trakt.scrobble_stop(self._np, progress=95)
            self._scrobbled = True

    def onPlayBackError(self):
        self._scrobbled = True  # don't scrobble on error

    # ── Seek to resume point ───────────────────────────────────────────────────

    def _maybe_seek(self):
        resume = self._np.get("resume_seconds", 0)
        if not resume:
            return
        # Wait briefly for the stream to be seekable
        for _ in range(10):
            try:
                if self.getTotalTime() > 10:
                    self.seekTime(resume)
                    xbmc.log("[BlackKnight/Trakt] Seeked to {}s".format(resume), xbmc.LOGINFO)
                    return
            except Exception:
                pass
            xbmc.sleep(500)

    # ── Main loop ──────────────────────────────────────────────────────────────

    def monitor_playback(self, start_timeout=15):
        """
        Block until playback ends. Call this after setResolvedUrl.
        Sends a Trakt heartbeat every 60 seconds while playing.
        """
        monitor  = xbmc.Monitor()
        deadline = time.time() + start_timeout

        # Wait for KODI to start playing
        while not self.isPlaying():
            if monitor.abortRequested() or time.time() > deadline:
                return
            xbmc.sleep(500)

        # Block while playing, sending heartbeats
        while self.isPlaying() and not monitor.abortRequested():
            now = time.time()
            if self._started and now - self._last_hb >= 60:
                self._trakt.scrobble_start(self._np, progress=self._pct())
                self._last_hb = now
            xbmc.sleep(5000)
