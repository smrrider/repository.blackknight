"""
channels_dvr.py - Channels DVR API wrapper with full EPG/guide support.
"""
import json
import time
import re
import xml.etree.ElementTree as ET
import xbmc

try:
    from urllib.request import urlopen, Request
    from urllib.error import URLError, HTTPError
    from urllib.parse import urlencode
except ImportError:
    from urllib2 import urlopen, Request, URLError, HTTPError
    from urllib import urlencode


class ChannelsDVRError(Exception):
    pass


class ChannelsDVR:

    def __init__(self, host, port, timeout=10):
        self.base = "http://{}:{}".format(host, int(port))
        self.timeout = timeout

    # ── Low-level ─────────────────────────────────────────────────────────────

    def _get(self, path, params=None):
        url = self.base + path
        if params:
            url += "?" + urlencode(params)
        xbmc.log("[BlackKnight] GET {}".format(url), xbmc.LOGDEBUG)
        try:
            req = Request(url, headers={"Accept": "application/json"})
            response = urlopen(req, timeout=self.timeout)
            raw = response.read()
            ct = response.headers.get("Content-Type", "")
            if "xml" in ct:
                return raw
            return json.loads(raw.decode("utf-8"))
        except HTTPError as e:
            raise ChannelsDVRError("HTTP {}: {}".format(e.code, path))
        except URLError as e:
            raise ChannelsDVRError("Cannot reach server: {}".format(e.reason))
        except Exception as e:
            raise ChannelsDVRError("Request failed: {}".format(e))

    def _delete(self, path):
        url = self.base + path
        try:
            req = Request(url)
            req.get_method = lambda: "DELETE"
            urlopen(req, timeout=self.timeout)
        except (HTTPError, URLError) as e:
            raise ChannelsDVRError(str(e))

    # ── Server ────────────────────────────────────────────────────────────────

    def get_status(self):
        return self._get("/dvr")

    def is_online(self):
        try:
            self.get_status()
            return True
        except ChannelsDVRError:
            return False

    # ── Channels ─────────────────────────────────────────────────────────────

    def get_channels(self):
        data = self._get("/api/v1/channels")
        return data if isinstance(data, list) else data.get("channels", [])

    def get_channel_logo_url(self, channel_number):
        return "{}/images/channels/{}/logo".format(self.base, channel_number)

    def get_stream_url(self, channel_number, use_hls=False):
        ext = "stream.m3u8" if use_hls else "stream.mpg"
        return "{}/devices/ANY/channels/{}/{}".format(self.base, channel_number, ext)

    # ── EPG / Guide ───────────────────────────────────────────────────────────

    def get_epg(self, duration=10800):
        """
        Fetch and parse guide data. Returns:
          { channel_key: [ program_dict, ... ] }
        where channel_key is the channel number string (or callsign as fallback).
        Each program_dict has:
          title, description, category,
          start_ts, stop_ts, start_hhmm, stop_hhmm,
          progress (0-100), is_current (bool)
        Tries JSON API first, falls back to XMLTV.
        """
        # Try JSON guide API (Channels DVR >= 2023 builds)
        try:
            data = self._get("/api/v1/guide", params={"duration": duration})
            if isinstance(data, list) and data:
                return self._parse_json_guide(data)
        except ChannelsDVRError:
            pass

        # Fall back to XMLTV
        try:
            raw = self._get("/devices/ANY/guide.xml")
            if isinstance(raw, bytes):
                return self._parse_xmltv(raw)
        except Exception as e:
            xbmc.log("[BlackKnight] EPG fallback failed: {}".format(e), xbmc.LOGWARNING)

        return {}

    def _parse_json_guide(self, data):
        now = time.time()
        result = {}
        for ch in data:
            num      = str(ch.get("channelNumber", ch.get("number", "")))
            callsign = ch.get("callSign", ch.get("stationID", ""))
            progs    = ch.get("airings", ch.get("programs", []))
            parsed   = []
            for p in progs:
                start = p.get("startTime", p.get("start", 0))
                stop  = p.get("endTime",   p.get("stop",  0))
                if start > 1e12:
                    start /= 1000
                    stop  /= 1000
                cats = p.get("categories", [])
                parsed.append(self._make_program(
                    title=p.get("title", ""),
                    description=p.get("summary", p.get("description", "")),
                    category=cats[0] if cats else "",
                    episode_title=p.get("episodeTitle", p.get("sub_title", "")),
                    season=int(p.get("seasonNumber", p.get("season", 0)) or 0),
                    episode=int(p.get("episodeNumber", p.get("episode", 0)) or 0),
                    air_date=str(p.get("originalAirDate", p.get("airDate", ""))),
                    image=p.get("image", p.get("thumbnail", "")),
                    start_ts=start, stop_ts=stop, now=now,
                ))
            if num and parsed:
                result[num] = parsed
                if callsign:
                    result[callsign] = parsed   # dual-key for flexible lookup
        return result

    def _parse_xmltv(self, xml_bytes):
        now = time.time()
        result = {}
        try:
            root = ET.fromstring(xml_bytes)
        except ET.ParseError as e:
            xbmc.log("[BlackKnight] XMLTV parse error: {}".format(e), xbmc.LOGWARNING)
            return {}

        # Build channel id -> list of display names
        # Channels DVR XMLTV uses callsign/number in display-name tags
        ch_keys = {}   # xmltv_id -> [key1, key2, ...]
        for ch in root.findall("channel"):
            cid  = ch.get("id", "")
            keys = []
            for dn in ch.findall("display-name"):
                txt = (dn.text or "").strip()
                if txt:
                    keys.append(txt)
            if not keys:
                keys = [cid]
            ch_keys[cid] = keys

        for prog in root.findall("programme"):
            cid   = prog.get("channel", "")
            start = self._xmltv_to_ts(prog.get("start", ""))
            stop  = self._xmltv_to_ts(prog.get("stop",  ""))

            t_el    = prog.find("title")
            d_el    = prog.find("desc")
            cat_el  = prog.find("category")
            sub_el  = prog.find("sub-title")
            date_el = prog.find("date")
            icon_el = prog.find("icon")

            # Parse episode-num (xmltv_ns format: "S.E." or "0.4.0/1")
            season = episode = 0
            for ep_el in prog.findall("episode-num"):
                sys = ep_el.get("system", "")
                val = (ep_el.text or "").strip()
                if sys == "xmltv_ns" and val:
                    parts = val.split(".")
                    try:
                        if parts[0].strip():
                            season  = int(parts[0].strip()) + 1
                        if len(parts) > 1 and parts[1].strip():
                            ep_part = parts[1].strip()
                            episode = int(ep_part.split("/")[0]) + 1
                    except (ValueError, IndexError):
                        pass
                elif sys == "onscreen" and val:
                    m = re.match(r"S(\d+)E(\d+)", val, re.IGNORECASE)
                    if m:
                        season, episode = int(m.group(1)), int(m.group(2))

            p = self._make_program(
                title=t_el.text if t_el is not None else "",
                description=d_el.text if d_el is not None else "",
                category=cat_el.text if cat_el is not None else "",
                episode_title=sub_el.text if sub_el is not None else "",
                season=season,
                episode=episode,
                air_date=date_el.text if date_el is not None else "",
                image=icon_el.get("src", "") if icon_el is not None else "",
                start_ts=start, stop_ts=stop, now=now,
            )

            for key in ch_keys.get(cid, [cid]):
                if key not in result:
                    result[key] = []
                result[key].append(p)

        return result

    @staticmethod
    def _xmltv_to_ts(s):
        """Parse 'YYYYMMDDHHMMSS +ZZZZ' to Unix timestamp. Returns 0 on failure."""
        from datetime import datetime, timezone, timedelta
        s = s.strip()
        if not s:
            return 0
        dt_str, tz_str = (s.split(" ", 1) + ["+0000"])[:2]
        try:
            dt   = datetime.strptime(dt_str, "%Y%m%d%H%M%S")
            sign = 1 if tz_str[0] == "+" else -1
            off  = timedelta(hours=int(tz_str[1:3]), minutes=int(tz_str[3:5])) * sign
            return dt.replace(tzinfo=timezone(off)).timestamp()
        except Exception:
            return 0

    @staticmethod
    def _make_program(title, description, category, start_ts, stop_ts, now,
                      episode_title="", season=0, episode=0, air_date="", image=""):
        from datetime import datetime
        duration = max(stop_ts - start_ts, 1)
        elapsed  = max(now - start_ts, 0)
        is_cur   = start_ts <= now < stop_ts
        progress = min(int(elapsed / duration * 100), 100) if is_cur else 0
        fmt      = lambda ts: datetime.fromtimestamp(ts).strftime("%H:%M") if ts else ""

        # Build a subtitle line like Channels DVR: "S2E5: Episode Title" or air date
        subtitle = ""
        if season and episode:
            subtitle = "S{}E{}".format(season, episode)
            if episode_title:
                subtitle += ": " + episode_title
        elif episode_title:
            subtitle = episode_title
        elif air_date:
            subtitle = air_date

        return {
            "title":         title,
            "description":   description,
            "category":      category,
            "episode_title": episode_title,
            "season":        season,
            "episode":       episode,
            "air_date":      air_date,
            "image":         image,
            "subtitle":      subtitle,
            "start_ts":      start_ts,
            "stop_ts":       stop_ts,
            "start_hhmm":    fmt(start_ts),
            "stop_hhmm":     fmt(stop_ts),
            "duration_s":    int(stop_ts - start_ts),
            "progress":      progress,
            "is_current":    is_cur,
        }

    def get_current_and_next(self, programs, now=None):
        """Given a sorted program list, return (current, next) or (None, None)."""
        if now is None:
            now = time.time()
        for i, p in enumerate(programs):
            if p["start_ts"] <= now < p["stop_ts"]:
                return p, (programs[i + 1] if i + 1 < len(programs) else None)
        return None, None

    # ── Recordings ────────────────────────────────────────────────────────────

    def get_recordings(self):
        for path in ("/dvr/recordings/all", "/api/v1/recordings"):
            try:
                data = self._get(path)
                return data if isinstance(data, list) else data.get("recordings", [])
            except ChannelsDVRError:
                continue
        return []

    def get_recording_stream_url(self, recording_id):
        return "{}/dvr/recordings/{}/stream.mp4".format(self.base, recording_id)

    def delete_recording(self, recording_id):
        self._delete("/dvr/recordings/{}".format(recording_id))

    # ── Jobs ─────────────────────────────────────────────────────────────────

    def get_jobs(self):
        try:
            data = self._get("/api/v1/jobs")
            return data if isinstance(data, list) else data.get("jobs", [])
        except ChannelsDVRError:
            return []

    def cancel_job(self, job_id):
        self._delete("/api/v1/jobs/{}".format(job_id))

    # ── Devices ──────────────────────────────────────────────────────────────

    def get_devices(self):
        try:
            return self._get("/api/v1/devices")
        except ChannelsDVRError:
            return []
