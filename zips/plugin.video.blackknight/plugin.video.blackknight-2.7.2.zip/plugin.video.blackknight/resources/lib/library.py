"""
library.py — .strm / .nfo file management for Kodi library integration.

Structure written to profile/library/:
  Movies/
    Title (Year)/
      Title (Year).strm
      Title (Year).nfo
  TV Shows/
    Title (Year)/
      tvshow.nfo
      Season 01/
        Title (Year) S01E01.strm
        ...
"""

import os
import xbmc
import xbmcvfs
import xbmcaddon

try:
    from urllib.parse import quote_plus
except ImportError:
    from urllib import quote_plus

_ADDON = xbmcaddon.Addon()
_ID    = _ADDON.getAddonInfo("id")


def lib_root():
    profile = xbmcvfs.translatePath(_ADDON.getAddonInfo("profile"))
    return os.path.join(profile, "library")


def _mkdirs(path):
    if not xbmcvfs.exists(path + "/"):
        xbmcvfs.mkdirs(path)


def _write(path, content):
    try:
        f = xbmcvfs.File(path, "w")
        f.write(content)
        f.close()
    except Exception as e:
        xbmc.log("[BlackKnight/Library] write failed {}: {}".format(path, e), xbmc.LOGWARNING)


def _escape(s):
    return str(s).replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace('"', "&quot;")


def _safe_name(s):
    invalid = '\\/:*?"<>|'
    return "".join(c for c in str(s) if c not in invalid).strip()


def _plugin_url(**kwargs):
    params = "?action=" + kwargs.pop("action", "home")
    for k, v in kwargs.items():
        params += "&{}={}".format(k, quote_plus(str(v)))
    return "plugin://{}{}".format(_ID, params)


def add_movie(title, year, tmdb_id, imdb_id=""):
    folder_name = "{} ({})".format(_safe_name(title), year) if year else _safe_name(title)
    folder = os.path.join(lib_root(), "Movies", folder_name)
    _mkdirs(folder)

    _write(
        os.path.join(folder, "{}.strm".format(folder_name)),
        _plugin_url(action="movie_sources", tmdb_id=tmdb_id, title=title, year=year)
    )

    nfo = '<?xml version="1.0" encoding="UTF-8"?>\n<movie>\n'
    nfo += "  <title>{}</title>\n".format(_escape(title))
    if year:
        nfo += "  <year>{}</year>\n".format(year)
    if imdb_id:
        nfo += '  <uniqueid type="imdb" default="true">{}</uniqueid>\n'.format(imdb_id)
    if tmdb_id:
        nfo += '  <uniqueid type="tmdb">{}</uniqueid>\n'.format(tmdb_id)
    nfo += "</movie>"
    _write(os.path.join(folder, "{}.nfo".format(folder_name)), nfo)

    xbmc.log("[BlackKnight/Library] Added movie: {}".format(folder), xbmc.LOGINFO)
    return folder


def add_show(title, year, tmdb_id, imdb_id="", seasons=None):
    """
    seasons: {season_number(int): [episode_number(int), ...]}
    """
    folder_name = "{} ({})".format(_safe_name(title), year) if year else _safe_name(title)
    show_folder = os.path.join(lib_root(), "TV Shows", folder_name)
    _mkdirs(show_folder)

    nfo = '<?xml version="1.0" encoding="UTF-8"?>\n<tvshow>\n'
    nfo += "  <title>{}</title>\n".format(_escape(title))
    if year:
        nfo += "  <year>{}</year>\n".format(year)
    if imdb_id:
        nfo += '  <uniqueid type="imdb" default="true">{}</uniqueid>\n'.format(imdb_id)
    if tmdb_id:
        nfo += '  <uniqueid type="tmdb">{}</uniqueid>\n'.format(tmdb_id)
    nfo += "</tvshow>"
    _write(os.path.join(show_folder, "tvshow.nfo"), nfo)

    for season_num, ep_nums in (seasons or {}).items():
        season_folder = os.path.join(show_folder, "Season {:02d}".format(int(season_num)))
        _mkdirs(season_folder)
        for ep_num in ep_nums:
            strm_name = "{} S{:02d}E{:02d}.strm".format(
                folder_name, int(season_num), int(ep_num))
            _write(
                os.path.join(season_folder, strm_name),
                _plugin_url(action="tv_episode_sources",
                            imdb_id=imdb_id, season=season_num, episode=ep_num,
                            show_title=title, show_year=year)
            )

    xbmc.log("[BlackKnight/Library] Added show: {} ({} seasons)".format(
        show_folder, len(seasons or {})), xbmc.LOGINFO)
    return show_folder
