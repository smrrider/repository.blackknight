"""
trailer.py — Apple Trailers fallback for Black Knight.

Primary trailer playback uses plugin.video.youtube directly (handled in default.py).
This module provides Apple Trailers as a secondary fallback for movies where the
YouTube key is unavailable, or as a future revival point if Apple restores their API.

NOTE: The Apple Trailers JSON endpoint (trailers.apple.com/trailers/home/feeds/search.json)
currently returns HTML instead of JSON — it has been dead since mid-2025.  The code is
preserved so it auto-revives if Apple restores the API.
"""

import json
import xbmc

try:
    from urllib.request import urlopen, Request
    from urllib.parse import quote_plus
except ImportError:
    from urllib2 import urlopen, Request
    from urllib import quote_plus

BROWSER_UA = (
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
    "AppleWebKit/537.36 (KHTML, like Gecko) "
    "Chrome/124.0.0.0 Safari/537.36"
)

APPLE_SEARCH = "https://trailers.apple.com/trailers/home/feeds/search.json?q={}"
APPLE_PAGE   = "https://trailers.apple.com{}data/page.json"


def get_trailer_url(title=None, year=None):
    """Return a direct Apple Trailers MP4 URL, or None."""
    if not title:
        return None
    url = _try_apple(title, year)
    if url:
        xbmc.log(
            "[BlackKnight/Trailer] Apple: resolved stream for '{}'".format(title),
            xbmc.LOGINFO,
        )
        return url
    xbmc.log(
        "[BlackKnight/Trailer] Apple: no trailer found for title={}".format(title),
        xbmc.LOGWARNING,
    )
    return None


def _http_get_json(url):
    req  = Request(url, headers={"User-Agent": BROWSER_UA, "Accept": "application/json"})
    resp = urlopen(req, timeout=10)
    raw  = resp.read()
    if not raw.strip():
        raise ValueError("Empty response from {}".format(url))
    return json.loads(raw.decode("utf-8"))


def _try_apple(title, year=None):
    try:
        results = _http_get_json(APPLE_SEARCH.format(quote_plus(title)))
        if not results:
            return None

        match = None
        title_lower = title.lower()
        for r in results:
            r_title = r.get("title", "").lower()
            if title_lower in r_title or r_title in title_lower:
                r_year = str(r.get("releasedate", ""))[:4]
                if not year or r_year == str(year):
                    match = r
                    break
        if not match:
            match = results[0]

        location = match.get("location", "")
        if not location:
            return None

        page  = _http_get_json(APPLE_PAGE.format(location))
        clips = page.get("clips", [])
        for clip in clips:
            versions = clip.get("versions", {})
            for quality in ("hd1080p", "hd720p", "sd"):
                v   = versions.get(quality, {})
                src = v.get("srcAlt") or v.get("src", "")
                if src:
                    return src

    except Exception as e:
        xbmc.log("[BlackKnight/Trailer] Apple error: {}".format(e), xbmc.LOGWARNING)
    return None
