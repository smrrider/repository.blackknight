"""
ui.py -- KODI menu/list builder utilities for Black Knight.
All xbmcplugin / xbmcgui interactions live here.
"""

import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon

try:
    from urllib.parse import quote_plus
except ImportError:
    from urllib import quote_plus

_ADDON = xbmcaddon.Addon()
_ID    = _ADDON.getAddonInfo("id")


# -- Addon URL builder ----------------------------------------------------------

def build_url(handle, action, **kwargs):
    """Build a plugin:// URL. Values are URL-encoded so titles/strings are safe."""
    params = "?action={}".format(action)
    for k, v in kwargs.items():
        params += "&{}={}".format(k, quote_plus(str(v)))
    return "plugin://{}{}".format(_ID, params)


# -- InfoTagVideo helper --------------------------------------------------------

def _apply_info_tag(li, info):
    """Apply video metadata using KODI Omega InfoTagVideo API."""
    try:
        tag = li.getVideoInfoTag()
        if info.get("title"):
            tag.setTitle(str(info["title"]))
        if info.get("plot"):
            tag.setPlot(str(info["plot"]))
        if info.get("rating"):
            tag.setRating(float(info["rating"]))
        if info.get("year"):
            tag.setYear(int(info["year"]))
        duration = info.get("duration", 0)
        if duration:
            tag.setDuration(int(duration))
        genre = info.get("genre", info.get("genres", ""))
        if genre:
            tag.setGenres(genre if isinstance(genre, list) else [genre])
        studio = info.get("studio", "")
        if studio:
            tag.setStudios([studio])
        tag.setMediaType(info.get("mediatype", "video"))
        if info.get("season") is not None:
            tag.setSeason(int(info["season"]))
        if info.get("episode") is not None:
            tag.setEpisode(int(info["episode"]))
        aired = info.get("aired", "")
        if aired:
            tag.setFirstAired(str(aired))
        playcount = info.get("playcount", 0)
        if playcount:
            tag.setPlaycount(int(playcount))
    except AttributeError:
        li.setInfo("video", info)


# -- List helpers ---------------------------------------------------------------

def add_directory(handle, label, url, art=None, info=None, is_folder=True):
    li = xbmcgui.ListItem(label=label)
    if art:
        li.setArt(art)
    if info:
        _apply_info_tag(li, info)
    xbmcplugin.addDirectoryItem(handle, url, li, isFolder=is_folder)


def add_playable(handle, label, url, art=None, info=None, context_items=None):
    li = xbmcgui.ListItem(label=label)
    li.setProperty("IsPlayable", "true")
    if art:
        li.setArt(art)
    if info:
        _apply_info_tag(li, info)
    if context_items:
        li.addContextMenuItems(context_items)
    xbmcplugin.addDirectoryItem(handle, url, li, isFolder=False)


def end_listing(handle, content="videos", sort_methods=None):
    xbmcplugin.setContent(handle, content)
    for sm in (sort_methods or [xbmcplugin.SORT_METHOD_LABEL_IGNORE_THE,
                                xbmcplugin.SORT_METHOD_DATE]):
        xbmcplugin.addSortMethod(handle, sm)
    xbmcplugin.endOfDirectory(handle)


def _next_page_label(page, total_pages):
    """Formatted next-page label with bold arrow."""
    return "[B]Next ->[/B] (Page {} of {})".format(page + 1, total_pages)


# -- Home screen ----------------------------------------------------------------

# Items that fire an action instead of opening a folder.
_ACTION_ONLY = {"trakt_auth", "trakt_disconnect", "open_settings", "library_setup"}

# Items the Captain may not hide - without these the menu becomes a dead end.
MENU_LOCKED = {"open_settings", "customize_menu"}

# Canonical menu registry. Order here is the factory default.
# "requires" gates visibility on runtime state, independent of user preference.
MENU_ITEMS = [
    {"id": "continue_watching",     "label": "Continue Watching",   "requires": "trakt"},
    {"id": "watchlist",             "label": "My Watchlist",        "requires": "trakt"},
    {"id": "trakt_recommendations", "label": "Trakt Picks For You", "requires": "trakt"},
    {"id": "trakt_hub",             "label": "My Trakt",            "requires": "trakt"},
    {"id": "friends_picks",         "label": "Friend's Picks",      "requires": "sharing"},
    {"id": "my_recommendations",    "label": "My Recommendations",  "requires": "sharing"},
    {"id": "stream_search",         "label": "Search Streaming Services", "requires": None},
    {"id": "search",                "label": "Search",              "requires": None},
    {"id": "streaming_services",    "label": "Streaming Services",  "requires": None},
    {"id": "movies",                "label": "Movies",              "requires": None},
    {"id": "tv_shows",              "label": "TV Shows",            "requires": None},
    {"id": "library_setup",         "label": "About Library",       "requires": None},
    {"id": "trakt_auth",            "label": "Connect Trakt",       "requires": "no_trakt"},
    {"id": "trakt_disconnect",      "label": "Disconnect Trakt",    "requires": "trakt"},
    {"id": "customize_menu",        "label": "Customize Menu",      "requires": None},
    {"id": "open_settings",         "label": "Settings",            "requires": None},
]

_MENU_BY_ID = {m["id"]: m for m in MENU_ITEMS}


def _csv_setting(key):
    try:
        raw = _ADDON.getSetting(key) or ""
    except Exception:
        return []
    return [p for p in (x.strip() for x in raw.split(",")) if p]


def menu_hidden_ids():
    """IDs the Captain has switched off."""
    return set(_csv_setting("home_menu_hidden")) - MENU_LOCKED


def menu_ordered_items():
    """MENU_ITEMS in the Captain's saved order.

    Unknown saved IDs are dropped and any registry item missing from the saved
    order is appended, so a stale preference never hides a newly added menu
    entry after an update.
    """
    saved = [i for i in _csv_setting("home_menu_order") if i in _MENU_BY_ID]
    rest  = [m["id"] for m in MENU_ITEMS if m["id"] not in saved]
    return [_MENU_BY_ID[i] for i in (saved + rest)]


def save_menu_prefs(order_ids, hidden_ids):
    _ADDON.setSetting("home_menu_order",  ",".join(order_ids))
    _ADDON.setSetting("home_menu_hidden", ",".join(sorted(set(hidden_ids) - MENU_LOCKED)))


def _menu_visible(entry, trakt_authorized, sharing_ok):
    req = entry.get("requires")
    if req == "trakt":     return trakt_authorized
    if req == "no_trakt":  return not trakt_authorized
    if req == "sharing":   return sharing_ok
    return True


def build_home(handle, trakt_authorized=False, friend_name="", sharing_enabled=False,
               trakt_username=""):
    icon   = _ADDON.getAddonInfo("icon")
    fanart = _ADDON.getAddonInfo("fanart")
    xbmcplugin.setPluginFanart(handle, fanart)

    sharing_ok = bool(sharing_enabled and friend_name)
    hidden     = menu_hidden_ids()

    for entry in menu_ordered_items():
        mid = entry["id"]
        if mid in hidden:
            continue
        if not _menu_visible(entry, trakt_authorized, sharing_ok):
            continue

        # Labels that carry runtime context
        label = entry["label"]
        if mid == "trakt_hub" and trakt_username:
            label = "My Trakt ({})".format(trakt_username)
        elif mid == "trakt_disconnect" and trakt_username:
            label = "Disconnect Trakt ({})".format(trakt_username)
        elif mid == "friends_picks" and friend_name:
            label = "{}'s Picks".format(friend_name)

        li = xbmcgui.ListItem(label=label)
        li.setArt({"icon": icon, "fanart": fanart})
        li.addContextMenuItems([
            ("Customize Menu", "RunPlugin({})".format(build_url(handle, "customize_menu"))),
        ])
        xbmcplugin.addDirectoryItem(handle, build_url(handle, mid), li,
                                    isFolder=(mid not in _ACTION_ONLY))

    xbmcplugin.setContent(handle, "files")
    # cacheToDisc=False is required here. KODI caches plugin directory listings
    # to disc by default and re-serves them, so menu edits appeared to save but
    # never showed up. It also means Container.Refresh cannot help when the
    # editor is launched from Settings, where the home container is not active.
    xbmcplugin.endOfDirectory(handle, cacheToDisc=False)

# -- Streaming Services ---------------------------------------------------------

STREAMING_SERVICES = [
    {"id": 8,    "name": "Netflix"},
    {"id": 9,    "name": "Amazon Prime Video"},
    {"id": 337,  "name": "Disney+"},
    {"id": 15,   "name": "Hulu"},
    {"id": 386,  "name": "Peacock"},
    {"id": 531,  "name": "Paramount+"},
    {"id": 350,  "name": "Apple TV+"},
    {"id": 1899, "name": "Max"},
    {"id": 73,   "name": "Tubi TV"},
]


def build_streaming_services(handle, logo_map=None, fanart_map=None):
    logo_map   = logo_map or {}
    fanart_map = fanart_map or {}
    li = xbmcgui.ListItem(label="[B]Search all services...[/B]")
    li.setArt({"icon": "DefaultAddonsSearch.png", "thumb": "DefaultAddonsSearch.png"})
    xbmcplugin.addDirectoryItem(handle, build_url(handle, "stream_search"), li, isFolder=True)
    for svc in STREAMING_SERVICES:
        pid  = svc["id"]
        name = svc["name"]
        url  = build_url(handle, "provider_menu",
                         provider_id=pid, provider_name=name)
        li   = xbmcgui.ListItem(label=name)
        art  = {}
        logo = logo_map.get(pid, "")
        if logo:
            art.update({"icon": logo, "thumb": logo, "poster": logo})
        fanart = fanart_map.get(pid, "")
        if fanart:
            art["fanart"] = fanart
        if art:
            li.setArt(art)
        xbmcplugin.addDirectoryItem(handle, url, li, isFolder=True)
    end_listing(handle, content="files", sort_methods=[xbmcplugin.SORT_METHOD_NONE])


_PROVIDER_SUBCATS = {
    "movie": [
        ("Popular",      "popularity.desc",           0),
        ("New Releases", "primary_release_date.desc", 0),
        ("Top Rated",    "vote_average.desc",         200),
    ],
    "tv": [
        ("Popular",      "popularity.desc",     0),
        ("New",          "first_air_date.desc", 0),
        ("Top Rated",    "vote_average.desc",   100),
    ],
}


def build_provider_menu(handle, provider_id, provider_name):
    for label, action in [("Movies", "provider_movies"), ("TV Shows", "provider_tv")]:
        url = build_url(handle, action,
                        provider_id=provider_id, provider_name=provider_name)
        add_directory(handle, label, url)
    end_listing(handle, content="files", sort_methods=[xbmcplugin.SORT_METHOD_NONE])


def build_provider_subcat_menu(handle, provider_id, provider_name, media_type):
    subcats = _PROVIDER_SUBCATS.get(media_type, _PROVIDER_SUBCATS["movie"])
    for label, sort_by, min_votes in subcats:
        url = build_url(handle, "provider_content",
                        provider_id=provider_id, provider_name=provider_name,
                        media_type=media_type, sort_by=sort_by,
                        min_votes=min_votes, page=1)
        add_directory(handle, label, url)
    end_listing(handle, content="files", sort_methods=[xbmcplugin.SORT_METHOD_NONE])


# -- TMDB Movies ----------------------------------------------------------------

def build_movies_menu(handle):
    items = [
        ("Trending Movies",   "trending_movies"),
        ("Popular Movies",    "movies_popular"),
        ("Top Rated Movies",  "movies_top_rated"),
        ("Now Playing",       "movies_now_playing"),
        ("Coming Soon",       "movies_upcoming"),
        ("Browse by Genre",   "movies_genres"),
        ("Search Movies",     "movies_search"),
    ]
    for label, action in items:
        add_directory(handle, label, build_url(handle, action, page=1))
    end_listing(handle, content="files", sort_methods=[xbmcplugin.SORT_METHOD_NONE])


def build_movie_list(handle, results, tmdb, total_pages=1, page=1,
                     next_action=None, rd_enabled=False, trakt_authorized=False,
                     next_params=None, friend_name="", sharing_enabled=False):
    xbmcplugin.setContent(handle, "movies")

    for movie in results:
        mid    = movie.get("id", "")
        title  = movie.get("title", "")
        year   = str(movie.get("release_date", ""))[:4]
        rating = movie.get("vote_average", 0)
        plot   = movie.get("overview", "")
        poster = tmdb.poster_url(movie.get("poster_path"))
        fanart = tmdb.fanart_url(movie.get("backdrop_path"))

        label = "{} ({})".format(title, year) if year else title
        info  = {
            "title":     title,
            "year":      int(year) if year.isdigit() else 0,
            "rating":    float(rating),
            "plot":      plot,
            "mediatype": "movie",
        }
        art = {"poster": poster, "fanart": fanart, "thumb": poster}

        ctx = [
            ("Play Trailer",
             "RunPlugin({})".format(build_url(handle, "play_trailer",
                 tmdb_id=mid, title=title, year=year if year.isdigit() else 0))),
            ("More Like This",
             "Container.Update({})".format(build_url(handle, "movie_similar",
                 tmdb_id=mid, title=title))),
            ("Add to Library",
             "RunPlugin({})".format(build_url(handle, "library_add_movie",
                 tmdb_id=mid, title=title, year=year if year.isdigit() else 0))),
        ]
        if sharing_enabled and friend_name:
            ctx.append(("Recommend to {}".format(friend_name),
                "RunPlugin({})".format(build_url(handle, "recommend",
                    media_type="movie", tmdb_id=mid, title=title,
                    year=year if year.isdigit() else 0))))
        if trakt_authorized:
            ctx.append(("+ Trakt Watchlist",
                "RunPlugin({})".format(build_url(handle, "watchlist_add",
                    media_type="movie", tmdb_id=mid, title=title,
                    year=year if year.isdigit() else 0))))

        if rd_enabled:
            url = build_url(handle, "movie_sources", tmdb_id=mid, title=title,
                            year=year if year.isdigit() else 0)
            li = xbmcgui.ListItem(label=label)
            li.setProperty("IsPlayable", "true")
            _apply_info_tag(li, info)
            li.setArt(art)
            if ctx:
                li.addContextMenuItems(ctx)
            xbmcplugin.addDirectoryItem(handle, url, li, isFolder=False)
        else:
            # No RD -- show metadata only; non-playable
            li = xbmcgui.ListItem(label=label)
            _apply_info_tag(li, info)
            li.setArt(art)
            if ctx:
                li.addContextMenuItems(ctx)
            xbmcplugin.addDirectoryItem(handle, "", li, isFolder=False)

    if next_action and page < total_pages:
        kw = dict(next_params or {})
        kw["page"] = page + 1
        add_directory(handle, _next_page_label(page, total_pages),
                      build_url(handle, next_action, **kw))

    xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_LABEL_IGNORE_THE)
    xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_VIDEO_RATING)
    xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_VIDEO_YEAR)
    xbmcplugin.endOfDirectory(handle)

# -- TMDB TV Shows --------------------------------------------------------------

def build_tv_menu(handle):
    items = [
        ("Trending TV Shows",   "trending_tv"),
        ("Popular TV Shows",    "tv_popular"),
        ("Top Rated TV Shows",  "tv_top_rated"),
        ("On the Air",          "tv_on_the_air"),
        ("Airing Today",        "tv_airing_today"),
        ("Browse by Genre",     "tv_genres"),
        ("Search TV Shows",     "tv_search"),
    ]
    for label, action in items:
        add_directory(handle, label, build_url(handle, action, page=1))
    end_listing(handle, content="files", sort_methods=[xbmcplugin.SORT_METHOD_NONE])


def build_tv_list(handle, results, tmdb, total_pages=1, page=1,
                  next_action=None, trakt_authorized=False, next_params=None,
                  friend_name="", sharing_enabled=False):
    xbmcplugin.setContent(handle, "tvshows")

    for show in results:
        sid    = show.get("id", "")
        title  = show.get("name", "")
        year   = str(show.get("first_air_date", ""))[:4]
        rating = show.get("vote_average", 0)
        plot   = show.get("overview", "")
        poster = tmdb.poster_url(show.get("poster_path"))
        fanart = tmdb.fanart_url(show.get("backdrop_path"))

        label = "{} ({})".format(title, year) if year else title
        url   = build_url(handle, "tv_seasons", tmdb_id=sid,
                          show_title=title, show_year=year if year.isdigit() else 0)
        info  = {
            "title":     title,
            "year":      int(year) if year.isdigit() else 0,
            "rating":    float(rating),
            "plot":      plot,
            "mediatype": "tvshow",
        }
        art = {"poster": poster, "fanart": fanart, "thumb": poster}

        li = xbmcgui.ListItem(label=label)
        _apply_info_tag(li, info)
        li.setArt(art)

        ctx = [
            ("Play Trailer",
             "RunPlugin({})".format(build_url(handle, "play_tv_trailer",
                 tmdb_id=sid, title=title, year=year if year.isdigit() else 0))),
            ("More Like This",
             "Container.Update({})".format(build_url(handle, "tv_similar",
                 tmdb_id=sid, title=title))),
            ("Add to Library",
             "RunPlugin({})".format(build_url(handle, "library_add_show",
                 tmdb_id=sid, title=title, year=year if year.isdigit() else 0))),
        ]
        if sharing_enabled and friend_name:
            ctx.append(("Recommend to {}".format(friend_name),
                "RunPlugin({})".format(build_url(handle, "recommend",
                    media_type="tv", tmdb_id=sid, title=title,
                    year=year if year.isdigit() else 0))))
        if trakt_authorized:
            ctx.append(("+ Trakt Watchlist",
                "RunPlugin({})".format(build_url(handle, "watchlist_add",
                    media_type="tv", tmdb_id=sid, title=title,
                    year=year if year.isdigit() else 0))))
        li.addContextMenuItems(ctx)

        xbmcplugin.addDirectoryItem(handle, url, li, isFolder=True)

    if next_action and page < total_pages:
        kw = dict(next_params or {})
        kw["page"] = page + 1
        add_directory(handle, _next_page_label(page, total_pages),
                      build_url(handle, next_action, **kw))

    xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_LABEL_IGNORE_THE)
    xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_VIDEO_RATING)
    xbmcplugin.endOfDirectory(handle)


def build_tv_seasons(handle, tv_id, seasons, tmdb, show_title="",
                     show_year=0, imdb_id=""):
    xbmcplugin.setContent(handle, "seasons")

    for season in seasons:
        season_num  = season.get("season_number", 0)
        season_name = season.get("name", "Season {}".format(season_num))
        ep_count    = season.get("episode_count", 0)
        poster      = tmdb.poster_url(season.get("poster_path"))

        label = "{} ({} eps)".format(season_name, ep_count)
        url   = build_url(handle, "tv_episodes", tmdb_id=tv_id,
                          season=season_num, imdb_id=imdb_id,
                          show_title=show_title, show_year=show_year)
        info  = {"title": season_name, "season": season_num, "mediatype": "season"}
        add_directory(handle, label, url, art={"poster": poster, "thumb": poster}, info=info)

    xbmcplugin.endOfDirectory(handle)


def build_tv_episodes(handle, episodes, tmdb, imdb_id="", season="1",
                      rd_enabled=False, show_title="", show_year=0,
                      trakt_authorized=False, tmdb_id="",
                      friend_name="", sharing_enabled=False):
    xbmcplugin.setContent(handle, "episodes")

    for ep in episodes:
        ep_num   = ep.get("episode_number", 0)
        title    = ep.get("name", "Episode {}".format(ep_num))
        plot     = ep.get("overview", "")
        rating   = ep.get("vote_average", 0)
        runtime  = ep.get("runtime", 0)
        still    = tmdb.still_url(ep.get("still_path"))
        air_date = ep.get("air_date", "")

        label = "{:02d}. {}".format(ep_num, title)
        info  = {
            "title":     title,
            "episode":   ep_num,
            "season":    int(season),
            "plot":      plot,
            "rating":    float(rating),
            "duration":  (runtime or 0) * 60,
            "aired":     air_date,
            "mediatype": "episode",
        }

        li = xbmcgui.ListItem(label=label)
        li.setArt({"thumb": still})

        ctx = []
        if tmdb_id:
            ctx.append(("Play Trailer",
                "RunPlugin({})".format(build_url(handle, "play_tv_trailer",
                    tmdb_id=tmdb_id, title=show_title, year=show_year))))
        if trakt_authorized and imdb_id:
            ctx.append(("+ Trakt Watchlist",
                "RunPlugin({})".format(build_url(handle, "watchlist_add",
                    media_type="tv", imdb_id=imdb_id, title=show_title, year=show_year))))
        if sharing_enabled and friend_name and imdb_id:
            ctx.append(("Recommend to {}".format(friend_name),
                "RunPlugin({})".format(build_url(handle, "recommend",
                    media_type="tv", imdb_id=imdb_id, title=show_title, year=show_year))))
        if ctx:
            li.addContextMenuItems(ctx)

        if rd_enabled and imdb_id:
            url = build_url(handle, "tv_episode_sources",
                            imdb_id=imdb_id, season=season, episode=ep_num,
                            show_title=show_title, show_year=show_year)
            li.setProperty("IsPlayable", "true")
            _apply_info_tag(li, info)
            xbmcplugin.addDirectoryItem(handle, url, li, isFolder=False)
        else:
            _apply_info_tag(li, info)
            xbmcplugin.addDirectoryItem(handle, "", li, isFolder=False)

    xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_EPISODE)
    xbmcplugin.endOfDirectory(handle)


# -- Genre browsers -------------------------------------------------------------

def build_genres_menu(handle, genres, media_type="movie"):
    """List genre directories."""
    action = "genre_movies" if media_type == "movie" else "genre_tv"
    for g in genres:
        gid   = g.get("id", "")
        gname = g.get("name", "")
        url   = build_url(handle, action, genre_id=gid, genre_name=gname, page=1)
        add_directory(handle, gname, url)
    end_listing(handle, content="files", sort_methods=[xbmcplugin.SORT_METHOD_LABEL_IGNORE_THE])


# -- Collections ----------------------------------------------------------------

def build_collection(handle, collection, tmdb, rd_enabled=False, trakt_authorized=False):
    """Display the parts of a TMDB collection / franchise."""
    xbmcplugin.setContent(handle, "movies")
    parts = collection.get("parts", [])
    parts.sort(key=lambda m: m.get("release_date", "") or "")

    for movie in parts:
        mid    = movie.get("id", "")
        title  = movie.get("title", "")
        year   = str(movie.get("release_date", ""))[:4]
        plot   = movie.get("overview", "")
        poster = tmdb.poster_url(movie.get("poster_path"))
        fanart = tmdb.fanart_url(movie.get("backdrop_path"))
        rating = movie.get("vote_average", 0)

        label = "{} ({})".format(title, year) if year else title
        info  = {
            "title": title, "year": int(year) if year.isdigit() else 0,
            "rating": float(rating), "plot": plot, "mediatype": "movie",
        }
        art = {"poster": poster, "fanart": fanart, "thumb": poster}
        ctx = [
            ("Play Trailer",
             "RunPlugin({})".format(build_url(handle, "play_trailer",
                 tmdb_id=mid, title=title, year=year if year.isdigit() else 0))),
        ]
        if trakt_authorized:
            ctx.append(("+ Trakt Watchlist",
                "RunPlugin({})".format(build_url(handle, "watchlist_add",
                    media_type="movie", tmdb_id=mid, title=title,
                    year=year if year.isdigit() else 0))))

        li = xbmcgui.ListItem(label=label)
        _apply_info_tag(li, info)
        li.setArt(art)
        if ctx:
            li.addContextMenuItems(ctx)

        if rd_enabled:
            url = build_url(handle, "movie_sources", tmdb_id=mid, title=title,
                            year=year if year.isdigit() else 0)
            li.setProperty("IsPlayable", "true")
            xbmcplugin.addDirectoryItem(handle, url, li, isFolder=False)
        else:
            xbmcplugin.addDirectoryItem(handle, "", li, isFolder=False)

    xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_LABEL_IGNORE_THE)
    xbmcplugin.endOfDirectory(handle)


# -- People search --------------------------------------------------------------

def build_person_list(handle, results):
    """Search results list of people."""
    from tmdb import IMAGE_BASE
    for person in results:
        pid  = person.get("id", "")
        name = person.get("name", "")
        dept = person.get("known_for_department", "")
        label = "{} ({})".format(name, dept) if dept else name
        url   = build_url(handle, "person_filmography", person_id=pid, person_name=name)
        known = person.get("known_for", [])
        known_titles = ", ".join([k.get("title") or k.get("name", "") for k in known[:3]])
        thumb = ""
        ppath = person.get("profile_path", "")
        if ppath:
            thumb = "{}/w185{}".format(IMAGE_BASE, ppath)
        li = xbmcgui.ListItem(label=label)
        if known_titles:
            try:
                li.getVideoInfoTag().setPlot("Known for: " + known_titles)
            except Exception:
                li.setInfo("video", {"plot": "Known for: " + known_titles})
        if thumb:
            li.setArt({"thumb": thumb, "poster": thumb})
        xbmcplugin.addDirectoryItem(handle, url, li, isFolder=True)
    xbmcplugin.endOfDirectory(handle)


def build_person_filmography(handle, credits, tmdb, person_name="",
                             rd_enabled=False, trakt_authorized=False):
    """Filmography list for a single person."""
    xbmcplugin.setContent(handle, "movies")
    cast_movies = credits.get("cast", [])
    crew_movies = [m for m in credits.get("crew", [])
                   if m.get("department") in ("Directing", "Writing", "Production")]
    seen = set()
    movies = []
    for m in (cast_movies + crew_movies):
        mid = m.get("id")
        if mid not in seen:
            seen.add(mid)
            movies.append(m)
    movies.sort(key=lambda m: m.get("release_date", "") or "", reverse=True)

    for movie in movies:
        mid    = movie.get("id", "")
        title  = movie.get("title", "")
        year   = str(movie.get("release_date", ""))[:4]
        plot   = movie.get("overview", "")
        poster = tmdb.poster_url(movie.get("poster_path"))
        fanart = tmdb.fanart_url(movie.get("backdrop_path"))
        rating = movie.get("vote_average", 0)
        role   = movie.get("character", "") or movie.get("job", "")
        label  = "{} ({})".format(title, year) if year else title
        if role:
            label += "  [{}]".format(role)
        info   = {
            "title": title, "year": int(year) if year.isdigit() else 0,
            "rating": float(rating), "plot": plot, "mediatype": "movie",
        }
        art = {"poster": poster, "fanart": fanart, "thumb": poster}
        ctx = [
            ("Play Trailer",
             "RunPlugin({})".format(build_url(handle, "play_trailer",
                 tmdb_id=mid, title=title, year=year if year.isdigit() else 0))),
        ]
        if trakt_authorized:
            ctx.append(("+ Trakt Watchlist",
                "RunPlugin({})".format(build_url(handle, "watchlist_add",
                    media_type="movie", tmdb_id=mid, title=title,
                    year=year if year.isdigit() else 0))))

        li = xbmcgui.ListItem(label=label)
        _apply_info_tag(li, info)
        li.setArt(art)
        if ctx:
            li.addContextMenuItems(ctx)

        if rd_enabled:
            url = build_url(handle, "movie_sources", tmdb_id=mid, title=title,
                            year=year if year.isdigit() else 0)
            li.setProperty("IsPlayable", "true")
            xbmcplugin.addDirectoryItem(handle, url, li, isFolder=False)
        else:
            xbmcplugin.addDirectoryItem(handle, "", li, isFolder=False)

    xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_LABEL_IGNORE_THE)
# -- Continue Watching helper --------------------------------------------------

def _tmdb_art(tmdb, tmdb_id, imdb_id, media_type="movie"):
    if not tmdb:
        return "", ""
    try:
        if tmdb_id:
            if media_type == "movie":
                data = tmdb.movie_details(tmdb_id)
            else:
                data = tmdb.tv_details(tmdb_id)
        elif imdb_id:
            data = tmdb.find_by_imdb(imdb_id, media_type=media_type)
        else:
            return "", ""
        return tmdb.poster_url(data.get("poster_path")), tmdb.fanart_url(data.get("backdrop_path"))
    except Exception:
        return "", ""


def build_continue_watching(handle, movies, episodes, tmdb=None):
    xbmcplugin.setContent(handle, "movies")
    if not movies and not episodes:
        xbmcgui.Dialog().notification("Black Knight", "Nothing in progress", xbmcgui.NOTIFICATION_INFO, 3000)
        xbmcplugin.endOfDirectory(handle)
        return
    for item in movies:
        movie      = item.get("movie", {})
        title      = movie.get("title", "")
        year       = movie.get("year", 0)
        ids        = movie.get("ids", {})
        imdb_id    = ids.get("imdb", "")
        tmdb_id    = ids.get("tmdb", "")
        progress   = item.get("progress", 0)
        pb_id      = item.get("id", "")
        runtime    = movie.get("runtime") or 90
        resume_sec = int(runtime * 60 * progress / 100)
        poster, fanart = _tmdb_art(tmdb, tmdb_id, imdb_id, "movie")
        label = "{} ({})".format(title, year) if year else title
        url   = build_url(handle, "movie_sources", imdb_id=imdb_id, title=title, year=year, resume_seconds=resume_sec)
        li = xbmcgui.ListItem(label=label)
        li.setProperty("IsPlayable", "true")
        li.setProperty("ProgressPercentage", str(int(progress)))
        li.setArt({"poster": poster, "fanart": fanart, "thumb": poster})
        _apply_info_tag(li, {"title": title, "year": year, "mediatype": "movie"})
        li.addContextMenuItems([("Remove from Continue Watching", "RunPlugin({})".format(build_url(handle, "remove_playback", playback_id=pb_id)))])
        xbmcplugin.addDirectoryItem(handle, url, li, isFolder=False)
    for item in episodes:
        show       = item.get("show", {})
        ep         = item.get("episode", {})
        show_title = show.get("title", "")
        show_year  = show.get("year", 0)
        ids        = show.get("ids", {})
        imdb_id    = ids.get("imdb", "")
        tmdb_id    = ids.get("tmdb", "")
        season     = ep.get("season", 1)
        ep_num     = ep.get("number", 1)
        ep_title   = ep.get("title", "")
        progress   = item.get("progress", 0)
        pb_id      = item.get("id", "")
        runtime    = ep.get("runtime") or 45
        resume_sec = int(runtime * 60 * progress / 100)
        poster, fanart = _tmdb_art(tmdb, tmdb_id, imdb_id, "tv")
        label = "{} S{:02d}E{:02d}".format(show_title, season, ep_num)
        if ep_title: label += " | " + ep_title
        url = build_url(handle, "tv_episode_sources", imdb_id=imdb_id, season=season, episode=ep_num, show_title=show_title, show_year=show_year, resume_seconds=resume_sec)
        li = xbmcgui.ListItem(label=label)
        li.setProperty("IsPlayable", "true")
        li.setProperty("ProgressPercentage", str(int(progress)))
        li.setArt({"poster": poster, "fanart": fanart, "thumb": poster})
        _apply_info_tag(li, {"title": ep_title or label, "season": season, "episode": ep_num, "mediatype": "episode"})
        li.addContextMenuItems([("Remove from Continue Watching", "RunPlugin({})".format(build_url(handle, "remove_playback", playback_id=pb_id)))])
        xbmcplugin.addDirectoryItem(handle, url, li, isFolder=False)
    xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_NONE)
    xbmcplugin.endOfDirectory(handle)


# -- Trakt: Watchlist ----------------------------------------------------------

def build_watchlist(handle, movies, shows, tmdb=None, rd_enabled=False):
    xbmcplugin.setContent(handle, "movies")
    if not movies and not shows:
        xbmcgui.Dialog().notification("Black Knight", "Your watchlist is empty", xbmcgui.NOTIFICATION_INFO, 3000)
        xbmcplugin.endOfDirectory(handle)
        return
    for item in movies:
        movie   = item.get("movie", {})
        title   = movie.get("title", "")
        year    = movie.get("year", 0)
        ids     = movie.get("ids", {})
        imdb_id = ids.get("imdb", "")
        tmdb_id = ids.get("tmdb", "")
        poster, fanart = _tmdb_art(tmdb, tmdb_id, imdb_id, "movie")
        label = "{} ({})".format(title, year) if year else title
        li = xbmcgui.ListItem(label=label)
        li.setArt({"poster": poster, "fanart": fanart, "thumb": poster})
        _apply_info_tag(li, {"title": title, "year": year, "mediatype": "movie"})
        li.addContextMenuItems([
            ("Play Trailer", "RunPlugin({})".format(build_url(handle, "play_trailer", tmdb_id=str(tmdb_id), title=title, year=year))),
            ("Remove from Watchlist", "RunPlugin({})".format(build_url(handle, "watchlist_remove", imdb_id=imdb_id, media_type="movie"))),
        ])
        if rd_enabled and imdb_id:
            url = build_url(handle, "movie_sources", imdb_id=imdb_id, title=title, year=year)
            li.setProperty("IsPlayable", "true")
            xbmcplugin.addDirectoryItem(handle, url, li, isFolder=False)
        else:
            xbmcplugin.addDirectoryItem(handle, "", li, isFolder=False)
    for item in shows:
        show    = item.get("show", {})
        title   = show.get("title", "")
        year    = show.get("year", 0)
        ids     = show.get("ids", {})
        tmdb_id = str(ids.get("tmdb", ""))
        imdb_id = ids.get("imdb", "")
        poster, fanart = _tmdb_art(tmdb, tmdb_id, imdb_id, "tv")
        label = "{} ({})".format(title, year) if year else title
        url   = build_url(handle, "tv_seasons", tmdb_id=tmdb_id, show_title=title, show_year=year)
        li = xbmcgui.ListItem(label=label)
        li.setArt({"poster": poster, "fanart": fanart, "thumb": poster})
        _apply_info_tag(li, {"title": title, "year": year, "mediatype": "tvshow"})
        li.addContextMenuItems([
            ("Play Trailer", "RunPlugin({})".format(build_url(handle, "play_tv_trailer", tmdb_id=tmdb_id, title=title, year=year))),
            ("Remove from Watchlist", "RunPlugin({})".format(build_url(handle, "watchlist_remove", imdb_id=imdb_id, media_type="tv"))),
        ])
        xbmcplugin.addDirectoryItem(handle, url, li, isFolder=True)
    xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_NONE)
    xbmcplugin.endOfDirectory(handle)


# -- Notification helpers -------------------------------------------------------

def notify(msg, title="Black Knight", icon=xbmcgui.NOTIFICATION_INFO, ms=3000):
    xbmcgui.Dialog().notification(title, msg, icon, ms)

def notify_error(msg):
    notify(msg, icon=xbmcgui.NOTIFICATION_ERROR, ms=5000)


# -- Trakt personalized recommendations ----------------------------------------

def build_trakt_recommendations(handle, movies, shows, tmdb=None,
                                rd_enabled=False, trakt_authorized=False):
    xbmcplugin.setContent(handle, "movies")
    if not movies and not shows:
        xbmcgui.Dialog().notification("Black Knight", "No recommendations available", xbmcgui.NOTIFICATION_INFO, 3000)
        xbmcplugin.endOfDirectory(handle)
        return
    for item in movies:
        movie   = item.get("movie", {})
        title   = movie.get("title", "")
        year    = movie.get("year", 0)
        ids     = movie.get("ids", {})
        imdb_id = ids.get("imdb", "")
        tmdb_id = str(ids.get("tmdb", ""))
        poster, fanart = _tmdb_art(tmdb, tmdb_id, imdb_id, "movie")
        label = "[Movie] {} ({})".format(title, year) if year else "[Movie] {}".format(title)
        li = xbmcgui.ListItem(label=label)
        li.setArt({"poster": poster, "fanart": fanart, "thumb": poster})
        _apply_info_tag(li, {"title": title, "year": year, "mediatype": "movie"})
        if rd_enabled and imdb_id:
            url = build_url(handle, "movie_sources", imdb_id=imdb_id, title=title, year=year)
            li.setProperty("IsPlayable", "true")
            xbmcplugin.addDirectoryItem(handle, url, li, isFolder=False)
        else:
            xbmcplugin.addDirectoryItem(handle, "", li, isFolder=False)
    for item in shows:
        show    = item.get("show", {})
        title   = show.get("title", "")
        year    = show.get("year", 0)
        ids     = show.get("ids", {})
        tmdb_id = str(ids.get("tmdb", ""))
        imdb_id = ids.get("imdb", "")
        poster, fanart = _tmdb_art(tmdb, tmdb_id, imdb_id, "tv")
        label = "[TV] {} ({})".format(title, year) if year else "[TV] {}".format(title)
        url   = build_url(handle, "tv_seasons", tmdb_id=tmdb_id, show_title=title, show_year=year)
        li = xbmcgui.ListItem(label=label)
        li.setArt({"poster": poster, "fanart": fanart, "thumb": poster})
        _apply_info_tag(li, {"title": title, "year": year, "mediatype": "tvshow"})
        xbmcplugin.addDirectoryItem(handle, url, li, isFolder=True)
    xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_NONE)
    xbmcplugin.endOfDirectory(handle)


# -- Trakt browsing hub ---------------------------------------------------------

def build_trakt_hub(handle, username=""):
    """Top-level 'My Trakt' menu."""
    who = " ({})".format(username) if username else ""
    add_directory(handle, "Watchlist" + who,
                  build_url(handle, "watchlist"))
    add_directory(handle, "Continue Watching",
                  build_url(handle, "continue_watching"))
    add_directory(handle, "My Lists",
                  build_url(handle, "trakt_my_lists"))
    add_directory(handle, "Liked Lists",
                  build_url(handle, "trakt_liked_lists"))
    add_directory(handle, "Collection - Movies",
                  build_url(handle, "trakt_collection", media_type="movies"))
    add_directory(handle, "Collection - TV Shows",
                  build_url(handle, "trakt_collection", media_type="shows"))
    add_directory(handle, "Watched - Movies",
                  build_url(handle, "trakt_watched", media_type="movies"))
    add_directory(handle, "Watched - TV Shows",
                  build_url(handle, "trakt_watched", media_type="shows"))
    add_directory(handle, "Recommended For You",
                  build_url(handle, "trakt_recommendations"))
    end_listing(handle, content="files")


def build_trakt_lists_menu(handle, lists, liked=False):
    """Render a set of Trakt lists as browsable folders."""
    if not lists:
        notify("No lists found")
        end_listing(handle, content="files")
        return
    for entry in lists:
        # Liked lists nest the list under a "list" key; own lists are flat.
        lst = entry.get("list", entry) if liked else entry
        name  = lst.get("name", "Untitled")
        ids   = lst.get("ids", {}) or {}
        lid   = ids.get("trakt", "")
        count = lst.get("item_count", 0)
        owner = ((lst.get("user", {}) or {}).get("username", "")) if liked else ""

        label = name if not owner else "{}  [COLOR grey]by {}[/COLOR]".format(name, owner)
        if count:
            label = "{}  [COLOR grey]({} items)[/COLOR]".format(label, count)

        if liked and owner:
            url = build_url(handle, "trakt_list_items",
                            list_id=lid, list_name=name, owner=owner)
        else:
            url = build_url(handle, "trakt_list_items", list_id=lid, list_name=name)
        add_directory(handle, label, url,
                      info={"plot": lst.get("description", "") or ""})
    end_listing(handle, content="files")


def build_trakt_items(handle, movies, shows, tmdb=None, rd_enabled=False,
                      trakt_authorized=False, empty_msg="Nothing here yet"):
    """Render Trakt movie/show entries. Shared by lists, collection and watched."""
    if not movies and not shows:
        notify(empty_msg)
        end_listing(handle, content="files")
        return

    xbmcplugin.setContent(handle, "movies")

    for item in movies:
        movie   = item.get("movie", item) or {}
        title   = movie.get("title", "")
        year    = movie.get("year", 0)
        ids     = movie.get("ids", {}) or {}
        imdb_id = ids.get("imdb", "")
        tmdb_id = str(ids.get("tmdb", "") or "")
        poster, fanart = _tmdb_art(tmdb, tmdb_id, imdb_id, "movie")
        label = "[Movie] {} ({})".format(title, year) if year else "[Movie] {}".format(title)
        li = xbmcgui.ListItem(label=label)
        li.setArt({"poster": poster, "fanart": fanart, "thumb": poster})
        _apply_info_tag(li, {"title": title, "year": year, "mediatype": "movie"})
        ctx = []
        if tmdb_id:
            ctx.append(("Play Trailer", "RunPlugin({})".format(
                build_url(handle, "play_trailer", tmdb_id=tmdb_id, title=title, year=year))))
            ctx.append(("More Like This", "Container.Update({})".format(
                build_url(handle, "movie_similar", tmdb_id=tmdb_id))))
        if ctx:
            li.addContextMenuItems(ctx)
        if rd_enabled and imdb_id:
            url = build_url(handle, "movie_sources", imdb_id=imdb_id, title=title, year=year)
            li.setProperty("IsPlayable", "true")
            xbmcplugin.addDirectoryItem(handle, url, li, isFolder=False)
        else:
            xbmcplugin.addDirectoryItem(handle, "", li, isFolder=False)

    for item in shows:
        show    = item.get("show", item) or {}
        title   = show.get("title", "")
        year    = show.get("year", 0)
        ids     = show.get("ids", {}) or {}
        imdb_id = ids.get("imdb", "")
        tmdb_id = str(ids.get("tmdb", "") or "")
        poster, fanart = _tmdb_art(tmdb, tmdb_id, imdb_id, "tv")
        label = "[TV] {} ({})".format(title, year) if year else "[TV] {}".format(title)
        li = xbmcgui.ListItem(label=label)
        li.setArt({"poster": poster, "fanart": fanart, "thumb": poster})
        _apply_info_tag(li, {"title": title, "year": year, "mediatype": "tvshow"})
        if tmdb_id:
            li.addContextMenuItems([
                ("Play Trailer", "RunPlugin({})".format(
                    build_url(handle, "play_tv_trailer", tmdb_id=tmdb_id, title=title, year=year))),
                ("More Like This", "Container.Update({})".format(
                    build_url(handle, "tv_similar", tmdb_id=tmdb_id))),
            ])
        url = build_url(handle, "tv_seasons", tmdb_id=tmdb_id,
                        show_title=title, show_year=year)
        xbmcplugin.addDirectoryItem(handle, url, li, isFolder=True)

    xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_NONE)
    xbmcplugin.endOfDirectory(handle)


# -- Search results (multi: movies + TV) ----------------------------------------

def build_search_results(handle, results, tmdb, rd_enabled=False, trakt_authorized=False,
                         friend_name="", sharing_enabled=False,
                         total_pages=1, page=1, next_params=None):
    if not results:
        xbmcgui.Dialog().notification("Black Knight", "No results found", xbmcgui.NOTIFICATION_INFO, 3000)
        xbmcplugin.endOfDirectory(handle)
        return
    xbmcplugin.setContent(handle, "movies")
    for item in results:
        media_type = item.get("media_type", "")
        if media_type == "movie":
            mid    = item.get("id", "")
            title  = item.get("title", "")
            year   = str(item.get("release_date", ""))[:4]
            rating = item.get("vote_average", 0)
            plot   = item.get("overview", "")
            poster = tmdb.poster_url(item.get("poster_path"))
            fanart = tmdb.fanart_url(item.get("backdrop_path"))
            label  = "[Movie]  {} ({})".format(title, year) if year else "[Movie]  {}".format(title)
            info   = {"title": title, "year": int(year) if year.isdigit() else 0, "rating": float(rating), "plot": plot, "mediatype": "movie"}
            art    = {"poster": poster, "fanart": fanart, "thumb": poster}
            ctx = [
                ("Play Trailer", "RunPlugin({})".format(build_url(handle, "play_trailer", tmdb_id=mid, title=title, year=year if year.isdigit() else 0))),
                ("More Like This", "Container.Update({})".format(build_url(handle, "movie_similar", tmdb_id=mid, title=title))),
                ("Add to Library", "RunPlugin({})".format(build_url(handle, "library_add_movie", tmdb_id=mid, title=title, year=year if year.isdigit() else 0))),
            ]
            if sharing_enabled and friend_name:
                ctx.append(("Recommend to {}".format(friend_name), "RunPlugin({})".format(build_url(handle, "recommend", media_type="movie", tmdb_id=mid, title=title, year=year if year.isdigit() else 0))))
            if trakt_authorized:
                ctx.append(("+ Trakt Watchlist", "RunPlugin({})".format(build_url(handle, "watchlist_add", media_type="movie", tmdb_id=mid, title=title, year=year if year.isdigit() else 0))))
            if rd_enabled:
                url = build_url(handle, "movie_sources", tmdb_id=mid, title=title, year=year if year.isdigit() else 0)
                li = xbmcgui.ListItem(label=label)
                li.setProperty("IsPlayable", "true")
                _apply_info_tag(li, info)
                li.setArt(art)
                li.addContextMenuItems(ctx)
                xbmcplugin.addDirectoryItem(handle, url, li, isFolder=False)
            else:
                li = xbmcgui.ListItem(label=label)
                _apply_info_tag(li, info)
                li.setArt(art)
                li.addContextMenuItems(ctx)
                xbmcplugin.addDirectoryItem(handle, "", li, isFolder=False)

        elif media_type == "tv":
            sid    = item.get("id", "")
            title  = item.get("name", "")
            year   = str(item.get("first_air_date", ""))[:4]
            rating = item.get("vote_average", 0)
            plot   = item.get("overview", "")
            poster = tmdb.poster_url(item.get("poster_path"))
            fanart = tmdb.fanart_url(item.get("backdrop_path"))
            label  = "[TV]  {} ({})".format(title, year) if year else "[TV]  {}".format(title)
            url    = build_url(handle, "tv_seasons", tmdb_id=sid, show_title=title, show_year=year if year.isdigit() else 0)
            info   = {"title": title, "year": int(year) if year.isdigit() else 0, "rating": float(rating), "plot": plot, "mediatype": "tvshow"}
            art    = {"poster": poster, "fanart": fanart, "thumb": poster}
            ctx = [
                ("Play Trailer", "RunPlugin({})".format(build_url(handle, "play_tv_trailer", tmdb_id=sid, title=title, year=year if year.isdigit() else 0))),
                ("More Like This", "Container.Update({})".format(build_url(handle, "tv_similar", tmdb_id=sid, title=title))),
                ("Add to Library", "RunPlugin({})".format(build_url(handle, "library_add_show", tmdb_id=sid, title=title, year=year if year.isdigit() else 0))),
            ]
            if sharing_enabled and friend_name:
                ctx.append(("Recommend to {}".format(friend_name), "RunPlugin({})".format(build_url(handle, "recommend", media_type="tv", tmdb_id=sid, title=title, year=year if year.isdigit() else 0))))
            if trakt_authorized:
                ctx.append(("+ Trakt Watchlist", "RunPlugin({})".format(build_url(handle, "watchlist_add", media_type="tv", tmdb_id=sid, title=title, year=year if year.isdigit() else 0))))
            li = xbmcgui.ListItem(label=label)
            _apply_info_tag(li, info)
            li.setArt(art)
            li.addContextMenuItems(ctx)
            xbmcplugin.addDirectoryItem(handle, url, li, isFolder=True)
    if page < total_pages:
        kw = dict(next_params or {})
        kw["page"] = page + 1
        add_directory(handle, _next_page_label(page, total_pages), build_url(handle, "search", **kw))
    xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_NONE)
    xbmcplugin.endOfDirectory(handle)


# -- Shared picks (friend's list / my recommendations) -------------------------

def build_shared_picks(handle, movies, shows, tmdb=None, owner_name="", is_own_list=False, rd_enabled=False):
    xbmcplugin.setContent(handle, "movies")
    if not movies and not shows:
        lbl = "Your recommendation list is empty." if is_own_list else "{} hasn't added any picks yet.".format(owner_name)
        xbmcgui.Dialog().notification("Black Knight", lbl, xbmcgui.NOTIFICATION_INFO, 3000)
        xbmcplugin.endOfDirectory(handle)
        return
    for item in movies:
        movie   = item.get("movie", {})
        title   = movie.get("title", "")
        year    = movie.get("year", 0)
        ids     = movie.get("ids", {})
        imdb_id = ids.get("imdb", "")
        tmdb_id = str(ids.get("tmdb", ""))
        poster, fanart = _tmdb_art(tmdb, tmdb_id, imdb_id, "movie")
        label = "{} ({})".format(title, year) if year else title
        ctx = []
        if is_own_list and imdb_id:
            ctx.append(("Remove Recommendation", "RunPlugin({})".format(build_url(handle, "recommend_remove", media_type="movie", imdb_id=imdb_id, title=title))))
        li = xbmcgui.ListItem(label=label)
        li.setArt({"poster": poster, "fanart": fanart, "thumb": poster})
        _apply_info_tag(li, {"title": title, "year": year, "mediatype": "movie"})
        if ctx: li.addContextMenuItems(ctx)
        if rd_enabled and imdb_id:
            url = build_url(handle, "movie_sources", imdb_id=imdb_id, title=title, year=year)
            li.setProperty("IsPlayable", "true")
            xbmcplugin.addDirectoryItem(handle, url, li, isFolder=False)
        else:
            xbmcplugin.addDirectoryItem(handle, "", li, isFolder=False)
    for item in shows:
        show    = item.get("show", {})
        title   = show.get("title", "")
        year    = show.get("year", 0)
        ids     = show.get("ids", {})
        imdb_id = ids.get("imdb", "")
        tmdb_id = str(ids.get("tmdb", ""))
        poster, fanart = _tmdb_art(tmdb, tmdb_id, imdb_id, "tv")
        label = "{} ({})".format(title, year) if year else title
        url   = build_url(handle, "tv_seasons", tmdb_id=tmdb_id, show_title=title, show_year=year)
        ctx = [("Play Trailer", "RunPlugin({})".format(build_url(handle, "play_tv_trailer", tmdb_id=tmdb_id, title=title, year=year)))]
        if is_own_list and imdb_id:
            ctx.append(("Remove Recommendation", "RunPlugin({})".format(build_url(handle, "recommend_remove", media_type="tv", imdb_id=imdb_id, title=title))))
        li = xbmcgui.ListItem(label=label)
        li.setArt({"poster": poster, "fanart": fanart, "thumb": poster})
        _apply_info_tag(li, {"title": title, "year": year, "mediatype": "tvshow"})
        if ctx: li.addContextMenuItems(ctx)
        xbmcplugin.addDirectoryItem(handle, url, li, isFolder=True)
    xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_NONE)
    xbmcplugin.endOfDirectory(handle)

