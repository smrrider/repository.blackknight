"""
trakt.py — Trakt.tv API client for Black Knight (personal use).
Client credentials are hardcoded for single-user convenience.
Tokens are stored in a JSON file in the addon_data directory.
"""
import json
import os
import time
import xbmc
import xbmcaddon
import xbmcvfs

try:
    from urllib.request import urlopen, Request
    from urllib.error import URLError, HTTPError
except ImportError:
    from urllib2 import urlopen, Request, URLError, HTTPError

# Default Trakt application credentials.
#
# NOTE: these are the publicly-shipped credentials from the Seren addon,
# used here with the Captain's explicit authorisation for private household
# use. Consequences to be aware of:
#   * API calls share Seren's rate-limit quota.
#   * The authorised connection appears as "Seren" in the Trakt account's
#     Connected Applications list, not as Black Knight.
# To use a dedicated application instead, register one at
# trakt.tv/oauth/applications/new and set the values in Settings > Trakt,
# which override these defaults without a code change.
DEFAULT_CLIENT_ID     = "0c9a30819e4af6ffaf3b954cbeae9b54499088513863c03c02911de00ac2de79"
DEFAULT_CLIENT_SECRET = "bf02417f27b514cee6a8d135f2ddc261a15eecfb6ed6289c36239826dcdd1842"
BASE_URL              = "https://api.trakt.tv"


def _setting(key, fallback=""):
    """Read an addon setting, tolerating any KODI weirdness."""
    try:
        val = xbmcaddon.Addon().getSetting(key)
    except Exception:
        return fallback
    return val.strip() if val and val.strip() else fallback


def client_id():
    """User-supplied Trakt client ID, else the built-in default."""
    return _setting("trakt_client_id", DEFAULT_CLIENT_ID)


def client_secret():
    """User-supplied Trakt client secret, else the built-in default."""
    return _setting("trakt_client_secret", DEFAULT_CLIENT_SECRET)

_ADDON_DATA   = xbmcvfs.translatePath(
    "special://profile/addon_data/plugin.video.blackknight/"
)
TOKEN_FILE    = os.path.join(_ADDON_DATA, "trakt_token.json")
NOW_PLAYING   = os.path.join(_ADDON_DATA, "now_playing.json")


class TraktError(Exception):
    pass


class TraktNotAuthorized(TraktError):
    pass


class Trakt:

    # ── Token storage ──────────────────────────────────────────────────────────

    def _load(self):
        try:
            if os.path.exists(TOKEN_FILE):
                with open(TOKEN_FILE, "r") as f:
                    return json.load(f)
        except Exception:
            pass
        return {}

    def _save(self, access_token, refresh_token, expires_in):
        os.makedirs(_ADDON_DATA, exist_ok=True)
        with open(TOKEN_FILE, "w") as f:
            json.dump({
                "access_token":  access_token,
                "refresh_token": refresh_token,
                "expires_at":    time.time() + expires_in,
            }, f)

    def _access_token(self):
        data = self._load()
        # Refresh proactively if within 7 days of expiry
        if data.get("access_token") and data.get("expires_at", 0) < time.time() + 604800:
            try:
                self._do_refresh(data.get("refresh_token", ""))
                data = self._load()
            except TraktError:
                pass
        return data.get("access_token", "")

    def is_authorized(self):
        """True only if a token exists AND has not passed its expiry.
        Presence alone is not enough - a long-dead token made the UI claim
        'connected' while every API call silently failed.
        """
        data = self._load()
        if not data.get("access_token", ""):
            return False
        # _access_token() refreshes proactively; if expiry is already in the
        # past and refresh could not fix it, report not-authorized.
        if data.get("expires_at", 0) <= time.time():
            self._access_token()          # one refresh attempt
            data = self._load()
            if data.get("expires_at", 0) <= time.time():
                return False
        return bool(data.get("access_token", ""))

    def connection_status(self):
        """Diagnose the Trakt connection. Returns (ok:bool, message:str)."""
        if not self._load().get("access_token", ""):
            base = "Not signed in."
        else:
            try:
                me = self._get("/users/me")
                return True, "Signed in as {}".format(me.get("username", "?"))
            except TraktNotAuthorized:
                base = "Sign-in is no longer valid."
            except TraktError as e:
                msg = str(e)
                if "403" not in msg and "401" not in msg:
                    return False, "Trakt unreachable: {}".format(msg)
                base = "Trakt rejected the connection."

        # Confirm the addon can still talk to Trakt at all before advising.
        try:
            self._request("GET", "/movies/trending?limit=1", auth=False)
            return False, base + "\n\nUse 'Connect / Reconnect Trakt account'."
        except TraktError as e:
            return False, base + "\n\nTrakt is not reachable right now: {}".format(e)


    # ── HTTP ───────────────────────────────────────────────────────────────────

    def _headers(self, auth=True):
        h = {
            "Content-Type":      "application/json",
            "Accept":            "application/json",
            "trakt-api-version": "2",
            "trakt-api-key":     client_id(),
            "User-Agent":        "BlackKnight/1.0 (KODI addon; personal use)",
        }
        if auth:
            tok = self._access_token()
            if tok:
                h["Authorization"] = "Bearer " + tok
        return h

    def _request(self, method, path, data=None, auth=True, _retried=False):
        url  = BASE_URL + path
        body = json.dumps(data).encode("utf-8") if data is not None else None
        req  = Request(url, data=body, headers=self._headers(auth=auth))
        req.get_method = lambda: method
        try:
            resp = urlopen(req, timeout=10)
            raw  = resp.read()
            return json.loads(raw.decode("utf-8")) if raw.strip() else {}
        except HTTPError as e:
            body_msg = ""
            try:
                body_msg = " — " + e.read().decode("utf-8", errors="replace")
            except Exception:
                pass
            if e.code == 401 and auth and not _retried:
                try:
                    self._do_refresh(self._load().get("refresh_token", ""))
                    return self._request(method, path, data=data, auth=auth, _retried=True)
                except TraktError:
                    raise TraktNotAuthorized(
                        "Trakt sign-in expired - reconnect from Settings > Trakt")
            raise TraktError("HTTP {}{}".format(e.code, body_msg))
        except URLError as e:
            raise TraktError("Cannot reach Trakt: {}".format(e.reason))
        except Exception as e:
            raise TraktError("Request failed: {}".format(e))

    def _get(self, path, auth=True):
        return self._request("GET", path, auth=auth)

    def _post(self, path, data, auth=True):
        return self._request("POST", path, data=data, auth=auth)

    # ── Auth lifecycle ─────────────────────────────────────────────────────────

    def revoke(self):
        """Revoke the stored token with Trakt and delete it locally."""
        tok = self._load().get("access_token", "")
        if tok:
            try:
                self._request("POST", "/oauth/revoke", {
                    "token":         tok,
                    "client_id":     client_id(),
                    "client_secret": client_secret(),
                }, auth=False)
            except TraktError:
                pass
        try:
            if os.path.exists(TOKEN_FILE):
                os.remove(TOKEN_FILE)
        except Exception:
            pass

    def start_device_auth(self):
        """Begin the Trakt device flow.
        Returns dict: user_code, verification_url, device_code, interval, expires_in.
        """
        return self._post("/oauth/device/code", {"client_id": client_id()}, auth=False)

    def poll_device_auth(self, device_code):
        """Poll once. Returns True if authorized (tokens saved), False if still pending."""
        try:
            data = self._post("/oauth/device/token", {
                "code":          device_code,
                "client_id":     client_id(),
                "client_secret": client_secret(),
            }, auth=False)
            if "access_token" in data:
                self._save(data["access_token"], data["refresh_token"],
                           data.get("expires_in", 7776000))
                return True
            return False
        except TraktError as e:
            if "400" in str(e):
                return False  # authorization_pending
            raise

    def _do_refresh(self, refresh_token):
        if not refresh_token:
            raise TraktNotAuthorized("No refresh token stored")
        data = self._post("/oauth/token", {
            "refresh_token": refresh_token,
            "client_id":     client_id(),
            "client_secret": client_secret(),
            "redirect_uri":  "urn:ietf:wg:oauth:2.0:oob",
            "grant_type":    "refresh_token",
        }, auth=False)
        self._save(data["access_token"], data["refresh_token"],
                   data.get("expires_in", 7776000))

    # ── Now-playing handoff ────────────────────────────────────────────────────

    @staticmethod
    def write_now_playing(imdb_id, media_type="movie", title="", year=0,
                          show_title="", show_year=0, season=None, episode=None,
                          resume_seconds=0):
        """
        Write a handoff file for the background service to pick up when
        playback starts. Includes Trakt metadata and optional resume offset.
        """
        os.makedirs(_ADDON_DATA, exist_ok=True)
        payload = {
            "media_type":     media_type,
            "imdb_id":        imdb_id,
            "title":          title,
            "year":           int(year or 0),
            "show_title":     show_title,
            "show_year":      int(show_year or 0),
            "season":         int(season) if season is not None else None,
            "episode":        int(episode) if episode is not None else None,
            "resume_seconds": int(resume_seconds or 0),
        }
        with open(NOW_PLAYING, "w") as f:
            json.dump(payload, f)

    @staticmethod
    def read_now_playing():
        """Read and delete the handoff file. Returns dict or None."""
        try:
            if os.path.exists(NOW_PLAYING):
                with open(NOW_PLAYING, "r") as f:
                    data = json.load(f)
                os.remove(NOW_PLAYING)
                return data
        except Exception as e:
            xbmc.log("[BlackKnight/Trakt] read_now_playing error: {}".format(e), xbmc.LOGWARNING)
        return None

    # ── Scrobble ───────────────────────────────────────────────────────────────

    @staticmethod
    def _build_payload(imdb_id, media_type, title, year, show_title, show_year,
                       season, episode, progress):
        if media_type == "movie":
            return {
                "movie":       {"title": title, "year": int(year or 0),
                                "ids": {"imdb": imdb_id}},
                "progress":    float(progress),
                "app_version": "1.0.0",
            }
        return {
            "show":        {"title": show_title or title,
                            "year":  int(show_year or year or 0),
                            "ids":   {"imdb": imdb_id}},
            "episode":     {"season": int(season or 1), "number": int(episode or 1)},
            "progress":    float(progress),
            "app_version": "1.0.0",
        }

    def _scrobble(self, verb, np, progress):
        """Internal: POST /scrobble/{verb} using a now-playing dict."""
        if not self.is_authorized():
            return
        payload = self._build_payload(
            imdb_id=np.get("imdb_id", ""),
            media_type=np.get("media_type", "movie"),
            title=np.get("title", ""),
            year=np.get("year", 0),
            show_title=np.get("show_title", ""),
            show_year=np.get("show_year", 0),
            season=np.get("season"),
            episode=np.get("episode"),
            progress=progress,
        )
        try:
            self._post("/scrobble/{}".format(verb), payload)
            xbmc.log("[BlackKnight/Trakt] scrobble/{} {} @ {}%".format(
                verb, np.get("imdb_id", ""), int(progress)), xbmc.LOGINFO)
        except TraktError as e:
            xbmc.log("[BlackKnight/Trakt] scrobble/{} failed: {}".format(verb, e),
                     xbmc.LOGWARNING)

    def scrobble_start(self, np, progress=1):
        self._scrobble("start", np, progress)

    def scrobble_pause(self, np, progress):
        self._scrobble("pause", np, progress)

    def scrobble_stop(self, np, progress):
        self._scrobble("stop", np, progress)

    # ── Watchlist ──────────────────────────────────────────────────────────────

    def get_watchlist(self, media_type="movies"):
        """media_type: 'movies' or 'shows'. Returns list of Trakt watchlist items."""
        try:
            return self._get("/sync/watchlist/{}?sort=added,asc".format(media_type))
        except TraktError as e:
            xbmc.log("[BlackKnight/Trakt] get_watchlist failed: {}".format(e), xbmc.LOGWARNING)
            return []

    def add_to_watchlist(self, imdb_id, media_type="movie", title="", year=0):
        key  = "movies" if media_type == "movie" else "shows"
        item = {"ids": {"imdb": imdb_id}, "title": title, "year": int(year or 0)}
        try:
            self._post("/sync/watchlist", {key: [item]})
        except TraktError as e:
            xbmc.log("[BlackKnight/Trakt] add_watchlist failed: {}".format(e), xbmc.LOGWARNING)
            raise

    def remove_from_watchlist(self, imdb_id, media_type="movie"):
        key  = "movies" if media_type == "movie" else "shows"
        try:
            self._post("/sync/watchlist/remove", {key: [{"ids": {"imdb": imdb_id}}]})
        except TraktError as e:
            xbmc.log("[BlackKnight/Trakt] remove_watchlist failed: {}".format(e), xbmc.LOGWARNING)
            raise

    # ── Continue watching (playback progress) ──────────────────────────────────

    def get_playback(self, media_type="movies"):
        """media_type: 'movies' or 'episodes'. Returns items with resume progress."""
        try:
            return self._get("/sync/playback/{}?limit=20&extended=full".format(media_type))
        except TraktError as e:
            xbmc.log("[BlackKnight/Trakt] get_playback failed: {}".format(e), xbmc.LOGWARNING)
            return []

    def delete_playback(self, playback_id):
        try:
            self._request("DELETE", "/sync/playback/{}".format(playback_id))
        except TraktError as e:
            xbmc.log("[BlackKnight/Trakt] delete_playback failed: {}".format(e), xbmc.LOGWARNING)

    # ── Custom lists (sharing) ─────────────────────────────────────────────────

    def get_list_items(self, username, list_slug):
        """
        Fetch all items from a public Trakt list. No auth required.
        Returns (movies_list, shows_list) — each a list of Trakt item dicts.
        """
        try:
            items = self._get(
                "/users/{}/lists/{}/items".format(username, list_slug),
                auth=False
            )
            movies = [i for i in items if i.get("type") == "movie"]
            shows  = [i for i in items if i.get("type") == "show"]
            return movies, shows
        except TraktError as e:
            xbmc.log("[BlackKnight/Trakt] get_list_items failed: {}".format(e), xbmc.LOGWARNING)
            return [], []

    def add_to_list(self, username, list_slug, imdb_id, media_type="movie",
                    title="", year=0):
        """Add a movie or show to an authenticated user's list."""
        key  = "movies" if media_type == "movie" else "shows"
        item = {"ids": {"imdb": imdb_id}, "title": title, "year": int(year or 0)}
        try:
            self._post("/users/{}/lists/{}/items".format(username, list_slug),
                       {key: [item]})
            xbmc.log("[BlackKnight/Trakt] added to list {}/{}: {}".format(
                username, list_slug, imdb_id), xbmc.LOGINFO)
        except TraktError as e:
            xbmc.log("[BlackKnight/Trakt] add_to_list failed: {}".format(e), xbmc.LOGWARNING)
            raise

    def remove_from_list(self, username, list_slug, imdb_id, media_type="movie"):
        """Remove a movie or show from an authenticated user's list."""
        key  = "movies" if media_type == "movie" else "shows"
        try:
            self._post("/users/{}/lists/{}/items/remove".format(username, list_slug),
                       {key: [{"ids": {"imdb": imdb_id}}]})
            xbmc.log("[BlackKnight/Trakt] removed from list {}/{}: {}".format(
                username, list_slug, imdb_id), xbmc.LOGINFO)
        except TraktError as e:
            xbmc.log("[BlackKnight/Trakt] remove_from_list failed: {}".format(e), xbmc.LOGWARNING)
            raise

    # ── Personalized Recommendations ──────────────────────────────────────────

    def recommendations_movies(self, limit=20):
        """Trakt personalized movie recommendations (requires auth)."""
        try:
            return self._get("/recommendations/movies?limit={}".format(limit))
        except TraktError as e:
            xbmc.log("[BlackKnight/Trakt] recommendations_movies failed: {}".format(e), xbmc.LOGWARNING)
            return []

    def recommendations_shows(self, limit=20):
        """Trakt personalized TV show recommendations (requires auth)."""
        try:
            return self._get("/recommendations/shows?limit={}".format(limit))
        except TraktError as e:
            xbmc.log("[BlackKnight/Trakt] recommendations_shows failed: {}".format(e), xbmc.LOGWARNING)
            return []

    # ── Watched history ───────────────────────────────────────────────────────

    # ── Personal lists / collection ───────────────────────────────────────────

    def get_my_lists(self):
        """The signed-in user's own custom lists."""
        try:
            return self._get("/users/me/lists")
        except TraktError as e:
            xbmc.log("[BlackKnight/Trakt] get_my_lists failed: {}".format(e), xbmc.LOGWARNING)
            return []

    def get_liked_lists(self):
        """Lists the user has liked (other people's lists)."""
        try:
            return self._get("/users/likes/lists?limit=100")
        except TraktError as e:
            xbmc.log("[BlackKnight/Trakt] get_liked_lists failed: {}".format(e), xbmc.LOGWARNING)
            return []

    def get_my_list_items(self, list_id):
        """Items in one of the user's own lists. Returns (movies, shows)."""
        try:
            items = self._get("/users/me/lists/{}/items".format(list_id))
            return ([i for i in items if i.get("type") == "movie"],
                    [i for i in items if i.get("type") == "show"])
        except TraktError as e:
            xbmc.log("[BlackKnight/Trakt] get_my_list_items failed: {}".format(e), xbmc.LOGWARNING)
            return [], []

    def get_collection(self, media_type="movies"):
        """Collected movies or shows. media_type: movies or shows."""
        try:
            return self._get("/sync/collection/{}".format(media_type))
        except TraktError as e:
            xbmc.log("[BlackKnight/Trakt] get_collection failed: {}".format(e), xbmc.LOGWARNING)
            return []

    def get_watched(self, media_type="movies"):
        """All watched movies or shows with play counts. media_type: movies or shows."""
        try:
            return self._get("/sync/watched/{}".format(media_type))
        except TraktError as e:
            xbmc.log("[BlackKnight/Trakt] get_watched failed: {}".format(e), xbmc.LOGWARNING)
            return []
