"""
realdebrid.py — Real-Debrid API v1 wrapper.
Handles magnet addition, file selection, link unrestriction, and account info.
"""

import json
import os
import time
import xbmc
import xbmcvfs

try:
    from urllib.request import urlopen, Request
    from urllib.error import URLError, HTTPError
    from urllib.parse import urlencode
except ImportError:
    from urllib2 import urlopen, Request, URLError, HTTPError
    from urllib import urlencode

RD_BASE  = "https://api.real-debrid.com/rest/1.0"
RD_OAUTH = "https://api.real-debrid.com/oauth/v2"

# Public client ID published by Real-Debrid for open source applications.
# Scopes: unrestrict, torrents, downloads, user.
OPEN_SOURCE_CLIENT_ID = "X245A4XAIBGVM"
DEVICE_GRANT_TYPE     = "http://oauth.net/grant_type/device/1.0"

_ADDON_DATA = xbmcvfs.translatePath(
    "special://profile/addon_data/plugin.video.blackknight/"
)
RD_TOKEN_FILE = os.path.join(_ADDON_DATA, "rd_token.json")

# Refresh this many seconds before the access token actually expires.
_REFRESH_MARGIN = 300

# Torrent status strings returned by RD
STATUS_WAITING     = "waiting_files_selection"
STATUS_QUEUED      = "queued"
STATUS_DOWNLOADING = "downloading"
STATUS_DOWNLOADED  = "downloaded"
STATUS_ERROR       = "error"
STATUS_DEAD        = "dead"
STATUS_MAGNET_ERR  = "magnet_error"

POLL_INTERVAL = 2   # seconds between status checks
POLL_TIMEOUT  = 60  # seconds before giving up


class RealDebridError(Exception):
    pass


class RealDebridNotAuthorized(RealDebridError):
    pass


# ── OAuth device flow ────────────────────────────────────────────────────────
#
# Real-Debrid's device flow, intended for devices without a usable keyboard:
#   1. GET  /oauth/v2/device/code         -> user_code + verification_url
#   2. user enters the code at real-debrid.com/device
#   3. GET  /oauth/v2/device/credentials  -> client_id + client_secret (polled)
#   4. POST /oauth/v2/token               -> access_token + refresh_token
#
# Access tokens are short lived (about an hour), so the refresh step is not
# optional - without it playback dies partway through an evening.

def _oauth_get(path, params):
    url = RD_OAUTH + path + "?" + urlencode(params)
    try:
        resp = urlopen(Request(url, headers={"Accept": "application/json"}), timeout=15)
        raw = resp.read()
        return json.loads(raw.decode("utf-8")) if raw else {}
    except HTTPError as e:
        body = ""
        try:
            body = e.read().decode("utf-8", errors="ignore")
        except Exception:
            pass
        raise RealDebridError("RD HTTP {}: {}".format(e.code, body or str(e)))
    except URLError as e:
        raise RealDebridError("RD unreachable: {}".format(e.reason))


def _oauth_post(path, data):
    url = RD_OAUTH + path
    body = urlencode(data).encode("utf-8")
    try:
        resp = urlopen(Request(url, data=body,
                               headers={"Accept": "application/json"}), timeout=15)
        raw = resp.read()
        return json.loads(raw.decode("utf-8")) if raw else {}
    except HTTPError as e:
        body = ""
        try:
            body = e.read().decode("utf-8", errors="ignore")
        except Exception:
            pass
        raise RealDebridError("RD HTTP {}: {}".format(e.code, body or str(e)))
    except URLError as e:
        raise RealDebridError("RD unreachable: {}".format(e.reason))


def start_device_auth():
    """Step 1. Returns dict with user_code, verification_url, device_code, interval."""
    return _oauth_get("/device/code", {
        "client_id":       OPEN_SOURCE_CLIENT_ID,
        "new_credentials": "yes",
    })


def poll_device_credentials(device_code):
    """Step 3. Returns (client_id, client_secret) once approved, else (None, None)."""
    try:
        data = _oauth_get("/device/credentials", {
            "client_id": OPEN_SOURCE_CLIENT_ID,
            "code":      device_code,
        })
    except RealDebridError:
        return None, None          # still pending - RD 4xx until approved
    cid = data.get("client_id")
    sec = data.get("client_secret")
    return (cid, sec) if cid and sec else (None, None)


def exchange_token(client_id, client_secret, device_code):
    """Step 4. Exchange approved credentials for access/refresh tokens."""
    data = _oauth_post("/token", {
        "client_id":     client_id,
        "client_secret": client_secret,
        "code":          device_code,
        "grant_type":    DEVICE_GRANT_TYPE,
    })
    if not data.get("access_token"):
        raise RealDebridError("Real-Debrid did not return an access token")
    save_token(client_id, client_secret, data)
    return data


# ── Token storage ────────────────────────────────────────────────────────────

def save_token(client_id, client_secret, token):
    try:
        os.makedirs(_ADDON_DATA, exist_ok=True)
    except Exception:
        pass
    with open(RD_TOKEN_FILE, "w") as f:
        json.dump({
            "client_id":     client_id,
            "client_secret": client_secret,
            "access_token":  token.get("access_token", ""),
            "refresh_token": token.get("refresh_token", ""),
            "expires_at":    time.time() + int(token.get("expires_in", 3600)),
        }, f)


def load_token():
    try:
        if os.path.exists(RD_TOKEN_FILE):
            with open(RD_TOKEN_FILE, "r") as f:
                return json.load(f)
    except Exception:
        pass
    return {}


def clear_token():
    try:
        if os.path.exists(RD_TOKEN_FILE):
            os.remove(RD_TOKEN_FILE)
    except Exception:
        pass


def _refresh(data):
    """Exchange the refresh token for a fresh access token."""
    token = _oauth_post("/token", {
        "client_id":     data.get("client_id", ""),
        "client_secret": data.get("client_secret", ""),
        "code":          data.get("refresh_token", ""),
        "grant_type":    DEVICE_GRANT_TYPE,
    })
    if not token.get("access_token"):
        raise RealDebridNotAuthorized("Could not refresh Real-Debrid token")
    # RD may omit refresh_token on refresh - keep the existing one.
    token.setdefault("refresh_token", data.get("refresh_token", ""))
    save_token(data.get("client_id", ""), data.get("client_secret", ""), token)
    return token["access_token"]


def oauth_access_token():
    """Current OAuth access token, refreshed if near expiry. '' if not signed in."""
    data = load_token()
    if not data.get("access_token"):
        return ""
    if data.get("expires_at", 0) - _REFRESH_MARGIN <= time.time():
        try:
            return _refresh(data)
        except RealDebridError as e:
            xbmc.log("[BlackKnight/RD] token refresh failed: {}".format(e),
                     xbmc.LOGWARNING)
            return ""
    return data["access_token"]


def is_device_authorized():
    return bool(load_token().get("access_token"))


class RealDebrid:
    """Real-Debrid REST client."""

    def __init__(self, api_key=None):
        """A device-flow OAuth token wins if one is stored; otherwise fall back
        to the manually entered API key so existing setups keep working."""
        token = oauth_access_token()
        self.using_oauth = bool(token)
        if not token:
            token = api_key
        if not token:
            raise RealDebridNotAuthorized(
                "Real-Debrid not connected. Use Settings > "
                "Connect Real-Debrid account.")
        self.api_key = token
        self._headers = {
            "Authorization": "Bearer {}".format(token),
            "Accept":        "application/json",
        }

    # ── Low-level ─────────────────────────────────────────────────────────────

    def _request(self, method, path, data=None):
        url = RD_BASE + path
        body = urlencode(data).encode("utf-8") if data else None
        xbmc.log("[BlackKnight/RD] {} {}".format(method, url), xbmc.LOGDEBUG)
        try:
            req = Request(url, data=body, headers=self._headers)
            req.get_method = lambda: method
            resp = urlopen(req, timeout=15)
            raw = resp.read()
            if raw:
                return json.loads(raw.decode("utf-8"))
            return {}
        except HTTPError as e:
            body = e.read().decode("utf-8", errors="ignore")
            try:
                err = json.loads(body)
                msg = err.get("error", body)
            except Exception:
                msg = body or str(e)
            raise RealDebridError("RD HTTP {}: {}".format(e.code, msg))
        except URLError as e:
            raise RealDebridError("RD unreachable: {}".format(e.reason))

    def _get(self, path, params=None):
        p = ("?" + urlencode(params)) if params else ""
        return self._request("GET", path + p)

    def _post(self, path, data=None):
        return self._request("POST", path, data=data)

    def _delete(self, path):
        return self._request("DELETE", path)

    # ── Account ───────────────────────────────────────────────────────────────

    def account_info(self):
        return self._get("/user")

    def is_authenticated(self):
        try:
            self.account_info()
            return True
        except RealDebridError:
            return False

    # ── Link unrestriction ────────────────────────────────────────────────────

    def unrestrict_link(self, link, password=None):
        """
        Unrestrict a hoster link and return the direct stream URL.
        This is the fast path when Torrentio already gives us an RD URL.
        """
        data = {"link": link}
        if password:
            data["password"] = password
        result = self._post("/unrestrict/link", data=data)
        direct = result.get("download", "")
        if not direct:
            raise RealDebridError("No download URL returned by RD unrestrict")
        return direct

    # ── Torrent / magnet flow ─────────────────────────────────────────────────

    def add_magnet(self, magnet_url):
        """Add a magnet link to RD. Returns torrent ID."""
        result = self._post("/torrents/addMagnet", data={"magnet": magnet_url})
        torrent_id = result.get("id", "")
        if not torrent_id:
            raise RealDebridError("RD did not return a torrent ID")
        return torrent_id

    def select_files(self, torrent_id, file_ids="all"):
        """Select files from a torrent. Pass 'all' or comma-separated IDs."""
        self._post("/torrents/selectFiles/{}".format(torrent_id),
                   data={"files": file_ids})

    def torrent_info(self, torrent_id):
        return self._get("/torrents/info/{}".format(torrent_id))

    def delete_torrent(self, torrent_id):
        self._delete("/torrents/delete/{}".format(torrent_id))

    def instant_availability(self, info_hash):
        """
        Check RD cache for a hash.
        Returns the availability dict (may be empty if not cached).
        """
        try:
            result = self._get("/torrents/instantAvailability/{}".format(
                info_hash.lower()
            ))
            return result
        except RealDebridError:
            return {}

    def is_cached(self, info_hash):
        """Return True if RD has this hash cached."""
        avail = self.instant_availability(info_hash)
        # avail = { hash: { rd: [ {file_id: ...}, ... ] } }
        if not avail:
            return False
        for _hash_key, host_data in avail.items():
            if isinstance(host_data, dict) and host_data.get("rd"):
                return True
        return False

    def resolve_magnet(self, magnet_url, info_hash=None):
        """
        Full magnet → direct URL flow:
          1. Add magnet
          2. Select all files
          3. Poll until downloaded
          4. Unrestrict the first video link
        Returns the direct stream URL string.
        """
        torrent_id = self.add_magnet(magnet_url)
        try:
            self.select_files(torrent_id)
            deadline = time.time() + POLL_TIMEOUT
            while time.time() < deadline:
                info = self.torrent_info(torrent_id)
                status = info.get("status", "")
                xbmc.log("[BlackKnight/RD] torrent status: {}".format(status), xbmc.LOGDEBUG)

                if status == STATUS_DOWNLOADED:
                    links = info.get("links", [])
                    if not links:
                        raise RealDebridError("Torrent ready but no links returned")
                    # Unrestrict the first link
                    return self.unrestrict_link(links[0])

                if status in (STATUS_ERROR, STATUS_DEAD, STATUS_MAGNET_ERR):
                    raise RealDebridError("Torrent failed with status: {}".format(status))

                time.sleep(POLL_INTERVAL)

            raise RealDebridError("Timed out waiting for RD torrent to download")
        except Exception:
            # Clean up the torrent on failure
            try:
                self.delete_torrent(torrent_id)
            except Exception:
                pass
            raise

    # ── Downloads list ────────────────────────────────────────────────────────

    def get_downloads(self, page=1):
        return self._get("/downloads", params={"page": page})

    def get_torrents(self, page=1, limit=50):
        return self._get("/torrents", params={"page": page, "limit": limit})
