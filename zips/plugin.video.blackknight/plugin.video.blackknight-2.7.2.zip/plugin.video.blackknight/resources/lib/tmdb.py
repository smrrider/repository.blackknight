"""
tmdb.py — TMDB API wrapper (v3)
Fetches movie and TV show metadata, posters, and fanart.
"""

import json
import xbmc

try:
    from urllib.request import urlopen, Request
    from urllib.error import URLError, HTTPError
    from urllib.parse import urlencode, quote
except ImportError:
    from urllib2 import urlopen, Request, URLError, HTTPError
    from urllib import urlencode, quote

TMDB_BASE = "https://api.themoviedb.org/3"
IMAGE_BASE = "https://image.tmdb.org/t/p"

_provider_logo_cache = {}

POSTER_SIZE = "w500"
FANART_SIZE = "w1280"
STILL_SIZE  = "w300"
THUMB_SIZE  = "w342"


class TMDBError(Exception):
    pass


class TMDB:
    """TMDB v3 REST client."""

    def __init__(self, api_key, language="en-US"):
        self.api_key = api_key
        self.language = language

    # ── Low-level ────────────────────────────────────────────────────────────

    def _get(self, path, params=None):
        if not self.api_key:
            raise TMDBError("TMDB API key not configured")
        p = {"api_key": self.api_key, "language": self.language}
        if params:
            p.update(params)
        url = TMDB_BASE + path + "?" + urlencode(p)
        xbmc.log("[BlackKnight/TMDB] GET {}".format(url), xbmc.LOGDEBUG)
        try:
            req = Request(url, headers={"Accept": "application/json"})
            response = urlopen(req, timeout=10)
            return json.loads(response.read().decode("utf-8"))
        except HTTPError as e:
            raise TMDBError("HTTP {}: {}".format(e.code, path))
        except URLError as e:
            raise TMDBError("TMDB unreachable: {}".format(e.reason))
        except Exception as e:
            raise TMDBError("TMDB request failed: {}".format(e))

    # ── Image URL helpers ─────────────────────────────────────────────────────

    @staticmethod
    def poster_url(poster_path, size=POSTER_SIZE):
        if not poster_path:
            return ""
        return "{}/{}{}" .format(IMAGE_BASE, size, poster_path)

    @staticmethod
    def fanart_url(backdrop_path, size=FANART_SIZE):
        if not backdrop_path:
            return ""
        return "{}/{}{}" .format(IMAGE_BASE, size, backdrop_path)

    @staticmethod
    def still_url(still_path, size=STILL_SIZE):
        if not still_path:
            return ""
        return "{}/{}{}" .format(IMAGE_BASE, size, still_path)

    # ── Movies ───────────────────────────────────────────────────────────────

    def trending_movies(self, time_window="day", page=1):
        """Trending movies. time_window: 'day' or 'week'."""
        data = self._get("/trending/movie/{}".format(time_window), {"page": page})
        return data.get("results", []), data.get("total_pages", 1)

    def trending_tv(self, time_window="day", page=1):
        """Trending TV shows. time_window: 'day' or 'week'."""
        data = self._get("/trending/tv/{}".format(time_window), {"page": page})
        return data.get("results", []), data.get("total_pages", 1)

    def popular_movies(self, page=1):
        data = self._get("/movie/popular", {"page": page})
        return data.get("results", []), data.get("total_pages", 1)

    def top_rated_movies(self, page=1):
        data = self._get("/movie/top_rated", {"page": page})
        return data.get("results", []), data.get("total_pages", 1)

    def now_playing_movies(self, page=1):
        """Movies currently in theaters."""
        data = self._get("/movie/now_playing", {"page": page})
        return data.get("results", []), data.get("total_pages", 1)

    def upcoming_movies(self, page=1):
        """Movies releasing soon."""
        data = self._get("/movie/upcoming", {"page": page})
        return data.get("results", []), data.get("total_pages", 1)

    def search_movies(self, query, page=1):
        data = self._get("/search/movie", {"query": query, "page": page})
        return data.get("results", []), data.get("total_pages", 1)

    def movie_details(self, movie_id):
        return self._get(
            "/movie/{}".format(movie_id),
            {"append_to_response": "credits,videos,belongs_to_collection"}
        )

    def movie_recommendations(self, movie_id, page=1):
        """TMDB More Like This for a movie."""
        try:
            data = self._get("/movie/{}/recommendations".format(movie_id), {"page": page})
            return data.get("results", []), data.get("total_pages", 1)
        except TMDBError:
            return [], 1

    def movie_similar(self, movie_id, page=1):
        """TMDB similar movies (based on genres/keywords)."""
        try:
            data = self._get("/movie/{}/similar".format(movie_id), {"page": page})
            return data.get("results", []), data.get("total_pages", 1)
        except TMDBError:
            return [], 1

    # ── TV Shows ─────────────────────────────────────────────────────────────

    def popular_tv(self, page=1):
        data = self._get("/tv/popular", {"page": page})
        return data.get("results", []), data.get("total_pages", 1)

    def top_rated_tv(self, page=1):
        data = self._get("/tv/top_rated", {"page": page})
        return data.get("results", []), data.get("total_pages", 1)

    def tv_on_the_air(self, page=1):
        """TV shows currently airing (within 7 days)."""
        data = self._get("/tv/on_the_air", {"page": page})
        return data.get("results", []), data.get("total_pages", 1)

    def tv_airing_today(self, page=1):
        """TV episodes airing today."""
        data = self._get("/tv/airing_today", {"page": page})
        return data.get("results", []), data.get("total_pages", 1)

    def search_tv(self, query, page=1):
        data = self._get("/search/tv", {"query": query, "page": page})
        return data.get("results", []), data.get("total_pages", 1)

    def tv_details(self, tv_id):
        return self._get(
            "/tv/{}".format(tv_id),
            {"append_to_response": "credits,videos"}
        )

    def tv_seasons(self, tv_id):
        details = self.tv_details(tv_id)
        return details.get("seasons", [])

    def tv_episodes(self, tv_id, season_number):
        data = self._get("/tv/{}/season/{}".format(tv_id, season_number))
        return data.get("episodes", [])

    def tv_recommendations(self, tv_id, page=1):
        """TMDB More Like This for a TV show."""
        try:
            data = self._get("/tv/{}/recommendations".format(tv_id), {"page": page})
            return data.get("results", []), data.get("total_pages", 1)
        except TMDBError:
            return [], 1

    def tv_similar(self, tv_id, page=1):
        """TMDB similar TV shows."""
        try:
            data = self._get("/tv/{}/similar".format(tv_id), {"page": page})
            return data.get("results", []), data.get("total_pages", 1)
        except TMDBError:
            return [], 1

    # ── Genres ───────────────────────────────────────────────────────────────

    def genre_movie_list(self):
        """Return list of movie genre dicts: [{id, name}, ...]."""
        try:
            data = self._get("/genre/movie/list")
            return data.get("genres", [])
        except TMDBError:
            return []

    def genre_tv_list(self):
        """Return list of TV genre dicts: [{id, name}, ...]."""
        try:
            data = self._get("/genre/tv/list")
            return data.get("genres", [])
        except TMDBError:
            return []

    def discover_by_genre(self, genre_id, media_type="movie", page=1,
                          sort_by="popularity.desc"):
        """Discover movies or TV shows filtered by genre."""
        params = {
            "with_genres": genre_id,
            "sort_by":     sort_by,
            "page":        page,
        }
        data = self._get("/discover/{}".format(media_type), params)
        return data.get("results", []), min(data.get("total_pages", 1), 500)

    # ── Collections / Franchises ──────────────────────────────────────────────

    def collection_details(self, collection_id):
        """Return collection dict with parts list."""
        try:
            return self._get("/collection/{}".format(collection_id))
        except TMDBError:
            return {}

    # ── People ───────────────────────────────────────────────────────────────

    def search_person(self, query, page=1):
        """Search for actors/directors."""
        data = self._get("/search/person", {"query": query, "page": page})
        return data.get("results", []), data.get("total_pages", 1)

    def person_movie_credits(self, person_id):
        """Return cast + crew movie credits for a person."""
        try:
            return self._get("/person/{}/movie_credits".format(person_id))
        except TMDBError:
            return {"cast": [], "crew": []}

    def person_tv_credits(self, person_id):
        """Return cast + crew TV credits for a person."""
        try:
            return self._get("/person/{}/tv_credits".format(person_id))
        except TMDBError:
            return {"cast": [], "crew": []}

    def person_details(self, person_id):
        """Return person biography and details."""
        try:
            return self._get("/person/{}".format(person_id))
        except TMDBError:
            return {}

    # ── Videos (trailers) ────────────────────────────────────────────────────

    def movie_videos(self, tmdb_id):
        """Video list for a movie. Lightweight - avoids pulling credits."""
        try:
            return self._get("/movie/{}/videos".format(tmdb_id)).get("results", [])
        except TMDBError:
            return []

    def tv_videos(self, tmdb_id):
        """Video list for a TV show. Lightweight - avoids pulling credits."""
        try:
            return self._get("/tv/{}/videos".format(tmdb_id)).get("results", [])
        except TMDBError:
            return []

    # ── External IDs ─────────────────────────────────────────────────────────

    def movie_external_ids(self, tmdb_id):
        """Return external IDs dict for a movie (imdb_id, wikidata_id, etc.)."""
        try:
            return self._get("/movie/{}/external_ids".format(tmdb_id))
        except TMDBError:
            return {}

    def movie_imdb_id(self, tmdb_id):
        """Return the IMDB ID string (e.g. tt1234567) for a movie, or ''.
        Uses the lightweight /external_ids endpoint instead of full movie_details().
        """
        return self.movie_external_ids(tmdb_id).get("imdb_id", "")

    def tv_imdb_id(self, tmdb_id):
        """Return the IMDB ID string for a TV show via /external_ids, or ''."""
        try:
            data = self._get("/tv/{}/external_ids".format(tmdb_id))
            return data.get("imdb_id", "")
        except TMDBError:
            return ""

    def find_by_imdb(self, imdb_id, media_type="movie"):
        """Look up poster/backdrop via TMDB /find endpoint using an IMDB ID."""
        try:
            data = self._get("/find/{}".format(imdb_id),
                             {"external_source": "imdb_id"})
            key  = "movie_results" if media_type == "movie" else "tv_results"
            results = data.get(key, [])
            return results[0] if results else {}
        except TMDBError:
            return {}

    # ── Watch Providers ───────────────────────────────────────────────────────

    def get_provider_logos(self, region="US"):
        global _provider_logo_cache
        if region in _provider_logo_cache:
            return _provider_logo_cache[region]
        try:
            data = self._get("/watch/providers/movie", {"watch_region": region})
            logos = {}
            for p in data.get("results", []):
                pid  = p.get("provider_id")
                path = p.get("logo_path", "")
                if pid and path:
                    logos[pid] = "{}/original{}".format(IMAGE_BASE, path)
            _provider_logo_cache[region] = logos
            return logos
        except TMDBError:
            return {}

    def discover_by_provider(self, provider_id, media_type="movie", page=1, region="US",
                             sort_by="popularity.desc", min_votes=0):
        params = {
            "with_watch_providers": provider_id,
            "watch_region":         region,
            "sort_by":              sort_by,
            "page":                 page,
        }
        if min_votes:
            params["vote_count.gte"] = min_votes
        data = self._get("/discover/{}".format(media_type), params)
        return data.get("results", []), min(data.get("total_pages", 1), 500)

    def watch_providers(self, tmdb_id, media_type="movie", region="US"):
        """Where-to-watch for one title in one region (TMDB / JustWatch data).

        Returns {"flatrate": [...], "free": [...], "ads": [...], "rent": [...],
        "buy": [...]} - each a list of provider dicts with provider_id,
        provider_name and logo_path. Missing region -> empty dict.
        """
        kind = "tv" if media_type == "tv" else "movie"
        data = self._get("/{}/{}/watch/providers".format(kind, int(tmdb_id)))
        return (data.get("results") or {}).get(region, {}) or {}

    # ── Multi-search ─────────────────────────────────────────────────────────

    def search_multi(self, query, page=1):
        data = self._get("/search/multi", {"query": query, "page": page})
        return data.get("results", []), data.get("total_pages", 1)

    # ── Match a recording title to TMDB ──────────────────────────────────────

    def match_recording(self, title, year=None, media_type="movie"):
        """
        Try to match a recording title to a TMDB entry.
        Returns the best matching result dict or None.
        """
        try:
            params = {"query": title}
            if year:
                params["year" if media_type == "movie" else "first_air_date_year"] = year
            if media_type == "movie":
                results, _ = self.search_movies(title)
            else:
                results, _ = self.search_tv(title)
            if results:
                return results[0]
        except TMDBError as e:
            xbmc.log("[BlackKnight/TMDB] match_recording error: {}".format(e), xbmc.LOGWARNING)
        return None
