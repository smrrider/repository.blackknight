"""
service.py — Black Knight background service.
Registered as xbmc.python.service in addon.xml — KODI starts this
automatically and keeps it running for the full session.

Responsibilities:
  - Monitor playback events for Trakt scrobbling
  - Read the now_playing.json handoff file written by default.py
  - Seek to resume position after playback starts (for Continue Watching)
"""
import sys
import os
import time
import xbmc
import xbmcaddon

# Set up lib path the same way default.py does
_ADDON = xbmcaddon.Addon()
sys.path.insert(0, os.path.join(_ADDON.getAddonInfo("path"), "resources", "lib"))

from trakt import Trakt  # noqa: E402


class BlackKnightService(xbmc.Player):

    def __init__(self):
        super(BlackKnightService, self).__init__()
        self._trakt        = Trakt()
        self._np           = None   # current now-playing dict
        self._resume_sec   = 0      # seek target in seconds (0 = no seek)
        self._seek_done    = False
        self._last_pct     = 0
        self._last_hb      = 0      # timestamp of last heartbeat

    # ── Progress helper ────────────────────────────────────────────────────────

    def _pct(self):
        try:
            total = self.getTotalTime()
            return min(int(self.getTime() / total * 100), 100) if total > 0 else 0
        except Exception:
            return self._last_pct

    # ── KODI Player callbacks ──────────────────────────────────────────────────

    def onAVStarted(self):
        """Fires when audio/video actually begins rendering — most reliable callback."""
        self._np = Trakt.read_now_playing()
        if not self._np:
            return  # Not a Black Knight stream

        self._seek_done  = False
        self._last_hb    = time.time()
        self._resume_sec = self._np.get("resume_seconds", 0)

        xbmc.log("[BlackKnight/Service] Now playing: {} ({})".format(
            self._np.get("title") or self._np.get("show_title", ""),
            self._np.get("media_type", "")), xbmc.LOGINFO)

        self._trakt.scrobble_start(self._np, progress=1)

    def onPlayBackStarted(self):
        """Fallback if onAVStarted doesn't fire (older builds)."""
        if self._np is None:
            self._np = Trakt.read_now_playing()
            if self._np:
                self._seek_done = False
                self._resume_sec = self._np.get("resume_seconds", 0)
                self._last_hb = time.time()
                self._trakt.scrobble_start(self._np, progress=1)

    def onPlayBackPaused(self):
        if self._np:
            self._last_pct = self._pct()
            self._trakt.scrobble_pause(self._np, self._last_pct)

    def onPlayBackResumed(self):
        if self._np:
            self._trakt.scrobble_start(self._np, progress=self._pct())
            self._last_hb = time.time()

    def onPlayBackStopped(self):
        if self._np:
            pct = self._pct() or self._last_pct
            if pct >= 80:
                self._trakt.scrobble_stop(self._np, progress=100)
            else:
                self._trakt.scrobble_pause(self._np, progress=pct)
        self._np = None

    def onPlayBackEnded(self):
        if self._np:
            self._trakt.scrobble_stop(self._np, progress=95)
        self._np = None

    def onPlayBackError(self):
        self._np = None  # don't scrobble on error

    # ── Main loop ──────────────────────────────────────────────────────────────

    def run(self):
        monitor = xbmc.Monitor()
        xbmc.log("[BlackKnight/Service] Started", xbmc.LOGINFO)

        while not monitor.abortRequested():
            if self._np and self.isPlaying():
                now = time.time()

                # Seek to resume position once, shortly after playback starts
                if self._resume_sec > 0 and not self._seek_done:
                    try:
                        total = self.getTotalTime()
                        if total > 10:  # stream is loaded enough to seek
                            self.seekTime(self._resume_sec)
                            self._seek_done = True
                            xbmc.log("[BlackKnight/Service] Seeked to {}s".format(
                                self._resume_sec), xbmc.LOGINFO)
                    except Exception:
                        pass

                # Trakt heartbeat every 60 seconds
                if now - self._last_hb >= 60:
                    pct = self._pct()
                    self._last_pct = pct
                    self._trakt.scrobble_start(self._np, progress=pct)
                    self._last_hb = now

            monitor.waitForAbort(2)

        xbmc.log("[BlackKnight/Service] Stopped", xbmc.LOGINFO)


if __name__ == "__main__":
    BlackKnightService().run()
