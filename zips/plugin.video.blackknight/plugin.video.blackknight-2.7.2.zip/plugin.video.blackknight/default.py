"""
default.py — Black Knight plugin entry point and URL router.
"""

import sys
import os
import json
import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs

try:
    from urllib.parse import parse_qsl, quote_plus, unquote_plus
    from urllib.request import urlretrieve
except ImportError:
    from urlparse import parse_qsl
    from urllib import quote_plus, unquote_plus, urlretrieve

# ── Bootstrap ─────────────────────────────────────────────────────────────────
ADDON    = xbmcaddon.Addon()
HANDLE   = int(sys.argv[1])
BASE_URL = sys.argv[0]
PARAMS   = dict(parse_qsl(sys.argv[2][1:]))

sys.path.insert(0, os.path.join(ADDON.getAddonInfo("path"), "resources", "lib"))

from tmdb         import TMDB, TMDBError
from realdebrid   import RealDebrid, RealDebridError
from scraper      import Scraper, ScraperError
from trakt        import Trakt, TraktError, TraktNotAuthorized
import library
import ui


# ── Invocation helpers ────────────────────────────────────────────────────────

def _end_dir_if_plugin():
    """endOfDirectory only makes sense for a real directory handle.
    Settings action buttons use RunPlugin(), where HANDLE is -1.
    """
    if HANDLE >= 0:
        xbmcplugin.endOfDirectory(HANDLE, False)


# ── Settings helpers ──────────────────────────────────────────────────────────

def get_tmdb():
    api_key = ADDON.getSetting("tmdb_api_key")
    lang    = ADDON.getSetting("tmdb_lang") or "en-US"
    return TMDB(api_key, language=lang)


def rd_credential():
    """The Real-Debrid bearer token to use, whatever its source.

    Device-flow OAuth wins; a manually entered API key is the fallback so
    existing installs keep working. Returns "" when neither is present.
    """
    import realdebrid as _rd
    try:
        token = _rd.oauth_access_token()
    except Exception as e:
        xbmc.log("[BlackKnight/RD] oauth token lookup failed: {}".format(e),
                 xbmc.LOGWARNING)
        token = ""
    return token or (ADDON.getSetting("rd_api_key") or "").strip()


def get_scraper():
    rd_key       = rd_credential() if ADDON.getSettingBool("rd_enabled") else ""
    max_results  = int(ADDON.getSetting("rd_max_results") or 20)
    cached_only  = ADDON.getSettingBool("rd_cached_only")
    english_only = ADDON.getSettingBool("rd_english_only")
    return Scraper(rd_api_key=rd_key or None, max_results=max_results,
                   cached_only=cached_only, english_only=english_only)


def get_trakt():
    return Trakt()


def rd_enabled():
    # Must accept a device-flow token too - gating on rd_api_key alone left
    # OAuth-only installs (no manual key) unable to play anything.
    return ADDON.getSettingBool("rd_enabled") and bool(rd_credential())


def trakt_authorized():
    return get_trakt().is_authorized()


def watch_region():
    return ADDON.getSetting("watch_region") or "US"


def sharing_enabled():
    try:
        return ADDON.getSettingBool("sharing_enabled")
    except (TypeError, RuntimeError):
        return ADDON.getSetting("sharing_enabled") == "true"

_my_username_cache = [None]

def sharing_my_username():
    """Your own Trakt username, resolved from the signed-in account.

    No longer a settings field - once Trakt is authorised the addon already
    knows who you are, so asking you to type it was redundant and a typo
    would silently break list sharing. Cached per run.
    """
    if _my_username_cache[0] is not None:
        return _my_username_cache[0]
    name = ""
    try:
        t = get_trakt()
        if t.is_authorized():
            name = (t._get("/users/me") or {}).get("username", "") or ""
    except Exception as e:
        xbmc.log("[BlackKnight] could not resolve Trakt username: {}".format(e),
                 xbmc.LOGWARNING)
    _my_username_cache[0] = name
    return name

def sharing_my_list_slug():
    return ADDON.getSetting("sharing_my_list_slug").strip() or "my-picks"

def sharing_friend_name():
    return ADDON.getSetting("sharing_friend_name").strip()

def sharing_friend_username():
    return ADDON.getSetting("sharing_friend_username").strip()

def sharing_friend_list_slug():
    return ADDON.getSetting("sharing_friend_list_slug").strip() or "my-picks"

def sharing_ready():
    return (sharing_enabled()
            and bool(sharing_my_username())
            and bool(sharing_friend_name())
            and bool(sharing_friend_username()))


def preferred_quality():
    val = ADDON.getSetting("rd_preferred_quality") or "1"
    # Fire Stick / some skins return the label text ("4K", "1080P", "720P")
    # instead of the list index ("0", "1", "2") — handle both.
    _label_map = {
        "4K": "4K", "4k": "4K",
        "1080P": "1080P", "1080p": "1080P",
        "720P": "720P", "720p": "720P",
    }
    if val in _label_map:
        return _label_map[val]
    try:
        return ["4K", "1080P", "720P"][int(val)]
    except (ValueError, IndexError):
        return "1080P"


def _param_str(key, default=""):
    return unquote_plus(PARAMS.get(key, default))


def _param_int(key, default=0):
    try:
        return int(PARAMS.get(key, default) or default)
    except (ValueError, TypeError):
        return default


# ── Provider image cache helpers ─────────────────────────────────────────────

def _profile_dir():
    return xbmcvfs.translatePath(ADDON.getAddonInfo("profile"))


def _cache_provider_logo(pid, remote_url):
    """Download a TMDB provider logo to the addon profile dir. Returns local path."""
    try:
        logo_dir = os.path.join(_profile_dir(), "provider_logos")
        if not xbmcvfs.exists(logo_dir + "/"):
            xbmcvfs.mkdirs(logo_dir)
        local_path = os.path.join(logo_dir, "{}.png".format(pid))
        if not xbmcvfs.exists(local_path):
            urlretrieve(remote_url, local_path)
        return local_path
    except Exception as e:
        xbmc.log("[BlackKnight] Logo cache failed for {}: {}".format(pid, e), xbmc.LOGWARNING)
        return remote_url


def _cache_provider_fanart(pid, remote_url):
    """Download a service backdrop to the addon profile dir. Returns local path."""
    try:
        fanart_dir = os.path.join(_profile_dir(), "provider_fanart")
        if not xbmcvfs.exists(fanart_dir + "/"):
            xbmcvfs.mkdirs(fanart_dir)
        local_path = os.path.join(fanart_dir, "{}.jpg".format(pid))
        if not xbmcvfs.exists(local_path):
            urlretrieve(remote_url, local_path)
        return local_path
    except Exception as e:
        xbmc.log("[BlackKnight] Fanart cache failed for {}: {}".format(pid, e), xbmc.LOGWARNING)
        return remote_url


# ── Home ──────────────────────────────────────────────────────────────────────

def action_home():
    trakt_username = ""
    try:
        from trakt import Trakt
        td = get_trakt()
        if td.is_authorized():
            tdata = td._get("/users/me")
            trakt_username = tdata.get("username", "")
    except Exception:
        pass
    ui.build_home(HANDLE,
                  trakt_authorized=trakt_authorized(),
                  friend_name=sharing_friend_name(),
                  sharing_enabled=sharing_ready(),
                  trakt_username=trakt_username)


def action_open_settings():
    ADDON.openSettings()
    xbmcplugin.endOfDirectory(HANDLE, False)


# ── Streaming Services ────────────────────────────────────────────────────────

def action_streaming_services():
    tmdb   = get_tmdb()
    region = watch_region()

    # Logos
    try:
        remote_logos = tmdb.get_provider_logos(region=region)
    except Exception:
        remote_logos = {}
    logo_map = {}
    for pid, remote_url in remote_logos.items():
        logo_map[pid] = _cache_provider_logo(pid, remote_url)

    # Fanart — load from disk cache or fetch from TMDB
    fanart_cache_path = os.path.join(_profile_dir(), "provider_fanart.json")
    fanart_url_map = {}
    try:
        if os.path.exists(fanart_cache_path):
            with open(fanart_cache_path, "r") as fh:
                fanart_url_map = json.load(fh)
    except Exception:
        pass

    if not fanart_url_map:
        for svc in ui.STREAMING_SERVICES:
            pid = svc["id"]
            try:
                results, _ = tmdb.discover_by_provider(
                    pid, media_type="movie", page=1,
                    region=region, sort_by="popularity.desc")
                for r in results:
                    backdrop = r.get("backdrop_path", "")
                    if backdrop:
                        fanart_url_map[pid] = tmdb.fanart_url(backdrop)
                        break
            except Exception:
                pass
        try:
            with open(fanart_cache_path, "w") as fh:
                json.dump(fanart_url_map, fh)
        except Exception:
            pass

    fanart_map = {}
    for pid, remote_url in fanart_url_map.items():
        if isinstance(pid, str) and pid.isdigit():
            pid = int(pid)
        fanart_map[pid] = _cache_provider_fanart(pid, remote_url)

    ui.build_streaming_services(HANDLE, logo_map=logo_map, fanart_map=fanart_map)


def action_provider_menu():
    provider_id   = _param_int("provider_id")
    provider_name = _param_str("provider_name")
    ui.build_provider_menu(HANDLE, provider_id, provider_name)


def action_provider_movies():
    provider_id   = _param_int("provider_id")
    provider_name = _param_str("provider_name")
    ui.build_provider_subcat_menu(HANDLE, provider_id, provider_name, "movie")


def action_provider_tv():
    provider_id   = _param_int("provider_id")
    provider_name = _param_str("provider_name")
    ui.build_provider_subcat_menu(HANDLE, provider_id, provider_name, "tv")


def action_provider_content():
    provider_id   = _param_int("provider_id")
    provider_name = _param_str("provider_name")
    media_type    = _param_str("media_type", "movie")
    sort_by       = _param_str("sort_by", "popularity.desc")
    min_votes     = _param_int("min_votes", 0)
    page          = _param_int("page", 1)
    region        = watch_region()

    tmdb = get_tmdb()
    try:
        results, total = tmdb.discover_by_provider(
            provider_id, media_type=media_type, page=page,
            region=region, sort_by=sort_by, min_votes=min_votes
        )
    except TMDBError as e:
        _handle_tmdb_error(e)
        return

    next_params = {
        "provider_id":   provider_id,
        "provider_name": provider_name,
        "media_type":    media_type,
        "sort_by":       sort_by,
        "min_votes":     min_votes,
    }

    if media_type == "tv":
        ui.build_tv_list(HANDLE, results, tmdb, total_pages=total, page=page,
                         next_action="provider_content",
                         trakt_authorized=trakt_authorized(),
                         next_params=next_params)
    else:
        ui.build_movie_list(HANDLE, results, tmdb, total_pages=total, page=page,
                            next_action="provider_content",
                            rd_enabled=rd_enabled(),
                            trakt_authorized=trakt_authorized(),
                            next_params=next_params)


# ── Trakt actions ─────────────────────────────────────────────────────────────

def action_trakt_auth():
    t = get_trakt()

    if t.is_authorized():
        if not xbmcgui.Dialog().yesno("Trakt", "Already connected. Reconnect?"):
            return
        # NOTE: do NOT revoke yet. If device auth fails (e.g. bad API key) we
        # would have destroyed a working login for nothing. Revoke on success.

    try:
        auth_data = t.start_device_auth()
    except TraktNotAuthorized as e:
        # Credential-level failure - needs a full dialog, not a 5s toast.
        xbmcgui.Dialog().ok("Trakt - Cannot Start Sign-In", str(e))
        _end_dir_if_plugin()
        return
    except TraktError as e:
        ui.notify_error("Trakt error: {}".format(e))
        _end_dir_if_plugin()
        return

    user_code   = auth_data.get("user_code", "")
    verify_url  = auth_data.get("verification_url", "https://auth.trakt.tv/activate")
    device_code = auth_data["device_code"]
    interval    = max(int(auth_data.get("interval", 5)), 5)
    expires_in  = int(auth_data.get("expires_in", 600))

    xbmcgui.Dialog().ok(
        "Connect to Trakt",
        "1. Go to:  [B]{}[/B]\n"
        "2. Enter:  [B]{}[/B]\n\n"
        "Click OK, then wait for confirmation.".format(verify_url, user_code)
    )

    prog = xbmcgui.DialogProgress()
    prog.create("Connecting to Trakt",
                "Code: [B]{}[/B]  —  Waiting…".format(user_code))

    authorized = False
    elapsed    = 0
    while elapsed < expires_in and not prog.iscanceled():
        xbmc.sleep(interval * 1000)
        elapsed += interval
        remaining = max(expires_in - elapsed, 0)
        prog.update(
            int(elapsed / expires_in * 100),
            "Code: [B]{}[/B]  —  {}s remaining".format(user_code, remaining)
        )
        try:
            if t.poll_device_auth(device_code):
                authorized = True
                break
        except TraktError as e:
            prog.close()
            ui.notify_error("Trakt error: {}".format(e))
            return

    prog.close()

    if authorized:
        ui.notify("Trakt connected!")
        xbmc.executebuiltin("Container.Refresh")
    elif not prog.iscanceled():
        ui.notify_error("Trakt authorization timed out.")
    _end_dir_if_plugin()


def action_trakt_disconnect():
    if xbmcgui.Dialog().yesno("Trakt", "Disconnect from Trakt?"):
        get_trakt().revoke()
        ui.notify("Trakt disconnected.")
        xbmc.executebuiltin("Container.Refresh")
    _end_dir_if_plugin()


def action_trakt_status():
    """Diagnose the Trakt connection and report plainly to the Captain."""
    ok, msg = get_trakt().connection_status()
    xbmcgui.Dialog().ok("Trakt Connection", ("[COLOR lime]OK[/COLOR]\n\n" if ok
                                             else "[COLOR red]PROBLEM[/COLOR]\n\n") + msg)
    _end_dir_if_plugin()


def action_continue_watching():
    t = get_trakt()
    if not t.is_authorized():
        if xbmcgui.Dialog().yesno("Trakt", "Connect to Trakt to use Continue Watching. Connect now?"):
            action_trakt_auth()
        else:
            xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
        return
    movies   = t.get_playback("movies")
    episodes = t.get_playback("episodes")
    ui.build_continue_watching(HANDLE, movies, episodes, tmdb=get_tmdb())


def action_watchlist():
    t = get_trakt()
    if not t.is_authorized():
        if xbmcgui.Dialog().yesno("Trakt", "Connect to Trakt to use My Watchlist. Connect now?"):
            action_trakt_auth()
        else:
            xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
        return
    movies = t.get_watchlist("movies")
    shows  = t.get_watchlist("shows")
    ui.build_watchlist(HANDLE, movies, shows, tmdb=get_tmdb(), rd_enabled=rd_enabled())


def action_watchlist_add():
    """Add a movie or show to Trakt watchlist. Called via RunPlugin (HANDLE=-1)."""
    media_type = PARAMS.get("media_type", "movie")
    tmdb_id    = PARAMS.get("tmdb_id", "")
    imdb_id    = _param_str("imdb_id")
    title      = _param_str("title")
    year       = _param_int("year")

    if not imdb_id and tmdb_id:
        try:
            tmdb = get_tmdb()
            imdb_id = (tmdb.movie_imdb_id(tmdb_id) if media_type == "movie"
                       else tmdb.tv_imdb_id(tmdb_id))
        except TMDBError as e:
            ui.notify_error("Could not resolve IMDB ID: {}".format(e))
            return

    if not imdb_id:
        ui.notify_error("Could not determine IMDB ID.")
        return

    t = get_trakt()
    if not t.is_authorized():
        ui.notify_error("Connect to Trakt first (Home screen → Connect Trakt).")
        return
    try:
        t.add_to_watchlist(imdb_id, media_type=media_type, title=title, year=year)
        ui.notify("Added to My Watchlist: {}".format(title or imdb_id))
    except TraktError as e:
        ui.notify_error("Trakt: {}".format(e))


def action_watchlist_remove():
    """Remove from Trakt watchlist. Called via RunPlugin (HANDLE=-1)."""
    imdb_id    = _param_str("imdb_id")
    media_type = PARAMS.get("media_type", "movie")
    t = get_trakt()
    try:
        t.remove_from_watchlist(imdb_id, media_type=media_type)
        ui.notify("Removed from My Watchlist.")
        xbmc.executebuiltin("Container.Refresh")
    except TraktError as e:
        ui.notify_error("Trakt: {}".format(e))


def action_remove_playback():
    """Remove a continue-watching entry. Called via RunPlugin (HANDLE=-1)."""
    pb_id = PARAMS.get("playback_id", "")
    if pb_id:
        get_trakt().delete_playback(pb_id)
        ui.notify("Removed from Continue Watching.")
        xbmc.executebuiltin("Container.Refresh")


# ── Trailer helpers ───────────────────────────────────────────────────────────

def _pick_youtube_key(videos):
    """Return best YouTube key from a TMDB videos list.
    Priority: Trailer > Teaser > Clip > Featurette > any YouTube video.
    """
    yt = [v for v in (videos or []) if v.get("site") == "YouTube"]
    for vtype in ("Trailer", "Teaser", "Clip", "Featurette"):
        for v in yt:
            if v.get("type") == vtype:
                return v["key"]
    return yt[0]["key"] if yt else ""


def _play_trailer_yt(youtube_key):
    """Launch a YouTube video via plugin.video.youtube. Returns True if launched."""
    if not youtube_key:
        return False
    xbmc.log(
        "[BlackKnight/Trailer] Playing via YouTube plugin: {}".format(youtube_key),
        xbmc.LOGINFO,
    )
    plugin_url = "plugin://plugin.video.youtube/play/?video_id={}".format(youtube_key)
    xbmc.executebuiltin("PlayMedia({})".format(plugin_url))
    return True

# ── Trailer ───────────────────────────────────────────────────────────────────

def action_play_trailer():
    tmdb_id = PARAMS.get("tmdb_id", "")
    title   = _param_str("title")
    year    = _param_int("year")

    youtube_key = ""
    if tmdb_id:
        try:
            videos = get_tmdb().movie_videos(tmdb_id)
            youtube_key = _pick_youtube_key(videos)
        except Exception as e:
            xbmc.log("[BlackKnight/Trailer] TMDB lookup failed: {}".format(e), xbmc.LOGWARNING)

    if _play_trailer_yt(youtube_key):
        return

    # FALLBACK: Apple Trailers direct MP4 -- endpoint currently dead, preserved for future revival.
    from trailer import get_trailer_url
    stream_url = get_trailer_url(title=title, year=year)
    if stream_url:
        xbmc.log("[BlackKnight/Trailer] Playing Apple stream for '{}'".format(title), xbmc.LOGINFO)
        li = xbmcgui.ListItem(title or "Trailer", offscreen=True)
        li.setProperty("IsPlayable", "true")
        xbmc.Player().play(stream_url, li)
        return

    ui.notify_error("No trailer found. Configure YouTube addon API key for trailer support.")

def action_play_tv_trailer():
    """Play a trailer for a TV show."""
    tmdb_id = PARAMS.get("tmdb_id", "")

    youtube_key = ""
    if tmdb_id:
        try:
            videos = get_tmdb().tv_videos(tmdb_id)
            youtube_key = _pick_youtube_key(videos)
        except Exception as e:
            xbmc.log("[BlackKnight/Trailer] TMDB TV lookup failed: {}".format(e), xbmc.LOGWARNING)

    if _play_trailer_yt(youtube_key):
        return

    ui.notify_error("No trailer found for this show.")


# ── Movies ────────────────────────────────────────────────────────────────────

def action_movies():
    ui.build_movies_menu(HANDLE)


def action_trending_movies():
    tmdb  = get_tmdb()
    page  = _param_int("page", 1)
    tw    = {"0": "day", "1": "week"}.get(ADDON.getSetting("trending_time_window"), "day")
    try:
        results, total = tmdb.trending_movies(time_window=tw, page=page)
        ui.build_movie_list(HANDLE, results, tmdb, total_pages=total, page=page,
                            next_action="trending_movies", rd_enabled=rd_enabled(),
                            trakt_authorized=trakt_authorized(),
                            next_params={"time_window": tw})
    except TMDBError as e:
        _handle_tmdb_error(e)


def action_movies_popular():
    tmdb = get_tmdb()
    page = _param_int("page", 1)
    try:
        results, total = tmdb.popular_movies(page=page)
        ui.build_movie_list(HANDLE, results, tmdb, total_pages=total, page=page,
                            next_action="movies_popular", rd_enabled=rd_enabled(),
                            trakt_authorized=trakt_authorized())
    except TMDBError as e:
        _handle_tmdb_error(e)


def action_movies_top_rated():
    tmdb = get_tmdb()
    page = _param_int("page", 1)
    try:
        results, total = tmdb.top_rated_movies(page=page)
        ui.build_movie_list(HANDLE, results, tmdb, total_pages=total, page=page,
                            next_action="movies_top_rated", rd_enabled=rd_enabled(),
                            trakt_authorized=trakt_authorized())
    except TMDBError as e:
        _handle_tmdb_error(e)


def action_movies_search():
    query = xbmcgui.Dialog().input("Search Movies", type=xbmcgui.INPUT_ALPHANUM)
    if not query:
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
        return
    tmdb = get_tmdb()
    page = _param_int("page", 1)
    try:
        results, total = tmdb.search_movies(query, page=page)
        ui.build_movie_list(HANDLE, results, tmdb, total_pages=total, page=page,
                            next_action="movies_search", rd_enabled=rd_enabled(),
                            trakt_authorized=trakt_authorized())
    except TMDBError as e:
        _handle_tmdb_error(e)


def action_movie_sources():
    tmdb_id    = PARAMS.get("tmdb_id", "")
    imdb_id    = _param_str("imdb_id")
    title      = _param_str("title")
    year       = _param_int("year")
    resume_sec = _param_int("resume_seconds", 0)

    if not imdb_id and tmdb_id:
        try:
            imdb_id = get_tmdb().movie_imdb_id(tmdb_id)
        except TMDBError:
            pass

    if not imdb_id:
        ui.notify_error("Could not determine IMDB ID for this title.")
        return

    _pick_and_play_stream(imdb_id, media_type="movie",
                          title=title, year=year, resume_seconds=resume_sec)


# ── TV Shows ──────────────────────────────────────────────────────────────────

def action_tv_shows():
    ui.build_tv_menu(HANDLE)


def action_trending_tv():
    tmdb  = get_tmdb()
    page  = _param_int("page", 1)
    tw    = {"0": "day", "1": "week"}.get(ADDON.getSetting("trending_time_window"), "day")
    try:
        results, total = tmdb.trending_tv(time_window=tw, page=page)
        ui.build_tv_list(HANDLE, results, tmdb, total_pages=total, page=page,
                         next_action="trending_tv", trakt_authorized=trakt_authorized(),
                         next_params={"time_window": tw})
    except TMDBError as e:
        _handle_tmdb_error(e)


def action_tv_popular():
    tmdb = get_tmdb()
    page = _param_int("page", 1)
    try:
        results, total = tmdb.popular_tv(page=page)
        ui.build_tv_list(HANDLE, results, tmdb, total_pages=total, page=page,
                         next_action="tv_popular", trakt_authorized=trakt_authorized())
    except TMDBError as e:
        _handle_tmdb_error(e)


def action_tv_top_rated():
    tmdb = get_tmdb()
    page = _param_int("page", 1)
    try:
        results, total = tmdb.top_rated_tv(page=page)
        ui.build_tv_list(HANDLE, results, tmdb, total_pages=total, page=page,
                         next_action="tv_top_rated", trakt_authorized=trakt_authorized())
    except TMDBError as e:
        _handle_tmdb_error(e)


def action_tv_search():
    query = xbmcgui.Dialog().input("Search TV Shows", type=xbmcgui.INPUT_ALPHANUM)
    if not query:
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
        return
    tmdb = get_tmdb()
    page = _param_int("page", 1)
    try:
        results, total = tmdb.search_tv(query, page=page)
        ui.build_tv_list(HANDLE, results, tmdb, total_pages=total, page=page,
                         next_action="tv_search", trakt_authorized=trakt_authorized())
    except TMDBError as e:
        _handle_tmdb_error(e)


def action_tv_seasons():
    tmdb_id    = PARAMS.get("tmdb_id", "")
    show_title = _param_str("show_title")
    show_year  = _param_int("show_year")
    if not tmdb_id:
        xbmcplugin.endOfDirectory(HANDLE)
        return
    tmdb = get_tmdb()
    try:
        details = tmdb.tv_details(tmdb_id)
        seasons = details.get("seasons", [])
        imdb_id = tmdb.tv_imdb_id(tmdb_id)
        if not show_title:
            show_title = details.get("name", "")
        if not show_year:
            show_year = str(details.get("first_air_date", ""))[:4]
        ui.build_tv_seasons(HANDLE, tmdb_id, seasons, tmdb,
                            show_title=show_title, show_year=show_year, imdb_id=imdb_id)
    except TMDBError as e:
        _handle_tmdb_error(e)


def action_tv_episodes():
    tmdb_id    = PARAMS.get("tmdb_id", "")
    imdb_id    = _param_str("imdb_id")
    season     = PARAMS.get("season", "1")
    show_title = _param_str("show_title")
    show_year  = _param_int("show_year")
    if not tmdb_id:
        xbmcplugin.endOfDirectory(HANDLE)
        return
    tmdb = get_tmdb()
    try:
        episodes = tmdb.tv_episodes(tmdb_id, season)
        ui.build_tv_episodes(HANDLE, episodes, tmdb, imdb_id=imdb_id, season=season,
                             rd_enabled=rd_enabled(), show_title=show_title,
                             show_year=show_year, trakt_authorized=trakt_authorized(),
                             tmdb_id=tmdb_id,
                             friend_name=sharing_friend_name(),
                             sharing_enabled=sharing_ready())
    except TMDBError as e:
        _handle_tmdb_error(e)


def action_tv_episode_sources():
    imdb_id    = _param_str("imdb_id")
    season     = PARAMS.get("season", "1")
    episode    = PARAMS.get("episode", "1")
    show_title = _param_str("show_title")
    show_year  = _param_int("show_year")
    resume_sec = _param_int("resume_seconds", 0)

    if not imdb_id:
        ui.notify_error("Could not determine IMDB ID for this show.")
        return

    _pick_and_play_stream(imdb_id, media_type="episode",
                          season=season, episode=episode,
                          title=show_title, year=show_year,
                          resume_seconds=resume_sec)


# ── Core stream picker ────────────────────────────────────────────────────────

def _pick_and_play_stream(imdb_id, media_type="movie", season=None, episode=None,
                          title="", year=0, resume_seconds=0):
    if not rd_enabled():
        ui.notify_error("Real-Debrid is not enabled — configure API key in Settings.")
        return

    scraper = get_scraper()

    dialog = xbmcgui.DialogProgress()
    dialog.create("Black Knight", "Fetching stream sources…")
    try:
        if media_type == "movie":
            streams = scraper.get_movie_streams(imdb_id)
        else:
            streams = scraper.get_episode_streams(imdb_id, season, episode)
    except ScraperError as e:
        dialog.close()
        ui.notify_error("Scraper: {}".format(e))
        return
    finally:
        dialog.close()

    if not streams:
        if ADDON.getSettingBool("rd_cached_only"):
            xbmcgui.Dialog().ok(
                "Black Knight",
                "No cached streams found for this title.\n"
                "Disable [B]Cached sources only[/B] in Settings to see all sources."
            )
        else:
            xbmcgui.Dialog().ok("Black Knight", "No streams found for this title.")
        return

    pref      = preferred_quality()
    auto_play = ADDON.getSettingBool("rd_auto_play")
    cached    = [s for s in streams if s.cached]
    pref_match = [s for s in cached if pref in s.quality.upper()]

    if auto_play and (pref_match or cached):
        chosen = pref_match[0] if pref_match else cached[0]
        xbmc.log("[BlackKnight] Auto-play selected: {}".format(chosen.label), xbmc.LOGINFO)
    elif len(pref_match) == 1:
        chosen = pref_match[0]
    else:
        idx = xbmcgui.Dialog().select("Choose Stream", [s.label for s in streams])
        if idx < 0:
            return
        chosen = streams[idx]

    dialog.create("Black Knight", "Resolving via Real-Debrid…")
    try:
        if not chosen.cached:
            dialog.update(0, "Stream not cached — adding to Real-Debrid…")
        play_url = scraper.resolve_stream(chosen)
    except ScraperError as e:
        dialog.close()
        ui.notify_error("RD resolve failed: {}".format(e))
        return
    finally:
        dialog.close()

    np = {
        "media_type":     media_type,
        "imdb_id":        imdb_id,
        "title":          title,
        "year":           int(year or 0),
        "show_title":     title if media_type == "episode" else "",
        "show_year":      int(year or 0) if media_type == "episode" else 0,
        "season":         int(season) if season is not None else None,
        "episode":        int(episode) if episode is not None else None,
        "resume_seconds": int(resume_seconds or 0),
    }

    li = xbmcgui.ListItem(path=play_url)
    li.setProperty("IsPlayable", "true")
    xbmcplugin.setResolvedUrl(HANDLE, True, li)

    t = get_trakt()
    if t.is_authorized():
        try:
            from player_monitor import TraktPlayerMonitor
            TraktPlayerMonitor(t, np).monitor_playback()
        except Exception as e:
            xbmc.log("[BlackKnight] Trakt monitor error: {}".format(e), xbmc.LOGWARNING)


# ── Sharing ───────────────────────────────────────────────────────────────────

def action_friends_picks():
    """Display the friend's Trakt recommendation list."""
    if not sharing_ready():
        xbmcgui.Dialog().ok("Black Knight",
                            "Configure sharing in Settings first.")
        xbmcplugin.endOfDirectory(HANDLE, False)
        return
    t = get_trakt()
    movies, shows = t.get_list_items(sharing_friend_username(),
                                     sharing_friend_list_slug())
    ui.build_shared_picks(HANDLE, movies, shows, tmdb=get_tmdb(),
                          owner_name=sharing_friend_name(),
                          is_own_list=False,
                          rd_enabled=rd_enabled())


def action_my_recommendations():
    """Display my own outgoing recommendation list."""
    if not sharing_ready():
        xbmcgui.Dialog().ok("Black Knight",
                            "Configure sharing in Settings first.")
        xbmcplugin.endOfDirectory(HANDLE, False)
        return
    t = get_trakt()
    movies, shows = t.get_list_items(sharing_my_username(),
                                     sharing_my_list_slug())
    ui.build_shared_picks(HANDLE, movies, shows, tmdb=get_tmdb(),
                          owner_name="Me",
                          is_own_list=True,
                          rd_enabled=rd_enabled())


def action_recommend():
    """Add a title to my recommendation list (long-press context menu)."""
    if not sharing_ready():
        ui.notify_error("Configure sharing in Settings first.")
        return
    if not trakt_authorized():
        ui.notify_error("Connect to Trakt first to use sharing.")
        return

    media_type = PARAMS.get("media_type", "movie")
    tmdb_id    = PARAMS.get("tmdb_id", "")
    title      = _param_str("title")
    year       = _param_int("year")

    imdb_id = _param_str("imdb_id")
    if not imdb_id and tmdb_id:
        try:
            tmdb = get_tmdb()
            imdb_id = (tmdb.movie_imdb_id(tmdb_id) if media_type == "movie"
                       else tmdb.tv_imdb_id(tmdb_id))
        except TMDBError:
            pass

    if not imdb_id:
        ui.notify_error("Could not resolve IMDB ID for this title.")
        return

    t = get_trakt()
    try:
        t.add_to_list(sharing_my_username(), sharing_my_list_slug(),
                      imdb_id, media_type=media_type, title=title, year=year)
        ui.notify("Recommended to {}: {}".format(sharing_friend_name(), title))
    except TraktError as e:
        ui.notify_error("Trakt: {}".format(e))


def action_recommend_remove():
    """Remove a title from my recommendation list."""
    if not sharing_ready() or not trakt_authorized():
        ui.notify_error("Sharing not configured or Trakt not connected.")
        return

    media_type = PARAMS.get("media_type", "movie")
    imdb_id    = _param_str("imdb_id")
    title      = _param_str("title")

    if not imdb_id:
        ui.notify_error("Cannot remove: missing IMDB ID.")
        return

    t = get_trakt()
    try:
        t.remove_from_list(sharing_my_username(), sharing_my_list_slug(),
                           imdb_id, media_type=media_type)
        ui.notify("Removed from recommendations: {}".format(title))
        xbmc.executebuiltin("Container.Refresh")
    except TraktError as e:
        ui.notify_error("Trakt: {}".format(e))


# ── Sprint 2 — Movies: Now Playing, Upcoming, Genres, Similar, Collection ──────

def action_movies_now_playing():
    tmdb = get_tmdb()
    page = _param_int("page", 1)
    try:
        results, total = tmdb.now_playing_movies(page=page)
        ui.build_movie_list(HANDLE, results, tmdb, total_pages=total, page=page,
                            next_action="movies_now_playing", rd_enabled=rd_enabled(),
                            trakt_authorized=trakt_authorized())
    except TMDBError as e:
        _handle_tmdb_error(e)


def action_movies_upcoming():
    tmdb = get_tmdb()
    page = _param_int("page", 1)
    try:
        results, total = tmdb.upcoming_movies(page=page)
        ui.build_movie_list(HANDLE, results, tmdb, total_pages=total, page=page,
                            next_action="movies_upcoming", rd_enabled=rd_enabled(),
                            trakt_authorized=trakt_authorized())
    except TMDBError as e:
        _handle_tmdb_error(e)


def action_movies_genres():
    tmdb = get_tmdb()
    genres = tmdb.genre_movie_list()
    ui.build_genres_menu(HANDLE, genres, media_type="movie")


def action_genre_movies():
    genre_id   = _param_str("genre_id")
    genre_name = _param_str("genre_name")
    page       = _param_int("page", 1)
    tmdb = get_tmdb()
    try:
        results, total = tmdb.discover_by_genre(genre_id, media_type="movie", page=page)
        ui.build_movie_list(HANDLE, results, tmdb, total_pages=total, page=page,
                            next_action="genre_movies", rd_enabled=rd_enabled(),
                            trakt_authorized=trakt_authorized(),
                            next_params={"genre_id": genre_id, "genre_name": genre_name})
    except TMDBError as e:
        _handle_tmdb_error(e)


def action_movie_similar():
    tmdb_id = _param_str("tmdb_id")
    page    = _param_int("page", 1)
    tmdb = get_tmdb()
    try:
        results, total = tmdb.movie_recommendations(tmdb_id, page=page)
        if not results:
            results, total = tmdb.movie_similar(tmdb_id, page=page)
        ui.build_movie_list(HANDLE, results, tmdb, total_pages=total, page=page,
                            next_action="movie_similar", rd_enabled=rd_enabled(),
                            trakt_authorized=trakt_authorized(),
                            next_params={"tmdb_id": tmdb_id})
    except TMDBError as e:
        _handle_tmdb_error(e)


def action_movie_collection():
    collection_id = _param_str("collection_id")
    tmdb = get_tmdb()
    try:
        data = tmdb.collection_details(collection_id)
        ui.build_collection(HANDLE, data, tmdb, rd_enabled=rd_enabled(),
                            trakt_authorized=trakt_authorized())
    except TMDBError as e:
        _handle_tmdb_error(e)


# ── Sprint 2 — TV: On the Air, Airing Today, Genres, Similar ─────────────────

def action_tv_on_the_air():
    tmdb = get_tmdb()
    page = _param_int("page", 1)
    try:
        results, total = tmdb.tv_on_the_air(page=page)
        ui.build_tv_list(HANDLE, results, tmdb, total_pages=total, page=page,
                         next_action="tv_on_the_air", trakt_authorized=trakt_authorized())
    except TMDBError as e:
        _handle_tmdb_error(e)


def action_tv_airing_today():
    tmdb = get_tmdb()
    page = _param_int("page", 1)
    try:
        results, total = tmdb.tv_airing_today(page=page)
        ui.build_tv_list(HANDLE, results, tmdb, total_pages=total, page=page,
                         next_action="tv_airing_today", trakt_authorized=trakt_authorized())
    except TMDBError as e:
        _handle_tmdb_error(e)


def action_tv_genres():
    tmdb = get_tmdb()
    genres = tmdb.genre_tv_list()
    ui.build_genres_menu(HANDLE, genres, media_type="tv")


def action_genre_tv():
    genre_id   = _param_str("genre_id")
    genre_name = _param_str("genre_name")
    page       = _param_int("page", 1)
    tmdb = get_tmdb()
    try:
        results, total = tmdb.discover_by_genre(genre_id, media_type="tv", page=page)
        ui.build_tv_list(HANDLE, results, tmdb, total_pages=total, page=page,
                         next_action="genre_tv", trakt_authorized=trakt_authorized(),
                         next_params={"genre_id": genre_id, "genre_name": genre_name})
    except TMDBError as e:
        _handle_tmdb_error(e)


def action_tv_similar():
    tmdb_id = _param_str("tmdb_id")
    page    = _param_int("page", 1)
    tmdb = get_tmdb()
    try:
        results, total = tmdb.tv_recommendations(tmdb_id, page=page)
        if not results:
            results, total = tmdb.tv_similar(tmdb_id, page=page)
        ui.build_tv_list(HANDLE, results, tmdb, total_pages=total, page=page,
                         next_action="tv_similar", trakt_authorized=trakt_authorized(),
                         next_params={"tmdb_id": tmdb_id})
    except TMDBError as e:
        _handle_tmdb_error(e)


# ── Sprint 2 — People & Trakt Recommendations ─────────────────────────────────

def action_search_person():
    query = xbmcgui.Dialog().input("Search Actors / Directors", type=xbmcgui.INPUT_ALPHANUM)
    if not query:
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
        return
    tmdb = get_tmdb()
    try:
        results, _ = tmdb.search_person(query)
        ui.build_person_list(HANDLE, results)
    except TMDBError as e:
        _handle_tmdb_error(e)


def action_person_filmography():
    person_id   = _param_str("person_id")
    person_name = _param_str("person_name")
    tmdb = get_tmdb()
    try:
        credits = tmdb.person_movie_credits(person_id)
        cast    = credits.get("cast", [])
        ui.build_person_filmography(HANDLE, cast, tmdb, rd_enabled=rd_enabled(),
                                    trakt_authorized=trakt_authorized(),
                                    person_name=person_name)
    except TMDBError as e:
        _handle_tmdb_error(e)


def _require_trakt():
    """Return an authorised Trakt client, or None.

    When not signed in this renders a normal one-item folder offering to
    connect, rather than calling action_trakt_auth() inline. That earlier
    approach ended the directory twice and surfaced KODI's generic
    "Error getting directory" even when the sign-in had just succeeded.
    """
    t = get_trakt()
    if t.is_authorized():
        return t

    li = xbmcgui.ListItem(label="Connect Trakt account")
    li.setInfo("video", {"plot": "Sign in to Trakt to browse your lists, "
                                 "collection and watch history."})
    xbmcplugin.addDirectoryItem(HANDLE, ui.build_url(HANDLE, "trakt_auth"), li,
                                isFolder=False)
    xbmcplugin.setContent(HANDLE, "files")
    xbmcplugin.endOfDirectory(HANDLE, succeeded=True)
    return None


def action_rd_auth():
    """Connect a Real-Debrid account using the OAuth device flow.

    Designed for TV remotes - the Captain (or Haley) enters a short code at
    real-debrid.com/device on a phone instead of typing a 52-character API
    key on KODI's on-screen keyboard.
    """
    import realdebrid as rd

    if rd.is_device_authorized():
        if not xbmcgui.Dialog().yesno("Real-Debrid", "Already connected. Reconnect?"):
            return

    try:
        auth = rd.start_device_auth()
    except RealDebridError as e:
        xbmcgui.Dialog().ok("Real-Debrid", "Could not start sign-in.\n\n{}".format(e))
        _end_dir_if_plugin()
        return

    user_code   = auth.get("user_code", "")
    verify_url  = auth.get("verification_url", "https://real-debrid.com/device")
    device_code = auth.get("device_code", "")
    interval    = max(int(auth.get("interval", 5)), 5)
    expires_in  = int(auth.get("expires_in", 600))

    if not device_code or not user_code:
        ui.notify_error("Real-Debrid did not return a sign-in code.")
        _end_dir_if_plugin()
        return

    xbmcgui.Dialog().ok(
        "Connect Real-Debrid",
        "1. Go to:  [B]{}[/B]\n"
        "2. Enter:  [B]{}[/B]\n\n"
        "Click OK, then wait for confirmation.".format(verify_url, user_code)
    )

    prog = xbmcgui.DialogProgress()
    prog.create("Connecting to Real-Debrid",
                "Code: [B]{}[/B]  -  Waiting...".format(user_code))

    authorized = False
    elapsed    = 0
    while elapsed < expires_in and not prog.iscanceled():
        xbmc.sleep(interval * 1000)
        elapsed += interval
        prog.update(int(elapsed * 100 / max(expires_in, 1)),
                    "Code: [B]{}[/B]  -  {}s remaining".format(
                        user_code, max(expires_in - elapsed, 0)))
        cid, secret = rd.poll_device_credentials(device_code)
        if not cid:
            continue
        try:
            rd.exchange_token(cid, secret, device_code)
            authorized = True
        except RealDebridError as e:
            prog.close()
            xbmcgui.Dialog().ok("Real-Debrid", "Sign-in failed.\n\n{}".format(e))
            _end_dir_if_plugin()
            return
        break

    prog.close()

    if authorized:
        try:
            info = RealDebrid().account_info()
            who  = info.get("username", "")
            prem = "Premium" if info.get("type") == "premium" else info.get("type", "")
            xbmcgui.Dialog().ok("Real-Debrid",
                                "Connected as [B]{}[/B]\nAccount: {}".format(who, prem))
        except RealDebridError:
            ui.notify("Real-Debrid connected!")
        _refresh_home()
    elif not prog.iscanceled():
        ui.notify_error("Real-Debrid sign-in timed out.")
    _end_dir_if_plugin()


def action_rd_disconnect():
    import realdebrid as rd
    if xbmcgui.Dialog().yesno("Real-Debrid", "Disconnect this Real-Debrid account?"):
        rd.clear_token()
        ui.notify("Real-Debrid disconnected.")
        _refresh_home()
    _end_dir_if_plugin()


def action_rd_status():
    """Report which Real-Debrid credential is in use and whether it works."""
    import realdebrid as rd
    src = ("device sign-in" if rd.is_device_authorized()
           else ("manual API key" if ADDON.getSetting("rd_api_key").strip()
                 else "none configured"))
    try:
        info = RealDebrid().account_info()
        exp  = info.get("expiration", "")[:10]
        xbmcgui.Dialog().ok(
            "Real-Debrid Connection",
            "[COLOR lime]OK[/COLOR]\n\nUsing: {}\nUser: {}\nType: {}\nExpires: {}".format(
                src, info.get("username", "?"), info.get("type", "?"), exp))
    except RealDebridError as e:
        xbmcgui.Dialog().ok(
            "Real-Debrid Connection",
            "[COLOR red]PROBLEM[/COLOR]\n\nUsing: {}\n\n{}".format(src, e))
    _end_dir_if_plugin()


def _refresh_home():
    """Force the home listing to be rebuilt after a menu change.

    Container.Refresh only affects the *active* container, so it does nothing
    when the editor was opened from Settings. Clearing the plugin directory
    cache makes the next visit to home re-run the plugin either way.
    """
    try:
        xbmc.executeJSONRPC(
            '{"jsonrpc":"2.0","method":"Files.GetDirectory","id":1,'
            '"params":{"directory":"plugin://plugin.video.blackknight/",'
            '"media":"files"}}')
    except Exception:
        pass
    xbmc.executebuiltin("Container.Refresh")


def action_customize_menu():
    """Show/hide and reorder the home screen menu items."""
    dialog  = xbmcgui.Dialog()
    order   = [m["id"] for m in ui.menu_ordered_items()]
    hidden  = ui.menu_hidden_ids()
    by_id   = dict((m["id"], m) for m in ui.MENU_ITEMS)

    while True:
        rows = []
        for mid in order:
            entry  = by_id[mid]
            locked = mid in ui.MENU_LOCKED
            if locked:
                mark = "[COLOR grey][locked][/COLOR]"
            elif mid in hidden:
                mark = "[COLOR red][ ] hidden[/COLOR]"
            else:
                mark = "[COLOR lime][x] shown[/COLOR]"
            rows.append("{}  -  {}".format(entry["label"], mark))
        rows.append("[COLOR yellow]== Save and close ==[/COLOR]")
        rows.append("[COLOR yellow]== Reset to defaults ==[/COLOR]")

        idx = dialog.select("Customize Home Menu", rows)
        if idx < 0:
            return                                  # cancelled - discard changes

        if idx == len(rows) - 2:                    # save
            ui.save_menu_prefs(order, hidden)
            _refresh_home()
            ui.notify("Menu saved")
            return

        if idx == len(rows) - 1:                    # reset
            if dialog.yesno("Customize Menu", "Reset menu to default order and show all items?"):
                ui.save_menu_prefs([], [])
                _refresh_home()
                ui.notify("Menu reset to defaults")
                return
            continue

        mid    = order[idx]
        locked = mid in ui.MENU_LOCKED
        opts   = []
        if not locked:
            opts.append("Hide this item" if mid not in hidden else "Show this item")
        if idx > 0:
            opts.append("Move up")
        if idx < len(order) - 1:
            opts.append("Move down")
        opts.append("Move to top")
        opts.append("Cancel")

        choice = dialog.select(rows[idx].split("  -  ")[0], opts)
        if choice < 0 or opts[choice] == "Cancel":
            continue
        pick = opts[choice]

        if pick == "Hide this item":
            hidden.add(mid)
        elif pick == "Show this item":
            hidden.discard(mid)
        elif pick == "Move up":
            order[idx - 1], order[idx] = order[idx], order[idx - 1]
        elif pick == "Move down":
            order[idx + 1], order[idx] = order[idx], order[idx + 1]
        elif pick == "Move to top":
            order.insert(0, order.pop(idx))


def action_trakt_hub():
    """My Trakt - top-level browsing menu."""
    if not _require_trakt():
        return
    ui.build_trakt_hub(HANDLE, username=sharing_my_username())


def action_trakt_my_lists():
    t = _require_trakt()
    if not t:
        return
    ui.build_trakt_lists_menu(HANDLE, t.get_my_lists(), liked=False)


def action_trakt_liked_lists():
    t = _require_trakt()
    if not t:
        return
    ui.build_trakt_lists_menu(HANDLE, t.get_liked_lists(), liked=True)


def action_trakt_list_items():
    t = _require_trakt()
    if not t:
        return
    list_id = _param_str("list_id")
    owner   = _param_str("owner")
    if owner:
        movies, shows = t.get_list_items(owner, list_id)
    else:
        movies, shows = t.get_my_list_items(list_id)
    ui.build_trakt_items(HANDLE, movies, shows, tmdb=get_tmdb(),
                         rd_enabled=rd_enabled(),
                         trakt_authorized=True,
                         empty_msg="This list is empty")


def action_trakt_collection():
    t = _require_trakt()
    if not t:
        return
    media_type = _param_str("media_type") or "movies"
    items = t.get_collection(media_type)
    movies = items if media_type == "movies" else []
    shows  = items if media_type == "shows"  else []
    ui.build_trakt_items(HANDLE, movies, shows, tmdb=get_tmdb(),
                         rd_enabled=rd_enabled(),
                         trakt_authorized=True,
                         empty_msg="Nothing in your collection")


def action_trakt_watched():
    t = _require_trakt()
    if not t:
        return
    media_type = _param_str("media_type") or "movies"
    items = t.get_watched(media_type)
    movies = items if media_type == "movies" else []
    shows  = items if media_type == "shows"  else []
    ui.build_trakt_items(HANDLE, movies, shows, tmdb=get_tmdb(),
                         rd_enabled=rd_enabled(),
                         trakt_authorized=True,
                         empty_msg="No watch history yet")


def action_trakt_recommendations():
    td = get_trakt()
    if not td.is_authorized():
        ui.notify_error("Connect Trakt from the home screen first.")
        return
    tmdb = get_tmdb()
    movies = td.recommendations_movies(limit=20)
    shows  = td.recommendations_shows(limit=20)
    ui.build_trakt_recommendations(HANDLE, movies, shows, tmdb,
                                   rd_enabled=rd_enabled())

# ── Search ────────────────────────────────────────────────────────────────────

def action_search():
    query = _param_str("query") or xbmcgui.Dialog().input("Search", type=xbmcgui.INPUT_ALPHANUM)
    if not query:
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
        return
    page = _param_int("page", 1)
    tmdb = get_tmdb()
    try:
        results, total = tmdb.search_multi(query, page=page)
        results = [r for r in results if r.get("media_type") in ("movie", "tv")]
        ui.build_search_results(HANDLE, results, tmdb,
                                rd_enabled=rd_enabled(),
                                trakt_authorized=trakt_authorized(),
                                friend_name=sharing_friend_name(),
                                sharing_enabled=sharing_ready(),
                                total_pages=total, page=page,
                                next_params={"query": query})
    except TMDBError as e:
        _handle_tmdb_error(e)


# ── Search Streaming Services (2.7.0) ────────────────────────────────────────

def _stream_svc_order():
    return [s["key"] for s in ss_services_order()]


def ss_services_order():
    import stream_search
    order = [svc["id"] for svc in ui.STREAMING_SERVICES]
    by_tmdb = {}
    for s in stream_search.SERVICES:
        for pid in s["tmdb_ids"]:
            by_tmdb[pid] = s
    out = [by_tmdb[pid] for pid in order if pid in by_tmdb]
    out += [s for s in stream_search.SERVICES if s not in out]
    return out


def _resolve_noop():
    """Non-folder items run with a real handle; tell Kodi nothing will play."""
    if HANDLE >= 0:
        try:
            xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
        except Exception:
            pass


def action_stream_search():
    import stream_search
    stream_search.build_root(HANDLE)


def action_stream_search_new():
    import stream_search
    query = xbmcgui.Dialog().input("Search streaming services", type=xbmcgui.INPUT_ALPHANUM)
    _resolve_noop()
    query = (query or "").strip()
    if not query:
        return
    stream_search.remember(query)
    xbmc.executebuiltin("Container.Update({})".format(
        stream_search.build_url("stream_search_results", query=query)))


def action_stream_search_results():
    import stream_search
    query = _param_str("query").strip()
    if not query:
        query = (xbmcgui.Dialog().input("Search streaming services",
                                        type=xbmcgui.INPUT_ALPHANUM) or "").strip()
    if not query:
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
        return
    stream_search.remember(query)
    stream_search.build_results(HANDLE, query, get_tmdb(), watch_region(),
                                _stream_svc_order())


def action_stream_launch():
    import stream_search
    _resolve_noop()
    stream_search.launch_service(_param_str("svc"), _param_str("query"),
                                 mode=_param_str("mode"))


def action_stream_live():
    import stream_search
    _resolve_noop()
    stream_search.watch_live(_param_str("number"), _param_str("channel"),
                             _param_str("title"), callsign=_param_str("callsign"))


def action_stream_where():
    import stream_search
    _resolve_noop()
    stream_search.show_where(_param_str("title"), _param_str("where"))


def action_stream_search_forget():
    import stream_search
    _resolve_noop()
    stream_search.forget(_param_str("query"))
    xbmc.executebuiltin("Container.Refresh")


def action_stream_search_clear():
    import stream_search
    _resolve_noop()
    if xbmcgui.Dialog().yesno("Black Knight", "Clear all recent streaming searches?"):
        stream_search.save_history([])
        xbmc.executebuiltin("Container.Refresh")


def action_noop():
    _resolve_noop()


# ── Library ───────────────────────────────────────────────────────────────────

def action_library_add_movie():
    tmdb_id = PARAMS.get("tmdb_id", "")
    title   = _param_str("title")
    year    = _param_int("year")

    imdb_id = ""
    if tmdb_id:
        try:
            imdb_id = get_tmdb().movie_imdb_id(tmdb_id)
        except TMDBError:
            pass

    library.add_movie(title, year, tmdb_id, imdb_id=imdb_id)
    ui.notify("Added to library: {}".format(title))
    _trigger_library_scan()


def action_library_add_show():
    tmdb_id = PARAMS.get("tmdb_id", "")
    title   = _param_str("title")
    year    = _param_int("year")

    if not tmdb_id:
        ui.notify_error("Cannot add to library: missing TMDB ID.")
        return

    dialog = xbmcgui.DialogProgress()
    dialog.create("Black Knight", "Building library for {}…".format(title))
    try:
        tmdb    = get_tmdb()
        imdb_id = tmdb.tv_imdb_id(tmdb_id)
        details = tmdb.tv_details(tmdb_id)
        raw_seasons = [s for s in details.get("seasons", [])
                       if s.get("season_number", 0) > 0]
        seasons = {}
        total   = len(raw_seasons)
        for i, season in enumerate(raw_seasons):
            if dialog.iscanceled():
                dialog.close()
                return
            snum     = season["season_number"]
            episodes = tmdb.tv_episodes(tmdb_id, snum)
            seasons[snum] = [e["episode_number"] for e in episodes]
            dialog.update(int((i + 1) / total * 100),
                          "Season {} of {}…".format(i + 1, total))
    except TMDBError as e:
        dialog.close()
        ui.notify_error("TMDB: {}".format(e))
        return
    finally:
        dialog.close()

    library.add_show(title, year, tmdb_id, imdb_id=imdb_id, seasons=seasons)
    ui.notify("Added to library: {} ({} seasons)".format(title, len(seasons)))
    _trigger_library_scan()


def action_library_setup():
    path = library.lib_root()
    xbmcgui.Dialog().ok(
        "Library Setup",
        "Your library files are stored at:\n[B]{}[/B]\n\n"
        "To integrate with Kodi library:\n"
        "1. Videos → Files → Add videos\n"
        "2. Browse to the path above\n"
        "3. Set content to Movies or TV Shows\n"
        "4. Scan for new content\n\n"
        "Use [B]Add to Library[/B] (long-press any title) to add content.".format(path)
    )
    xbmcplugin.endOfDirectory(HANDLE, False)


def _trigger_library_scan():
    path = library.lib_root()
    xbmc.executebuiltin("UpdateLibrary(video,{})".format(path))


# ── Error helpers ─────────────────────────────────────────────────────────────

def _handle_tmdb_error(e):
    msg = str(e)
    xbmc.log("[BlackKnight] TMDB error: {}".format(msg), xbmc.LOGWARNING)
    if "API key" in msg or "not configured" in msg:
        if xbmcgui.Dialog().yesno("Black Knight",
                                  "TMDB API key not configured.\nOpen Settings now?"):
            ADDON.openSettings()
    else:
        ui.notify_error("TMDB: {}".format(msg))
    xbmcplugin.endOfDirectory(HANDLE, succeeded=False)


# ── Router ────────────────────────────────────────────────────────────────────

ACTIONS = {
    # Home
    "home":               action_home,
    "open_settings":      action_open_settings,
    # Search
    "search":             action_search,
    # Search Streaming Services (2.7.0)
    "stream_search":          action_stream_search,
    "stream_search_new":      action_stream_search_new,
    "stream_search_results":  action_stream_search_results,
    "stream_launch":          action_stream_launch,
    "stream_live":            action_stream_live,
    "stream_where":           action_stream_where,
    "stream_search_forget":   action_stream_search_forget,
    "stream_search_clear":    action_stream_search_clear,
    "noop":                   action_noop,
    # Streaming Services
    "streaming_services": action_streaming_services,
    "provider_menu":      action_provider_menu,
    "provider_movies":    action_provider_movies,
    "provider_tv":        action_provider_tv,
    "provider_content":   action_provider_content,
    # Trakt
    "trakt_auth":         action_trakt_auth,
    "trakt_status":          action_trakt_status,
    "trakt_disconnect":   action_trakt_disconnect,
    "continue_watching":  action_continue_watching,
    "watchlist":          action_watchlist,
    "watchlist_add":      action_watchlist_add,
    "watchlist_remove":   action_watchlist_remove,
    "remove_playback":    action_remove_playback,
    # Trailer
    "play_trailer":       action_play_trailer,
    "play_tv_trailer":    action_play_tv_trailer,
    # Movies
    "trending_movies":    action_trending_movies,
    "movies":             action_movies,
    "movies_popular":     action_movies_popular,
    "movies_top_rated":   action_movies_top_rated,
    "movies_search":      action_movies_search,
    "movie_sources":      action_movie_sources,
    # Sharing
    "friends_picks":      action_friends_picks,
    "my_recommendations": action_my_recommendations,
    "recommend":          action_recommend,
    "recommend_remove":   action_recommend_remove,
    # Library
    "library_add_movie":  action_library_add_movie,
    "library_add_show":   action_library_add_show,
    "library_setup":      action_library_setup,
    # TV Shows
    "trending_tv":        action_trending_tv,
    "tv_shows":           action_tv_shows,
    "tv_popular":         action_tv_popular,
    "tv_top_rated":       action_tv_top_rated,
    "tv_on_the_air":      action_tv_on_the_air,
    "tv_airing_today":    action_tv_airing_today,
    "tv_search":          action_tv_search,
    "tv_seasons":         action_tv_seasons,
    "tv_episodes":        action_tv_episodes,
    "tv_episode_sources": action_tv_episode_sources,
    # Content discovery (Sprint 2)
    "movies_now_playing":   action_movies_now_playing,
    "movies_upcoming":      action_movies_upcoming,
    "movies_genres":        action_movies_genres,
    "tv_genres":            action_tv_genres,
    "genre_movies":         action_genre_movies,
    "genre_tv":             action_genre_tv,
    "movie_similar":        action_movie_similar,
    "tv_similar":           action_tv_similar,
    "movie_collection":     action_movie_collection,
    "search_person":        action_search_person,
    "person_filmography":   action_person_filmography,
    "trakt_recommendations": action_trakt_recommendations,
    "trakt_hub":             action_trakt_hub,
    "customize_menu":        action_customize_menu,
    "rd_auth":               action_rd_auth,
    "rd_disconnect":         action_rd_disconnect,
    "rd_status":             action_rd_status,
    "trakt_my_lists":        action_trakt_my_lists,
    "trakt_liked_lists":     action_trakt_liked_lists,
    "trakt_list_items":      action_trakt_list_items,
    "trakt_collection":      action_trakt_collection,
    "trakt_watched":         action_trakt_watched,
}


def router():
    action = PARAMS.get("action", "home")
    xbmc.log("[BlackKnight] action={}  params={}".format(action, PARAMS), xbmc.LOGDEBUG)
    handler = ACTIONS.get(action)
    if handler:
        handler()
    else:
        xbmc.log("[BlackKnight] Unknown action: {}".format(action), xbmc.LOGWARNING)
        action_home()


if __name__ == "__main__":
    router()






